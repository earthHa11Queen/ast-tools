package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordGateway#findStaleTables.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordGatewayFindStaleTablesScenario {

    @Test
    @DisplayName("UTAPI-005671")
    void case_UTAPI_005671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005671",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005671", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005671", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005671", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005671", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005671", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005671", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005671", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005671", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005671", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005671", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005671", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005671")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005672")
    void case_UTAPI_005672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005672",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005672", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005672", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005672", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005672", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005672", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005672", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005672", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005672", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005672", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005672", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005672", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005672")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005673")
    void case_UTAPI_005673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005673",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005673", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005673", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005673", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005673", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005673", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005673", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005673", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005673", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005673", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005673", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005673", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005673")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005674")
    void case_UTAPI_005674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005674",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005674", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005674", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005674", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005674", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005674", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005674", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005674", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005674", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005674", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005674", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005674", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005674")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005675")
    void case_UTAPI_005675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005675",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005675", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005675", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005675", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005675", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005675", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005675", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005675", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005675", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005675", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005675", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005675", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005675")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005676")
    void case_UTAPI_005676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005676",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005676", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005676", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005676", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005676", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005676", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005676", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005676", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005676", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005676", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005676", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005676", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005676")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005677")
    void case_UTAPI_005677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005677",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005677", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005677", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005677", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005677", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005677", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005677", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005677", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005677", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005677", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005677", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005677", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005677")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005678")
    void case_UTAPI_005678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005678",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005678", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005678", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005678", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005678", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005678", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005678", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005678", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005678", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005678", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005678", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005678", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005678")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005679")
    void case_UTAPI_005679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005679",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005679", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005679", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005679", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005679", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005679", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005679", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005679", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005679", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005679", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005679", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005679", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005679")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005680")
    void case_UTAPI_005680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005680",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005680", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005680", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005680", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005680", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005680", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005680", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005680", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005680", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005680", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005680", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005680", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005680")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005681")
    void case_UTAPI_005681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005681",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005681", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005681", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005681", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005681", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005681", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005681", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005681", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005681", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005681", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005681", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005681", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005681")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005682")
    void case_UTAPI_005682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005682",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005682", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005682", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005682", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005682", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005682", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005682", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005682", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005682", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005682", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005682", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005682", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005682")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005683")
    void case_UTAPI_005683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005683",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005683", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005683", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005683", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005683", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005683", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005683", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005683", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005683", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005683", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005683", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005683", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005683")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005684")
    void case_UTAPI_005684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005684",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005684", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005684", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005684", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005684", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005684", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005684", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005684", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005684", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005684", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005684", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005684", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005684")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005685")
    void case_UTAPI_005685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005685",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005685", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005685", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005685", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005685", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005685", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005685", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005685", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005685", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005685", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005685", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005685", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005685")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005686")
    void case_UTAPI_005686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005686",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005686", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005686", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005686", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005686", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005686", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005686", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005686", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005686", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005686", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005686", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005686", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005686")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005687")
    void case_UTAPI_005687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005687",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005687", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005687", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005687", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005687", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005687", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005687", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005687", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005687", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005687", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005687", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005687", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005687")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005688")
    void case_UTAPI_005688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005688",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005688", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005688", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005688", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005688", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005688", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005688", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005688", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005688", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005688", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005688", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005688", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005688")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005689")
    void case_UTAPI_005689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005689",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005689", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005689", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005689", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005689", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005689", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005689", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005689", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005689", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005689", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005689", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005689", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005689")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005690")
    void case_UTAPI_005690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005690",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005690", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005690", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005690", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005690", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005690", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005690", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005690", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005690", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005690", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005690", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005690", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005690")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005691")
    void case_UTAPI_005691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005691",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005691", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005691", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005691", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005691", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005691", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005691", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005691", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005691", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005691", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005691", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005691", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005691")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005692")
    void case_UTAPI_005692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005692",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005692", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005692", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005692", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005692", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005692", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005692", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005692", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005692", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005692", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005692", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005692", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005692")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005693")
    void case_UTAPI_005693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005693",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005693", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005693", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005693", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005693", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005693", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005693", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005693", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005693", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005693", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005693", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005693", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005693")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005694")
    void case_UTAPI_005694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005694",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005694", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005694", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005694", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005694", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005694", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005694", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005694", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005694", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005694", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005694", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005694", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005694")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005695")
    void case_UTAPI_005695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005695",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005695", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005695", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005695", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005695", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005695", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005695", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005695", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005695", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005695", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005695", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005695", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005695")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005696")
    void case_UTAPI_005696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005696",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005696", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005696", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005696", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005696", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005696", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005696", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005696", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005696", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005696", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005696", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005696", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005696")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005697")
    void case_UTAPI_005697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005697",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005697", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005697", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005697", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005697", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005697", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005697", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005697", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005697", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005697", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005697", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005697", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005697")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005698")
    void case_UTAPI_005698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005698",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005698", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005698", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005698", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005698", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005698", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005698", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005698", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005698", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005698", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005698", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005698", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005698")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005699")
    void case_UTAPI_005699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005699",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005699", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005699", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005699", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005699", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005699", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005699", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005699", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005699", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005699", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005699", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005699", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005699")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005700")
    void case_UTAPI_005700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005700",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005700", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005700", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005700", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005700", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005700", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005700", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005700", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005700", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005700", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005700", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005700", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005700")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005701")
    void case_UTAPI_005701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005701",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005701", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005701", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005701", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005701", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005701", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005701", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005701", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005701", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005701", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005701", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005701", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005701")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005702")
    void case_UTAPI_005702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005702",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005702", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005702", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005702", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005702", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005702", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005702", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005702", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005702", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005702", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005702", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005702", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005702")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005703")
    void case_UTAPI_005703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005703",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005703", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005703", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005703", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005703", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005703", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005703", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005703", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005703", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005703", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005703", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005703", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005703")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005704")
    void case_UTAPI_005704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005704",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005704", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005704", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005704", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005704", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005704", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005704", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005704", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005704", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005704", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005704", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005704", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005704")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005705")
    void case_UTAPI_005705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005705",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005705", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005705", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005705", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005705", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005705", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005705", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005705", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005705", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005705", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005705", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005705", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005705")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005706")
    void case_UTAPI_005706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005706",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005706", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005706", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005706", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005706", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005706", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005706", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005706", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005706", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005706", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005706", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005706", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005706")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005707")
    void case_UTAPI_005707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005707",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005707", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005707", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005707", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005707", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005707", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005707", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005707", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005707", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005707", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005707", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005707", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005707")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005708")
    void case_UTAPI_005708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005708",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005708", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005708", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005708", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005708", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005708", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005708", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005708", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005708", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005708", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005708", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005708", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005708")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005709")
    void case_UTAPI_005709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005709",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005709", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005709", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005709", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005709", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005709", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005709", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005709", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005709", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005709", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005709", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005709", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005709")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005710")
    void case_UTAPI_005710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005710",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005710", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005710", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005710", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005710", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005710", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005710", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005710", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005710", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005710", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005710", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005710", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005710")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005711")
    void case_UTAPI_005711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005711",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005711", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005711", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005711", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005711", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005711", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005711", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005711", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005711", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005711", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005711", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005711", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005711")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005712")
    void case_UTAPI_005712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005712",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005712", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005712", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005712", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005712", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005712", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005712", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005712", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005712", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005712", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005712", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005712", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005712")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005713")
    void case_UTAPI_005713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005713",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005713", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005713", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005713", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005713", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005713", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005713", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005713", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005713", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005713", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005713", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005713", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005713")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005714")
    void case_UTAPI_005714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005714",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005714", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005714", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005714", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005714", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005714", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005714", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005714", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005714", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005714", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005714", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005714", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005714")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005715")
    void case_UTAPI_005715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005715",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005715", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005715", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005715", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005715", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005715", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005715", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005715", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005715", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005715", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005715", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005715", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005715")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005716")
    void case_UTAPI_005716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005716",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005716", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005716", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005716", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005716", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005716", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005716", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005716", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005716", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005716", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005716", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005716", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005716")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005717")
    void case_UTAPI_005717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005717",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005717", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005717", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005717", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005717", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005717", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005717", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005717", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005717", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005717", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005717", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005717", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005717")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005718")
    void case_UTAPI_005718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005718",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005718", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005718", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005718", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005718", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005718", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005718", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005718", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005718", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005718", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005718", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005718", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005718")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005719")
    void case_UTAPI_005719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005719",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005719", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005719", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005719", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005719", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005719", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005719", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005719", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005719", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005719", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005719", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005719", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005719")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005720")
    void case_UTAPI_005720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005720",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005720", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005720", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005720", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005720", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005720", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005720", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005720", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005720", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005720", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005720", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005720", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005720")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005721")
    void case_UTAPI_005721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005721",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005721", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005721", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005721", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005721", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005721", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005721", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005721", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005721", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005721", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005721", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005721", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005721")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005722")
    void case_UTAPI_005722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005722",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005722", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005722", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005722", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005722", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005722", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005722", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005722", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005722", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005722", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005722", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005722", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005722")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005723")
    void case_UTAPI_005723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005723",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005723", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005723", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005723", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005723", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005723", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005723", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005723", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005723", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005723", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005723", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005723", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005723")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005724")
    void case_UTAPI_005724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005724",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005724", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005724", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005724", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005724", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005724", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005724", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005724", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005724", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005724", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005724", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005724", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005724")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005725")
    void case_UTAPI_005725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005725",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005725", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005725", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005725", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005725", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005725", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005725", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005725", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005725", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005725", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005725", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005725", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005725")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005726")
    void case_UTAPI_005726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005726",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005726", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005726", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005726", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005726", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005726", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005726", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005726", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005726", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005726", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005726", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005726", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005726")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005727")
    void case_UTAPI_005727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005727",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005727", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005727", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005727", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005727", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005727", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005727", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005727", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005727", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005727", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005727", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005727", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005727")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005728")
    void case_UTAPI_005728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005728",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005728", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005728", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005728", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005728", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005728", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005728", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005728", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005728", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005728", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005728", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005728", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005728")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005729")
    void case_UTAPI_005729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005729",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005729", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005729", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005729", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005729", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005729", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005729", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005729", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005729", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005729", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005729", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005729", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005729")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005730")
    void case_UTAPI_005730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005730",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005730", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005730", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005730", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005730", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005730", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005730", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005730", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005730", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005730", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005730", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005730", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005730")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005731")
    void case_UTAPI_005731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005731",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005731", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005731", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005731", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005731", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005731", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005731", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005731", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005731", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005731", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005731", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005731", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005731")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005732")
    void case_UTAPI_005732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005732",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005732", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005732", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005732", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005732", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005732", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005732", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005732", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005732", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005732", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005732", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005732", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005732")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005733")
    void case_UTAPI_005733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005733",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005733", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005733", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005733", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005733", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005733", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005733", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005733", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005733", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005733", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005733", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005733", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005733")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005734")
    void case_UTAPI_005734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005734",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005734", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005734", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005734", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005734", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005734", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005734", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005734", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005734", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005734", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005734", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005734", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005734")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005735")
    void case_UTAPI_005735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005735",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005735", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005735", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005735", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005735", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005735", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005735", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005735", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005735", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005735", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005735", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005735", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005735")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005736")
    void case_UTAPI_005736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005736",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005736", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005736", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005736", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005736", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005736", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005736", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005736", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005736", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005736", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005736", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005736", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005736")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005737")
    void case_UTAPI_005737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005737",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005737", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005737", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005737", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005737", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005737", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005737", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005737", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005737", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005737", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005737", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005737", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005737")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005738")
    void case_UTAPI_005738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005738",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005738", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005738", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005738", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005738", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005738", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005738", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005738", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005738", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005738", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005738", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005738", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005738")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005739")
    void case_UTAPI_005739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005739",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005739", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005739", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005739", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005739", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005739", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005739", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005739", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005739", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005739", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005739", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005739", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005739")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005740")
    void case_UTAPI_005740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005740",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005740", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005740", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005740", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005740", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005740", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005740", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005740", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005740", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005740", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005740", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005740", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005740")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005741")
    void case_UTAPI_005741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005741",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005741", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005741", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005741", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005741", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005741", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005741", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005741", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005741", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005741", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005741", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005741", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005741")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005742")
    void case_UTAPI_005742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005742",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005742", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005742", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005742", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005742", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005742", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005742", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005742", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005742", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005742", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005742", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005742", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005742")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005743")
    void case_UTAPI_005743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005743",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005743", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005743", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005743", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005743", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005743", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005743", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005743", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005743", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005743", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005743", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005743", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005743")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005744")
    void case_UTAPI_005744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005744",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005744", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005744", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005744", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005744", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005744", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005744", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005744", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005744", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005744", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005744", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005744", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005744")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005745")
    void case_UTAPI_005745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005745",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005745", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005745", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005745", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005745", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005745", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005745", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005745", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005745", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005745", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005745", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005745", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005745")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005746")
    void case_UTAPI_005746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005746",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005746", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005746", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005746", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005746", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005746", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005746", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005746", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005746", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005746", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005746", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005746", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005746")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005747")
    void case_UTAPI_005747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005747",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005747", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005747", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005747", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005747", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005747", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005747", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005747", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005747", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005747", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005747", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005747", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005747")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005748")
    void case_UTAPI_005748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005748",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005748", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005748", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005748", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005748", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005748", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005748", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005748", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005748", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005748", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005748", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005748", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005748")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005749")
    void case_UTAPI_005749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005749",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005749", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005749", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005749", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005749", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005749", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005749", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005749", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005749", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005749", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005749", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005749", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005749")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005750")
    void case_UTAPI_005750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005750",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005750", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005750", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005750", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005750", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005750", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005750", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005750", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005750", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005750", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005750", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005750", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005750")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005751")
    void case_UTAPI_005751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005751",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005751", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005751", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005751", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005751", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005751", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005751", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005751", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005751", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005751", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005751", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005751", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005751")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005752")
    void case_UTAPI_005752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005752",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005752", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005752", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005752", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005752", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005752", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005752", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005752", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005752", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005752", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005752", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005752", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005752")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005753")
    void case_UTAPI_005753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005753",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005753", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005753", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005753", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005753", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005753", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005753", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005753", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005753", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005753", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005753", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005753", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005753")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005754")
    void case_UTAPI_005754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005754",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005754", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005754", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005754", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005754", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005754", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005754", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005754", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005754", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005754", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005754", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005754", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005754")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005755")
    void case_UTAPI_005755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005755",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005755", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005755", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005755", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005755", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005755", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005755", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005755", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005755", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005755", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005755", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005755", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005755")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005756")
    void case_UTAPI_005756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005756",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005756", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005756", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005756", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005756", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005756", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005756", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005756", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005756", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005756", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005756", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005756", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005756")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005757")
    void case_UTAPI_005757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005757",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005757", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005757", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005757", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005757", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005757", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005757", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005757", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005757", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005757", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005757", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005757", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005757")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005758")
    void case_UTAPI_005758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005758",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005758", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005758", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005758", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005758", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005758", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005758", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005758", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005758", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005758", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005758", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005758", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005758")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005759")
    void case_UTAPI_005759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005759",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005759", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005759", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005759", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005759", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005759", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005759", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005759", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005759", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005759", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005759", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005759", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005759")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005760")
    void case_UTAPI_005760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005760",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005760", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005760", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005760", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005760", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005760", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005760", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005760", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005760", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005760", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005760", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005760", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005760")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005761")
    void case_UTAPI_005761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005761",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005761", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005761", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005761", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005761", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005761", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005761", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005761", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005761", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005761", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005761", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005761", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005761")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005762")
    void case_UTAPI_005762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005762",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005762", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005762", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005762", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005762", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005762", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005762", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005762", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005762", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005762", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005762", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005762", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005762")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005763")
    void case_UTAPI_005763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005763",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005763", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005763", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005763", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005763", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005763", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005763", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005763", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005763", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005763", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005763", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005763", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005763")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005764")
    void case_UTAPI_005764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005764",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005764", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005764", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005764", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005764", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005764", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005764", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005764", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005764", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005764", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005764", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005764", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005764")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005765")
    void case_UTAPI_005765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005765",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005765", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005765", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005765", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005765", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005765", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005765", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005765", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005765", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005765", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005765", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005765", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005765")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005766")
    void case_UTAPI_005766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005766",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005766", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005766", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005766", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005766", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005766", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005766", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005766", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005766", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005766", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005766", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005766", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005766")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005767")
    void case_UTAPI_005767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005767",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005767", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005767", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005767", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005767", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005767", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005767", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005767", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005767", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005767", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005767", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005767", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005767")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005768")
    void case_UTAPI_005768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005768",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005768", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005768", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005768", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005768", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005768", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005768", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005768", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005768", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005768", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005768", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005768", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005768")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005769")
    void case_UTAPI_005769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005769",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005769", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005769", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005769", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005769", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005769", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005769", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005769", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005769", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005769", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005769", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005769", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005769")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005770")
    void case_UTAPI_005770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005770",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005770", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005770", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005770", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005770", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005770", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005770", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005770", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005770", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005770", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005770", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005770", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005770")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005771")
    void case_UTAPI_005771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005771",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005771", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005771", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005771", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005771", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005771", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005771", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005771", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005771", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005771", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005771", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005771", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005771")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005772")
    void case_UTAPI_005772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005772",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005772", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005772", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005772", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005772", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005772", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005772", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005772", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005772", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005772", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005772", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005772", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005772")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005773")
    void case_UTAPI_005773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005773",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005773", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005773", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005773", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005773", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005773", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005773", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005773", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005773", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005773", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005773", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005773", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005773")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005774")
    void case_UTAPI_005774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005774",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005774", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005774", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005774", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005774", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005774", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005774", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005774", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005774", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005774", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005774", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005774", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005774")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005775")
    void case_UTAPI_005775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005775",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005775", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005775", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005775", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005775", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005775", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005775", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005775", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005775", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005775", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005775", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005775", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005775")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005776")
    void case_UTAPI_005776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005776",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005776", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005776", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005776", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005776", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005776", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005776", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005776", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005776", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005776", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005776", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005776", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005776")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005777")
    void case_UTAPI_005777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005777",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005777", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005777", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005777", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005777", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005777", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005777", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005777", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005777", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005777", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005777", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005777", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005777")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005778")
    void case_UTAPI_005778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005778",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005778", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005778", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005778", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005778", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005778", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005778", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005778", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005778", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005778", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005778", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005778", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005778")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005779")
    void case_UTAPI_005779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005779",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005779", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005779", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005779", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005779", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005779", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005779", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005779", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005779", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005779", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005779", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005779", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005779")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005780")
    void case_UTAPI_005780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005780",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005780", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005780", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005780", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005780", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005780", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005780", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005780", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005780", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005780", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005780", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005780", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005780")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005781")
    void case_UTAPI_005781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005781",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005781", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005781", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005781", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005781", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005781", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005781", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005781", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005781", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005781", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005781", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005781", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005781")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005782")
    void case_UTAPI_005782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005782",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005782", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005782", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005782", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005782", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005782", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005782", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005782", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005782", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005782", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005782", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005782", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005782")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005783")
    void case_UTAPI_005783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005783",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005783", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005783", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005783", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005783", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005783", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005783", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005783", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005783", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005783", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005783", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005783", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005783")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005784")
    void case_UTAPI_005784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005784",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005784", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005784", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005784", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005784", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005784", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005784", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005784", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005784", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005784", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005784", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005784", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005784")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005785")
    void case_UTAPI_005785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005785",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005785", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005785", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005785", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005785", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005785", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005785", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005785", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005785", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005785", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005785", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005785", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005785")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005786")
    void case_UTAPI_005786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005786",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005786", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005786", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005786", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005786", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005786", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005786", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005786", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005786", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005786", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005786", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005786", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005786")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005787")
    void case_UTAPI_005787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005787",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005787", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005787", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005787", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005787", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005787", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005787", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005787", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005787", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005787", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005787", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005787", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005787")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005788")
    void case_UTAPI_005788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005788",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005788", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005788", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005788", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005788", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005788", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005788", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005788", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005788", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005788", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005788", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005788", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005788")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005789")
    void case_UTAPI_005789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005789",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005789", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005789", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005789", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005789", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005789", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005789", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005789", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005789", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005789", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005789", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005789", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005789")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005790")
    void case_UTAPI_005790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005790",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005790", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005790", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005790", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005790", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005790", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005790", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005790", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005790", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005790", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005790", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005790", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005790")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005791")
    void case_UTAPI_005791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005791",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005791", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005791", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005791", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005791", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005791", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005791", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005791", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005791", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005791", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005791", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005791", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005791")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005792")
    void case_UTAPI_005792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005792",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005792", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005792", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005792", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005792", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005792", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005792", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005792", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005792", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005792", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005792", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005792", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005792")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005793")
    void case_UTAPI_005793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005793",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005793", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005793", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005793", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005793", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005793", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005793", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005793", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005793", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005793", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005793", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005793", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005793")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005794")
    void case_UTAPI_005794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005794",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005794", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005794", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005794", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005794", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005794", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005794", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005794", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005794", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005794", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005794", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005794", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005794")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005795")
    void case_UTAPI_005795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005795",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005795", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005795", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005795", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005795", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005795", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005795", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005795", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005795", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005795", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005795", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005795", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005795")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005796")
    void case_UTAPI_005796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005796",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005796", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005796", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005796", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005796", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005796", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005796", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005796", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005796", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005796", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005796", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005796", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005796")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005797")
    void case_UTAPI_005797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005797",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005797", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005797", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005797", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005797", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005797", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005797", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005797", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005797", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005797", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005797", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005797", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005797")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005798")
    void case_UTAPI_005798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005798",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005798", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005798", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005798", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005798", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005798", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005798", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005798", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005798", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005798", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005798", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005798", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005798")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005799")
    void case_UTAPI_005799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005799",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005799", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005799", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005799", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005799", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005799", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005799", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005799", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005799", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005799", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005799", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005799", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005799")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005800")
    void case_UTAPI_005800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005800",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005800", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005800", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005800", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005800", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005800", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005800", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005800", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005800", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005800", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005800", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005800", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005800")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005801")
    void case_UTAPI_005801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005801",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005801", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005801", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005801", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005801", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005801", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005801", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005801", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005801", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005801", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005801", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005801", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005801")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005802")
    void case_UTAPI_005802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005802",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005802", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005802", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005802", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005802", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005802", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005802", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005802", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005802", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005802", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005802", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005802", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005802")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005803")
    void case_UTAPI_005803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005803",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005803", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005803", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005803", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005803", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005803", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005803", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005803", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005803", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005803", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005803", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005803", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005803")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005804")
    void case_UTAPI_005804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005804",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005804", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005804", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005804", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005804", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005804", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005804", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005804", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005804", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005804", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005804", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005804", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005804")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005805")
    void case_UTAPI_005805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005805",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005805", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005805", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005805", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005805", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005805", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005805", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005805", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005805", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005805", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005805", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005805", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005805")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005806")
    void case_UTAPI_005806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005806",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005806", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005806", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005806", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005806", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005806", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005806", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005806", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005806", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005806", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005806", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005806", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005806")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005807")
    void case_UTAPI_005807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005807",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005807", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005807", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005807", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005807", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005807", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005807", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005807", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005807", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005807", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005807", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005807", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005807")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005808")
    void case_UTAPI_005808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005808",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005808", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005808", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005808", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005808", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005808", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005808", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005808", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005808", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005808", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005808", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005808", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005808")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005809")
    void case_UTAPI_005809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005809",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005809", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005809", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005809", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005809", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005809", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005809", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005809", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005809", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005809", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005809", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005809", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005809")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005810")
    void case_UTAPI_005810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005810",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005810", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005810", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005810", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005810", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005810", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005810", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005810", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005810", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005810", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005810", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005810", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005810")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005811")
    void case_UTAPI_005811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005811",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005811", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005811", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005811", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005811", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005811", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005811", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005811", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005811", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005811", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005811", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005811", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005811")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005812")
    void case_UTAPI_005812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005812",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005812", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005812", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005812", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005812", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005812", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005812", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005812", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005812", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005812", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005812", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005812", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005812")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005813")
    void case_UTAPI_005813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005813",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005813", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005813", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005813", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005813", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005813", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005813", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005813", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005813", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005813", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005813", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005813", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005813")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005814")
    void case_UTAPI_005814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005814",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005814", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005814", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005814", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005814", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005814", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005814", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005814", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005814", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005814", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005814", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005814", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005814")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005815")
    void case_UTAPI_005815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005815",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005815", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005815", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005815", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005815", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005815", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005815", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005815", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005815", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005815", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005815", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005815", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005815")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005816")
    void case_UTAPI_005816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005816",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005816", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005816", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005816", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005816", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005816", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005816", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005816", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005816", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005816", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005816", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005816", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005816")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005817")
    void case_UTAPI_005817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005817",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005817", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005817", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005817", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005817", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005817", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005817", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005817", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005817", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005817", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005817", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005817", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005817")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005818")
    void case_UTAPI_005818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005818",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005818", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005818", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005818", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005818", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005818", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005818", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005818", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005818", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005818", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005818", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005818", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005818")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005819")
    void case_UTAPI_005819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005819",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005819", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005819", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005819", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005819", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005819", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005819", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005819", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005819", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005819", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005819", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005819", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005819")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005820")
    void case_UTAPI_005820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005820",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005820", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005820", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005820", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005820", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005820", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005820", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005820", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005820", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005820", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005820", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005820", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005820")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005821")
    void case_UTAPI_005821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005821",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005821", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005821", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005821", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005821", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005821", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005821", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005821", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005821", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005821", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005821", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005821", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005821")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005822")
    void case_UTAPI_005822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005822",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005822", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005822", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005822", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005822", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005822", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005822", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005822", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005822", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005822", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005822", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005822", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005822")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005823")
    void case_UTAPI_005823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005823",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005823", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005823", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005823", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005823", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005823", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005823", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005823", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005823", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005823", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005823", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005823", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005823")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005824")
    void case_UTAPI_005824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005824",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005824", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005824", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005824", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005824", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005824", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005824", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005824", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005824", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005824", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005824", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005824", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005824")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005825")
    void case_UTAPI_005825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005825",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005825", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005825", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005825", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005825", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005825", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005825", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005825", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005825", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005825", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005825", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005825", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005825")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005826")
    void case_UTAPI_005826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005826",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005826", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005826", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005826", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005826", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005826", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005826", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005826", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005826", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005826", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005826", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005826", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005826")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005827")
    void case_UTAPI_005827() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005827",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005827", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005827", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005827", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005827", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005827", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005827", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005827", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005827", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005827", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005827", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005827", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005827")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005828")
    void case_UTAPI_005828() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005828",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005828", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005828", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005828", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005828", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005828", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005828", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005828", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005828", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005828", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005828", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005828", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005828")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005829")
    void case_UTAPI_005829() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005829",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005829", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005829", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005829", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005829", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005829", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005829", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005829", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005829", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005829", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005829", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005829", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005829")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005830")
    void case_UTAPI_005830() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005830",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005830", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005830", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005830", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005830", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005830", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005830", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005830", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005830", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005830", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005830", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005830", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005830")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005831")
    void case_UTAPI_005831() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005831",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005831", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005831", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005831", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005831", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005831", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005831", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005831", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005831", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005831", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005831", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005831", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005831")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005832")
    void case_UTAPI_005832() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005832",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "findStaleTables",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005832", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005832", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005832", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005832", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005832", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005832", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005832", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005832", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005832", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005832", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005832", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005832")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::findStaleTables::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

}

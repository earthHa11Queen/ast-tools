package com.matsushita.dbeditor.utils;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Arguments handed to the SUT together with the value obtained for every dataId,
 * so the Oracle can express its expected condition in terms of the Case own input.
 */
public final class Arguments {

    private final Object[] values;
    private final Map<String, Object> byDataId;

    public Arguments(Object[] values, Map<String, Object> byDataId) {
        this.values = values;
        this.byDataId = Collections.unmodifiableMap(new LinkedHashMap<String, Object>(byDataId));
    }

    public Object[] values() {
        return values;
    }

    public Object arg(int index) {
        if (index >= 0 && index < values.length) {
            return values[index];
        }
        throw new HarnessException("Argument index out of range: " + index);
    }

    public boolean hasDataId(String dataId) {
        return byDataId.containsKey(dataId);
    }

    public Object value(String dataId) {
        if (!byDataId.containsKey(dataId)) {
            throw new HarnessException("No value assembled for dataId " + dataId);
        }
        return byDataId.get(dataId);
    }

    public Map<String, Object> all() {
        return byDataId;
    }
}

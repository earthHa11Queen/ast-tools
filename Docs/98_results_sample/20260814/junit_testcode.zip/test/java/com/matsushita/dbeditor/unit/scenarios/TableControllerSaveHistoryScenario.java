package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#saveHistory.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerSaveHistoryScenario {

    @Test
    @DisplayName("UTAPI-001629")
    void case_UTAPI_001629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001629",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001629", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001629", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001629", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001629", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001629", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001629", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001629", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001629", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001629")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001630")
    void case_UTAPI_001630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001630",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001630", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001630", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001630", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001630", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001630", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001630", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001630", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001630", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001630")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001631")
    void case_UTAPI_001631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001631",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001631", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001631", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001631", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001631", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001631", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001631", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001631", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001631", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001631")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001632")
    void case_UTAPI_001632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001632",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001632", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001632", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001632", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001632", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001632", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001632", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001632", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001632", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001632")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001633")
    void case_UTAPI_001633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001633",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001633", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001633", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001633", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001633", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001633", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001633", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001633", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001633", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001633")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001634")
    void case_UTAPI_001634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001634",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001634", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001634", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001634", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001634", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001634", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001634", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001634", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001634", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001634")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001635")
    void case_UTAPI_001635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001635",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001635", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001635", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001635", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001635", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001635", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001635", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001635", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001635", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001635")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001636")
    void case_UTAPI_001636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001636",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001636", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001636", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001636", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001636", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001636", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001636", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001636", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001636", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001636")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001637")
    void case_UTAPI_001637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001637",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001637", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001637", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001637", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001637", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001637", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001637", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001637", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001637", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001637")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001638")
    void case_UTAPI_001638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001638",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001638", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001638", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001638", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001638", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001638", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001638", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001638", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001638", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001638")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001639")
    void case_UTAPI_001639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001639",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001639", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001639", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001639", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001639", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001639", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001639", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001639", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001639", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001639")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001640")
    void case_UTAPI_001640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001640",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001640", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001640", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001640", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001640", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001640", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001640", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001640", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001640", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001640")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001641")
    void case_UTAPI_001641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001641",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001641", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001641", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001641", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001641", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001641", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001641", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001641", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001641", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001641")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001642")
    void case_UTAPI_001642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001642",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001642", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001642", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001642", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001642", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001642", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001642", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001642", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001642", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001642")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001643")
    void case_UTAPI_001643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001643",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001643", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001643", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001643", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001643", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001643", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001643", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001643", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001643", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001643")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001644")
    void case_UTAPI_001644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001644",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001644", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001644", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001644", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001644", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001644", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001644", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001644", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001644", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001644")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001645")
    void case_UTAPI_001645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001645",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001645", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001645", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001645", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001645", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001645", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001645", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001645", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001645", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001645")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001646")
    void case_UTAPI_001646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001646",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001646", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001646", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001646", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001646", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001646", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001646", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001646", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001646", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001646")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001647")
    void case_UTAPI_001647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001647",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001647", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001647", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001647", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001647", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001647", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001647", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001647", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001647", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001647")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001648")
    void case_UTAPI_001648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001648",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001648", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001648", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001648", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001648", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001648", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001648", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001648", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001648", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001648")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001649")
    void case_UTAPI_001649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001649",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001649", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001649", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001649", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001649", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001649", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001649", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001649", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001649", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001649")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001650")
    void case_UTAPI_001650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001650",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001650", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001650", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001650", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001650", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001650", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001650", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001650", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001650", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001650")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.connectionId classifies this input condition", "TableHistorySaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001651")
    void case_UTAPI_001651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001651",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001651", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001651", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001651", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001651", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001651", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001651", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001651", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001651", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001651")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.connectionId classifies this input condition", "TableHistorySaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001652")
    void case_UTAPI_001652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001652",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001652", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001652", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001652", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001652", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001652", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001652", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001652", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001652", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001652")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.connectionId classifies this input condition", "TableHistorySaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001653")
    void case_UTAPI_001653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001653",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001653", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001653", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001653", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001653", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001653", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001653", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001653", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001653", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001653")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.connectionId classifies this input condition", "TableHistorySaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001654")
    void case_UTAPI_001654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001654",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001654", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001654", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001654", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001654", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001654", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001654", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001654", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001654", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001654")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.connectionId classifies this input condition", "TableHistorySaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001655")
    void case_UTAPI_001655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001655",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001655", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001655", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001655", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001655", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001655", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001655", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001655", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001655", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001655")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.connectionId classifies this input condition", "TableHistorySaveRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001656")
    void case_UTAPI_001656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001656",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001656", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001656", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001656", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001656", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001656", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001656", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001656", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001656", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001656")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001657")
    void case_UTAPI_001657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001657",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001657", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001657", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001657", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001657", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001657", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001657", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001657", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001657", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001657")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001658")
    void case_UTAPI_001658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001658",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001658", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001658", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001658", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001658", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001658", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001658", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001658", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001658", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001658")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001659")
    void case_UTAPI_001659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001659",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001659", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001659", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001659", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001659", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001659", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001659", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001659", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001659", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001659")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "TableHistorySaveRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001660")
    void case_UTAPI_001660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001660",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001660", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001660", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001660", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001660", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001660", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001660", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001660", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001660", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001660")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::records")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.records", "TableHistorySaveRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.records classifies this input condition", "TableHistorySaveRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001661")
    void case_UTAPI_001661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001661",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001661", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001661", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001661", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001661", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001661", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001661", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001661", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001661", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001661")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::records")
                    .mirror("-", "3:length_min", "-")
                    .target("request.records", "TableHistorySaveRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.records classifies this input condition", "TableHistorySaveRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001662")
    void case_UTAPI_001662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001662",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001662", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001662", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001662", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001662", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001662", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001662", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001662", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001662", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001662")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::records")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.records", "TableHistorySaveRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.records classifies this input condition", "TableHistorySaveRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001663")
    void case_UTAPI_001663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001663",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001663", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001663", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001663", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001663", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001663", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001663", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001663", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001663", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001663")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::records")
                    .mirror("-", "5:length_max", "-")
                    .target("request.records", "TableHistorySaveRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.records classifies this input condition", "TableHistorySaveRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001664")
    void case_UTAPI_001664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001664",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001664", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001664", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001664", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001664", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001664", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001664", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001664", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001664", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001664")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::records")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.records", "TableHistorySaveRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.records classifies this input condition", "TableHistorySaveRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001665")
    void case_UTAPI_001665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001665",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001665", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001665", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001665", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001665", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001665", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001665", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001665", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001665", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001665")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::records")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.records", "TableHistorySaveRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableHistorySaveRequest.records classifies this input condition", "TableHistorySaveRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001666")
    void case_UTAPI_001666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001666",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001666", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001666", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001666", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001666", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001666", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001666", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001666", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001666", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001666")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001667")
    void case_UTAPI_001667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001667",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001667", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001667", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001667", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001667", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001667", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001667", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001667", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001667", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001667")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001668")
    void case_UTAPI_001668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001668",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001668", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001668", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001668", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001668", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001668", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001668", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001668", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001668", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001668")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001669")
    void case_UTAPI_001669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001669",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001669", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001669", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001669", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001669", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001669", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001669", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001669", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001669", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001669")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001670")
    void case_UTAPI_001670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001670",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001670", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001670", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001670", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001670", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001670", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001670", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001670", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001670", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001670")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001671")
    void case_UTAPI_001671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001671",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001671", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001671", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001671", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001671", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001671", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001671", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001671", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001671", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001671")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001672")
    void case_UTAPI_001672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001672",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001672", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001672", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001672", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001672", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001672", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001672", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001672", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001672", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001672")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001673")
    void case_UTAPI_001673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001673",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001673", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001673", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001673", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001673", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001673", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001673", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001673", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001673", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001673")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001674")
    void case_UTAPI_001674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001674",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001674", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001674", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001674", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001674", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001674", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001674", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001674", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001674", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001674")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001675")
    void case_UTAPI_001675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001675",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001675", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001675", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001675", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001675", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001675", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001675", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001675", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001675", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001675")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001676")
    void case_UTAPI_001676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001676",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001676", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001676", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001676", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001676", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001676", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001676", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001676", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001676", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001676")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001677")
    void case_UTAPI_001677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001677",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001677", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001677", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001677", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001677", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001677", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001677", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001677", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001677", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001677")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001678")
    void case_UTAPI_001678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001678",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001678", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001678", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001678", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001678", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001678", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001678", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001678", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001678", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001678")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001679")
    void case_UTAPI_001679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001679",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001679", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001679", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001679", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001679", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001679", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001679", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001679", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001679", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001679")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001680")
    void case_UTAPI_001680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001680",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001680", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001680", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001680", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001680", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001680", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001680", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001680", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001680", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001680")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001681")
    void case_UTAPI_001681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001681",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001681", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001681", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001681", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001681", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001681", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001681", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001681", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001681", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001681")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001682")
    void case_UTAPI_001682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001682",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001682", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001682", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001682", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001682", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001682", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001682", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001682", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001682", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001682")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001683")
    void case_UTAPI_001683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001683",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001683", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001683", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001683", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001683", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001683", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001683", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001683", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001683", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001683")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001684")
    void case_UTAPI_001684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001684",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001684", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001684", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001684", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001684", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001684", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001684", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001684", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001684", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001684")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001685")
    void case_UTAPI_001685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001685",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001685", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001685", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001685", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001685", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001685", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001685", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001685", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001685", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001685")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001686")
    void case_UTAPI_001686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001686",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "saveHistory",
                "ResponseEntity<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableHistorySaveRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001686", "request", "NORMAL", "OBJECT", "TableHistorySaveRequest"),
                    new DataRef("UTAPI-001686", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001686", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001686", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001686", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001686", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001686", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001686", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001686")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::saveHistory::7::FIELD::2::TableHistorySaveRequest::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.schemaName", "TableHistorySaveRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableHistoryUseCase.saveHistory")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryUseCase.saveHistory", "tableHistoryUseCase", "saveHistory")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableHistoryUseCase.saveHistory must carry the value generated for request.connectionId", "tableHistoryUseCase", "saveHistory", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryUseCase.saveHistory must carry the value generated for request.schemaName", "tableHistoryUseCase", "saveHistory", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryUseCase.saveHistory must carry the value generated for name", "tableHistoryUseCase", "saveHistory", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryUseCase.saveHistory must carry the value generated for request.records", "tableHistoryUseCase", "saveHistory", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

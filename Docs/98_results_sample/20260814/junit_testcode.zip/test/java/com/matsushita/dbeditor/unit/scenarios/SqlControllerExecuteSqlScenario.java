package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlController#executeSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlControllerExecuteSqlScenario {

    @Test
    @DisplayName("UTAPI-000995")
    void case_UTAPI_000995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000995",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000995", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-000995", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000995", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000995")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlExecuteRequest.connectionId classifies this input condition", "SqlExecuteRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000996")
    void case_UTAPI_000996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000996",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000996", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-000996", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000996", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000996")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlExecuteRequest.connectionId classifies this input condition", "SqlExecuteRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000997")
    void case_UTAPI_000997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000997",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000997", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-000997", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000997", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000997")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlExecuteRequest.connectionId classifies this input condition", "SqlExecuteRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000998")
    void case_UTAPI_000998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000998",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000998", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-000998", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000998", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000998")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlExecuteRequest.connectionId classifies this input condition", "SqlExecuteRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000999")
    void case_UTAPI_000999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000999",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000999", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-000999", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000999", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000999")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlExecuteRequest.connectionId classifies this input condition", "SqlExecuteRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001000")
    void case_UTAPI_001000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001000",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001000", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001000", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001000", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001000")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of SqlExecuteRequest.connectionId classifies this input condition", "SqlExecuteRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001001")
    void case_UTAPI_001001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001001",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001001", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001001", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001001", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001001")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001002")
    void case_UTAPI_001002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001002",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001002", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001002", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001002", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001002")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001003")
    void case_UTAPI_001003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001003",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001003", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001003", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001003", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001003")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001004")
    void case_UTAPI_001004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001004",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001004", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001004", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001004", "request.sql", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001004")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "SqlExecuteRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001005")
    void case_UTAPI_001005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001005",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001005", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001005", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001005", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001005")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of SqlExecuteRequest.sql classifies this input condition", "SqlExecuteRequest", "sql", "NotBlank", "data:request.sql")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001006")
    void case_UTAPI_001006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001006",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001006", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001006", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001006", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001006")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "3:length_min", "-")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001007")
    void case_UTAPI_001007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001007",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001007", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001007", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001007", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001007")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001008")
    void case_UTAPI_001008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001008",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001008", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001008", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001008", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001008")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "5:length_max", "-")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001009")
    void case_UTAPI_001009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001009",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001009", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001009", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001009", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001009")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001010")
    void case_UTAPI_001010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001010",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001010", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001010", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001010", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001010")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001011")
    void case_UTAPI_001011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001011",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001011", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001011", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001011", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001011")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001012")
    void case_UTAPI_001012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001012",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001012", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001012", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001012", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001012")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001013")
    void case_UTAPI_001013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001013",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001013", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001013", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001013", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001013")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001014")
    void case_UTAPI_001014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001014",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001014", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001014", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001014", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001014")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001015")
    void case_UTAPI_001015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001015",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001015", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001015", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001015", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001015")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001016")
    void case_UTAPI_001016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001016",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001016", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001016", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001016", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001016")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "56:space")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001017")
    void case_UTAPI_001017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001017",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001017", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001017", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001017", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001017")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001018")
    void case_UTAPI_001018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001018",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001018", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001018", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001018", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001018")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001019")
    void case_UTAPI_001019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001019",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001019", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001019", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001019", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001019")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "59:tab")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001020")
    void case_UTAPI_001020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001020",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001020", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001020", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001020", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001020")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001021")
    void case_UTAPI_001021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001021",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001021", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001021", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001021", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001021")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001022")
    void case_UTAPI_001022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001022",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001022", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001022", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001022", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001022")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001023")
    void case_UTAPI_001023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001023",
                "com.matsushita.dbeditor.adapter.controller.SqlController",
                "executeSql",
                "ResponseEntity<SqlExecuteResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "SqlExecuteRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001023", "request", "NORMAL", "OBJECT", "SqlExecuteRequest"),
                    new DataRef("UTAPI-001023", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001023", "request.sql", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001023")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/SqlController.java::SqlController::executeSql::4::FIELD::1::SqlExecuteRequest::sql")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.sql", "SqlExecuteRequest.sql")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of sqlUseCase.executeSql")
                    .expected("the value generated for request.sql is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through sqlUseCase.executeSql", "sqlUseCase", "executeSql")
                    .check(CheckType.ARG_EQUALS, "argument 0 of sqlUseCase.executeSql must carry the value generated for request.connectionId", "sqlUseCase", "executeSql", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of sqlUseCase.executeSql must carry the value generated for request.sql", "sqlUseCase", "executeSql", "1", "data:request.sql")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlControllerWrapper());
    }

}

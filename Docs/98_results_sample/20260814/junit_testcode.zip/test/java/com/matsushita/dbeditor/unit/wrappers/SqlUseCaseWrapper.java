package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for SqlUseCase.
 */
public final class SqlUseCaseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.usecase.sql.SqlUseCase";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.usecase.sql.SqlUseCase";
    private static final String[] DEP_NAMES = new String[] {"savedSqlRepository", "connectionSettingRepository", "connector"};
    private static final String[] DEP_TYPES = new String[] {"SavedSqlRepository", "ConnectionSettingRepository", "TargetDatabaseConnector"};
    private static final String[] TYPES_executeSql = new String[] {"Integer", "String"};
    private static final String[] TYPES_getSql = new String[] {"Integer"};
    private static final String[] TYPES_getSqlForDownload = new String[] {"Integer"};
    private static final String[] TYPES_listSql = new String[] {"Integer"};
    private static final String[] TYPES_saveSql = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_uploadSql = new String[] {"Integer", "String", "byte[]"};

    public SqlUseCaseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** SqlExecuteResponse executeSql(connectionId, sql) */
    public ExecutionResult executeSql(Object[] args) {
        return invoke("executeSql", TYPES_executeSql, args);
    }

    /** SqlResponse getSql(n) */
    public ExecutionResult getSql(Object[] args) {
        return invoke("getSql", TYPES_getSql, args);
    }

    /** SavedSql getSqlForDownload(n) */
    public ExecutionResult getSqlForDownload(Object[] args) {
        return invoke("getSqlForDownload", TYPES_getSqlForDownload, args);
    }

    /** List<SqlResponse> listSql(connectionId) */
    public ExecutionResult listSql(Object[] args) {
        return invoke("listSql", TYPES_listSql, args);
    }

    /** SqlResponse saveSql(connectionId, title, content) */
    public ExecutionResult saveSql(Object[] args) {
        return invoke("saveSql", TYPES_saveSql, args);
    }

    /** SqlResponse uploadSql(connectionId, filename, bytes) */
    public ExecutionResult uploadSql(Object[] args) {
        return invoke("uploadSql", TYPES_uploadSql, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("executeSql".equals(operation)) {
            return executeSql(args);
        } else if ("getSql".equals(operation)) {
            return getSql(args);
        } else if ("getSqlForDownload".equals(operation)) {
            return getSqlForDownload(args);
        } else if ("listSql".equals(operation)) {
            return listSql(args);
        } else if ("saveSql".equals(operation)) {
            return saveSql(args);
        } else if ("uploadSql".equals(operation)) {
            return uploadSql(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

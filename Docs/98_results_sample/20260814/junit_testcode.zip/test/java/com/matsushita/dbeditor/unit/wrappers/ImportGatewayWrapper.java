package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for ImportGateway.
 */
public final class ImportGatewayWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.gateway.ImportGateway";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.gateway.ImportGateway";
    private static final String[] DEP_NAMES = new String[] {"targetDatabaseConnector"};
    private static final String[] DEP_TYPES = new String[] {"TargetDatabaseConnector"};
    private static final String[] TYPES_createTableAndInsert = new String[] {"ConnectionSetting", "String", "String", "List<String>", "List<String>", "List<Map<String, Object>>"};
    private static final String[] TYPES_findColumnNames = new String[] {"ConnectionSetting", "String", "String"};
    private static final String[] TYPES_insertIntoCopyTable = new String[] {"ConnectionSetting", "String", "String", "List<String>", "List<Map<String, Object>>"};
    private static final String[] TYPES_sanitizeType = new String[] {"String"};

    public ImportGatewayWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** void createTableAndInsert(setting, schemaName, tableName, columns, columnTypes, rows) */
    public ExecutionResult createTableAndInsert(Object[] args) {
        return invoke("createTableAndInsert", TYPES_createTableAndInsert, args);
    }

    /** List<String> findColumnNames(setting, schemaName, tableName) */
    public ExecutionResult findColumnNames(Object[] args) {
        return invoke("findColumnNames", TYPES_findColumnNames, args);
    }

    /** void insertIntoCopyTable(setting, schemaName, tableName, columns, rows) */
    public ExecutionResult insertIntoCopyTable(Object[] args) {
        return invoke("insertIntoCopyTable", TYPES_insertIntoCopyTable, args);
    }

    /** String sanitizeType(type) */
    public ExecutionResult sanitizeType(Object[] args) {
        return invoke("sanitizeType", TYPES_sanitizeType, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("createTableAndInsert".equals(operation)) {
            return createTableAndInsert(args);
        } else if ("findColumnNames".equals(operation)) {
            return findColumnNames(args);
        } else if ("insertIntoCopyTable".equals(operation)) {
            return insertIntoCopyTable(args);
        } else if ("sanitizeType".equals(operation)) {
            return sanitizeType(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

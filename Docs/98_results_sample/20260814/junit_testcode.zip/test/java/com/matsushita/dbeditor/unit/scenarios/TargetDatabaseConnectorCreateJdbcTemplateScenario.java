package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TargetDatabaseConnectorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TargetDatabaseConnector#createJdbcTemplate.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TargetDatabaseConnectorCreateJdbcTemplateScenario {

    @Test
    @DisplayName("UTAPI-011351")
    void case_UTAPI_011351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011351",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011351", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011351", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011351", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011351", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011351", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011351", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011351", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011351", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011351", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011351", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011351")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011352")
    void case_UTAPI_011352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011352",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011352", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011352", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011352", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011352", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011352", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011352", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011352", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011352", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011352", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011352", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011352")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011353")
    void case_UTAPI_011353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011353",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011353", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011353", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011353", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011353", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011353", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011353", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011353", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011353", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011353", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011353", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011353")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011354")
    void case_UTAPI_011354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011354",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011354", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011354", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011354", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011354", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011354", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011354", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011354", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011354", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011354", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011354", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011354")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011355")
    void case_UTAPI_011355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011355",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011355", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011355", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011355", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011355", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011355", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011355", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011355", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011355", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011355", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011355", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011355")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011356")
    void case_UTAPI_011356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011356",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011356", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011356", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011356", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011356", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011356", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011356", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011356", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011356", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011356", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011356", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011356")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011357")
    void case_UTAPI_011357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011357",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011357", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011357", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011357", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011357", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011357", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011357", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011357", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011357", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011357", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011357", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011357")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011358")
    void case_UTAPI_011358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011358",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011358", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011358", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011358", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011358", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011358", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011358", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011358", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011358", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011358", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011358", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011358")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on createdTimestamp", "setting", "createdTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011359")
    void case_UTAPI_011359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011359",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011359", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011359", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011359", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011359", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011359", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011359", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011359", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011359", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011359", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011359", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011359")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011360")
    void case_UTAPI_011360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011360",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011360", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011360", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011360", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011360", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011360", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011360", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011360", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011360", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011360", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011360", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011360")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011361")
    void case_UTAPI_011361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011361",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011361", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011361", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011361", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011361", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011361", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011361", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011361", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011361", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011361", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011361", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011361")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011362")
    void case_UTAPI_011362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011362",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011362", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011362", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011362", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011362", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011362", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011362", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011362", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011362", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011362", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011362", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011362")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011363")
    void case_UTAPI_011363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011363",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011363", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011363", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011363", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011363", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011363", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011363", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011363", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011363", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011363", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011363", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011363")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011364")
    void case_UTAPI_011364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011364",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011364", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011364", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011364", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011364", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011364", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011364", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011364", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011364", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011364", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011364", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011364")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011365")
    void case_UTAPI_011365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011365",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011365", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011365", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011365", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011365", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011365", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011365", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011365", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011365", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011365", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011365", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011365")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011366")
    void case_UTAPI_011366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011366",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011366", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011366", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011366", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011366", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011366", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011366", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011366", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011366", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011366", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011366", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011366")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011367")
    void case_UTAPI_011367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011367",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011367", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011367", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011367", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011367", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011367", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011367", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011367", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011367", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011367", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011367", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011367")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011368")
    void case_UTAPI_011368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011368",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011368", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011368", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011368", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011368", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011368", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011368", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011368", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011368", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011368", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011368", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011368")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011369")
    void case_UTAPI_011369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011369",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011369", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011369", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011369", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011369", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011369", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011369", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011369", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011369", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011369", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011369", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011369")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011370")
    void case_UTAPI_011370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011370",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011370", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011370", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011370", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011370", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011370", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011370", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011370", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011370", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011370", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011370", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011370")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011371")
    void case_UTAPI_011371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011371",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011371", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011371", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011371", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011371", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011371", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011371", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011371", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011371", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011371", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011371", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011371")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011372")
    void case_UTAPI_011372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011372",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011372", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011372", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011372", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011372", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011372", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011372", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011372", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011372", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011372", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011372", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011372")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011373")
    void case_UTAPI_011373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011373",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011373", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011373", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011373", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011373", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011373", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011373", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011373", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011373", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011373", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011373", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011373")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011374")
    void case_UTAPI_011374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011374",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011374", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011374", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011374", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011374", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011374", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011374", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011374", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011374", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011374", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011374", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011374")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011375")
    void case_UTAPI_011375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011375",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011375", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011375", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011375", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011375", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011375", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011375", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011375", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011375", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011375", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011375", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011375")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011376")
    void case_UTAPI_011376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011376",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011376", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011376", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011376", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011376", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011376", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011376", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011376", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011376", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011376", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011376", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011376")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011377")
    void case_UTAPI_011377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011377",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011377", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011377", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011377", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011377", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011377", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011377", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011377", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011377", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011377", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011377", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011377")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011378")
    void case_UTAPI_011378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011378",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011378", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011378", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011378", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011378", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011378", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011378", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011378", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011378", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011378", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011378", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011378")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011379")
    void case_UTAPI_011379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011379",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011379", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011379", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011379", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011379", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011379", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011379", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011379", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011379", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011379", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011379", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011379")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011380")
    void case_UTAPI_011380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011380",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011380", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011380", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011380", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011380", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011380", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011380", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011380", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011380", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011380", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011380", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011380")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011381")
    void case_UTAPI_011381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011381",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011381", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011381", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011381", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011381", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011381", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011381", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011381", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011381", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011381", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011381", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011381")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011382")
    void case_UTAPI_011382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011382",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011382", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011382", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011382", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011382", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011382", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011382", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011382", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011382", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011382", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011382", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011382")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011383")
    void case_UTAPI_011383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011383",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011383", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011383", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011383", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011383", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011383", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011383", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011383", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011383", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011383", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011383", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011383")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011384")
    void case_UTAPI_011384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011384",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011384", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011384", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011384", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011384", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011384", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011384", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011384", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011384", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011384", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011384", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011384")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011385")
    void case_UTAPI_011385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011385",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011385", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011385", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011385", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011385", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011385", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011385", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011385", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011385", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011385", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011385", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011385")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011386")
    void case_UTAPI_011386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011386",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011386", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011386", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011386", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011386", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011386", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011386", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011386", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011386", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011386", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011386", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011386")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011387")
    void case_UTAPI_011387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011387",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011387", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011387", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011387", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011387", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011387", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011387", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011387", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011387", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011387", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011387", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011387")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011388")
    void case_UTAPI_011388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011388",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011388", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011388", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011388", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011388", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011388", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011388", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011388", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011388", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011388", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011388", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011388")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011389")
    void case_UTAPI_011389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011389",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011389", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011389", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011389", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011389", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011389", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011389", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011389", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011389", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011389", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011389", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011389")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011390")
    void case_UTAPI_011390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011390",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011390", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011390", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011390", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011390", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011390", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011390", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011390", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011390", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011390", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011390", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011390")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011391")
    void case_UTAPI_011391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011391",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011391", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011391", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011391", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011391", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011391", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011391", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011391", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011391", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011391", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011391", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011391")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011392")
    void case_UTAPI_011392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011392",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011392", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011392", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011392", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011392", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011392", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011392", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011392", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011392", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011392", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011392", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011392")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011393")
    void case_UTAPI_011393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011393",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011393", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011393", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011393", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011393", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011393", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011393", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011393", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011393", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011393", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011393", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011393")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011394")
    void case_UTAPI_011394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011394",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011394", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011394", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011394", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011394", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011394", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011394", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011394", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011394", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011394", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011394", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011394")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011395")
    void case_UTAPI_011395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011395",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011395", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011395", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011395", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011395", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011395", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011395", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011395", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011395", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011395", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011395", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011395")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011396")
    void case_UTAPI_011396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011396",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011396", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011396", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011396", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011396", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011396", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011396", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011396", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011396", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011396", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011396", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011396")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011397")
    void case_UTAPI_011397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011397",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011397", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011397", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011397", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011397", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011397", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011397", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011397", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011397", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011397", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011397", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011397")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011398")
    void case_UTAPI_011398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011398",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011398", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011398", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011398", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011398", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011398", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011398", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011398", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011398", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011398", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011398", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011398")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011399")
    void case_UTAPI_011399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011399",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011399", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011399", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011399", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011399", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011399", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011399", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011399", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011399", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011399", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011399", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011399")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011400")
    void case_UTAPI_011400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011400",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011400", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011400", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011400", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011400", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011400", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011400", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011400", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011400", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011400", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011400", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011400")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011401")
    void case_UTAPI_011401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011401",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011401", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011401", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011401", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011401", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011401", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011401", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011401", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011401", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011401", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011401", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011401")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011402")
    void case_UTAPI_011402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011402",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011402", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011402", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011402", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011402", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011402", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011402", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011402", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011402", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011402", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011402", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011402")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011403")
    void case_UTAPI_011403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011403",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011403", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011403", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011403", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011403", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011403", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011403", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011403", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011403", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011403", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011403", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011403")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011404")
    void case_UTAPI_011404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011404",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011404", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011404", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011404", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011404", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011404", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011404", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011404", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011404", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011404", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011404", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011404")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011405")
    void case_UTAPI_011405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011405",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011405", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011405", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011405", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011405", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011405", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011405", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011405", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011405", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011405", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011405", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011405")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011406")
    void case_UTAPI_011406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011406",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011406", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011406", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011406", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011406", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011406", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011406", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011406", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011406", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011406", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011406", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011406")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011407")
    void case_UTAPI_011407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011407",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011407", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011407", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011407", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011407", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011407", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011407", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011407", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011407", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011407", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011407", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011407")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011408")
    void case_UTAPI_011408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011408",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011408", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011408", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011408", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011408", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011408", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011408", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011408", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011408", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011408", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011408", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011408")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011409")
    void case_UTAPI_011409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011409",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011409", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011409", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011409", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011409", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011409", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011409", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011409", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011409", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011409", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011409", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011409")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011410")
    void case_UTAPI_011410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011410",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011410", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011410", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011410", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011410", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011410", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011410", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011410", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011410", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011410", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011410", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011410")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011411")
    void case_UTAPI_011411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011411",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011411", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011411", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011411", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011411", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011411", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011411", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011411", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011411", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011411", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011411", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011411")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011412")
    void case_UTAPI_011412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011412",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011412", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011412", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011412", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011412", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011412", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011412", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011412", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011412", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011412", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011412", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011412")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011413")
    void case_UTAPI_011413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011413",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011413", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011413", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011413", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011413", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011413", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011413", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011413", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011413", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011413", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011413", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011413")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011414")
    void case_UTAPI_011414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011414",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011414", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011414", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011414", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011414", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011414", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011414", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011414", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011414", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011414", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011414", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011414")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011415")
    void case_UTAPI_011415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011415",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011415", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011415", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011415", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011415", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011415", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011415", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011415", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011415", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011415", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011415", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011415")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011416")
    void case_UTAPI_011416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011416",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011416", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011416", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011416", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011416", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011416", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011416", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011416", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011416", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011416", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011416", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011416")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011417")
    void case_UTAPI_011417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011417",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011417", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011417", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011417", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011417", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011417", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011417", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011417", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011417", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011417", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011417", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011417")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011418")
    void case_UTAPI_011418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011418",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011418", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011418", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011418", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011418", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011418", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011418", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011418", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011418", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011418", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011418", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011418")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011419")
    void case_UTAPI_011419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011419",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011419", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011419", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011419", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011419", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011419", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011419", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011419", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011419", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011419", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011419", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011419")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011420")
    void case_UTAPI_011420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011420",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011420", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011420", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011420", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011420", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011420", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011420", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011420", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011420", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011420", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011420", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011420")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbName", "setting", "dbName", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011421")
    void case_UTAPI_011421() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011421",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011421", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011421", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011421", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011421", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011421", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011421", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011421", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011421", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011421", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011421", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011421")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011422")
    void case_UTAPI_011422() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011422",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011422", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011422", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011422", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011422", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011422", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011422", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011422", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011422", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011422", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011422", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011422")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011423")
    void case_UTAPI_011423() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011423",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011423", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011423", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011423", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011423", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011423", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011423", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011423", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011423", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011423", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011423", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011423")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011424")
    void case_UTAPI_011424() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011424",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011424", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011424", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011424", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011424", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011424", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011424", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011424", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011424", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011424", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011424", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011424")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011425")
    void case_UTAPI_011425() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011425",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011425", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011425", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011425", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011425", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011425", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011425", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011425", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011425", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011425", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011425", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011425")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011426")
    void case_UTAPI_011426() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011426",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011426", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011426", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011426", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011426", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011426", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011426", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011426", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011426", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011426", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011426", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011426")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011427")
    void case_UTAPI_011427() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011427",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011427", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011427", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011427", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011427", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011427", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011427", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011427", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011427", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011427", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011427", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011427")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011428")
    void case_UTAPI_011428() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011428",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011428", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011428", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011428", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011428", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011428", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011428", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011428", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011428", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011428", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011428", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011428")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011429")
    void case_UTAPI_011429() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011429",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011429", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011429", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011429", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011429", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011429", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011429", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011429", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011429", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011429", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011429", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011429")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011430")
    void case_UTAPI_011430() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011430",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011430", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011430", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011430", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011430", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011430", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011430", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011430", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011430", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011430", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011430", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011430")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011431")
    void case_UTAPI_011431() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011431",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011431", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011431", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011431", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011431", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011431", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011431", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011431", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011431", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011431", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011431", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011431")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011432")
    void case_UTAPI_011432() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011432",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011432", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011432", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011432", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011432", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011432", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011432", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011432", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011432", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011432", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011432", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011432")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011433")
    void case_UTAPI_011433() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011433",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011433", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011433", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011433", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011433", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011433", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011433", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011433", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011433", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011433", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011433", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011433")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011434")
    void case_UTAPI_011434() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011434",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011434", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011434", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011434", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011434", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011434", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011434", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011434", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011434", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011434", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011434", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011434")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011435")
    void case_UTAPI_011435() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011435",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011435", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011435", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011435", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011435", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011435", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011435", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011435", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011435", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011435", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011435", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011435")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011436")
    void case_UTAPI_011436() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011436",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011436", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011436", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011436", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011436", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011436", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011436", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011436", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011436", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011436", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011436", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011436")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011437")
    void case_UTAPI_011437() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011437",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011437", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011437", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011437", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011437", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011437", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011437", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011437", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011437", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011437", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011437", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011437")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011438")
    void case_UTAPI_011438() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011438",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011438", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011438", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011438", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011438", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011438", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011438", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011438", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011438", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011438", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011438", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011438")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011439")
    void case_UTAPI_011439() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011439",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011439", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011439", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011439", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011439", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011439", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011439", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011439", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011439", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011439", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011439", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011439")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011440")
    void case_UTAPI_011440() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011440",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011440", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011440", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011440", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011440", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011440", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011440", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011440", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011440", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011440", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011440", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011440")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on dbPassword", "setting", "dbPassword", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011441")
    void case_UTAPI_011441() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011441",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011441", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011441", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011441", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011441", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011441", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011441", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011441", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011441", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011441", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011441", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011441")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011442")
    void case_UTAPI_011442() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011442",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011442", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011442", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011442", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011442", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011442", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011442", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011442", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011442", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011442", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011442", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011442")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011443")
    void case_UTAPI_011443() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011443",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011443", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011443", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011443", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011443", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011443", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011443", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011443", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011443", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011443", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011443", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011443")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011444")
    void case_UTAPI_011444() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011444",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011444", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011444", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011444", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011444", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011444", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011444", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011444", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011444", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011444", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011444", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011444")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011445")
    void case_UTAPI_011445() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011445",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011445", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011445", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011445", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011445", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011445", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011445", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011445", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011445", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011445", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011445", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011445")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011446")
    void case_UTAPI_011446() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011446",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011446", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011446", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011446", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011446", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011446", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011446", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011446", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011446", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011446", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011446", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011446")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011447")
    void case_UTAPI_011447() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011447",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011447", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011447", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011447", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011447", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011447", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011447", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011447", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011447", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011447", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011447", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011447")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011448")
    void case_UTAPI_011448() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011448",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011448", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011448", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011448", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011448", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011448", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011448", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011448", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011448", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011448", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011448", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011448")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011449")
    void case_UTAPI_011449() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011449",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011449", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011449", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011449", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011449", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011449", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011449", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011449", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011449", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011449", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011449", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011449")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011450")
    void case_UTAPI_011450() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011450",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011450", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011450", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011450", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011450", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011450", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011450", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011450", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011450", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011450", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011450", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011450")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011451")
    void case_UTAPI_011451() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011451",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011451", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011451", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011451", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011451", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011451", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011451", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011451", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011451", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011451", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011451", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011451")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011452")
    void case_UTAPI_011452() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011452",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011452", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011452", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011452", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011452", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011452", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011452", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011452", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011452", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011452", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011452", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011452")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011453")
    void case_UTAPI_011453() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011453",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011453", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011453", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011453", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011453", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011453", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011453", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011453", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011453", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011453", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011453", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011453")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011454")
    void case_UTAPI_011454() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011454",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011454", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011454", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011454", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011454", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011454", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011454", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011454", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011454", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011454", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011454", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011454")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011455")
    void case_UTAPI_011455() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011455",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011455", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011455", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011455", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011455", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011455", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011455", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011455", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011455", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011455", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011455", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011455")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011456")
    void case_UTAPI_011456() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011456",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011456", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011456", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011456", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011456", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011456", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011456", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011456", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011456", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011456", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011456", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011456")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011457")
    void case_UTAPI_011457() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011457",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011457", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011457", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011457", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011457", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011457", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011457", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011457", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011457", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011457", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011457", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011457")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011458")
    void case_UTAPI_011458() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011458",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011458", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011458", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011458", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011458", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011458", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011458", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011458", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011458", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011458", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011458", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011458")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011459")
    void case_UTAPI_011459() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011459",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011459", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011459", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011459", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011459", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011459", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011459", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011459", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011459", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011459", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011459", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011459")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011460")
    void case_UTAPI_011460() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011460",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011460", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011460", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011460", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011460", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011460", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011460", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011460", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011460", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011460", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011460", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011460")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011461")
    void case_UTAPI_011461() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011461",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011461", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011461", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011461", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011461", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011461", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011461", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011461", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011461", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011461", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011461", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011461")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011462")
    void case_UTAPI_011462() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011462",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011462", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011462", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011462", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011462", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011462", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011462", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011462", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011462", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011462", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011462", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011462")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011463")
    void case_UTAPI_011463() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011463",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011463", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011463", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011463", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011463", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011463", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011463", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011463", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011463", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011463", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011463", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011463")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011464")
    void case_UTAPI_011464() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011464",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011464", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011464", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011464", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011464", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011464", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011464", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011464", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011464", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011464", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011464", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011464")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011465")
    void case_UTAPI_011465() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011465",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011465", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011465", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011465", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011465", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011465", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011465", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011465", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011465", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011465", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011465", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011465")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011466")
    void case_UTAPI_011466() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011466",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011466", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011466", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011466", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011466", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011466", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011466", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011466", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011466", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011466", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011466", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011466")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011467")
    void case_UTAPI_011467() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011467",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011467", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011467", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011467", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011467", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011467", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011467", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011467", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011467", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011467", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011467", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011467")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011468")
    void case_UTAPI_011468() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011468",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011468", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011468", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011468", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011468", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011468", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011468", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011468", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011468", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011468", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011468", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011468")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011469")
    void case_UTAPI_011469() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011469",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011469", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011469", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011469", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011469", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011469", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011469", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011469", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011469", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011469", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011469", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011469")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011470")
    void case_UTAPI_011470() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011470",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011470", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011470", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011470", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011470", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011470", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011470", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011470", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011470", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011470", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011470", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011470")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011471")
    void case_UTAPI_011471() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011471",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011471", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011471", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011471", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011471", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011471", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011471", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011471", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011471", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011471", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011471", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011471")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011472")
    void case_UTAPI_011472() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011472",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011472", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011472", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011472", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011472", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011472", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011472", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011472", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011472", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011472", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011472", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011472")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011473")
    void case_UTAPI_011473() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011473",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011473", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011473", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011473", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011473", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011473", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011473", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011473", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011473", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011473", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011473", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011473")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011474")
    void case_UTAPI_011474() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011474",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011474", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011474", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011474", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011474", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011474", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011474", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011474", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011474", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011474", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011474", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011474")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011475")
    void case_UTAPI_011475() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011475",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011475", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011475", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011475", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011475", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011475", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011475", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011475", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011475", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011475", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011475", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011475")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011476")
    void case_UTAPI_011476() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011476",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011476", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011476", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011476", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011476", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011476", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011476", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011476", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011476", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011476", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011476", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011476")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011477")
    void case_UTAPI_011477() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011477",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011477", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011477", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011477", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011477", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011477", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011477", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011477", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011477", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011477", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011477", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011477")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011478")
    void case_UTAPI_011478() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011478",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011478", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011478", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011478", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011478", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011478", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011478", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011478", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011478", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011478", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011478", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011478")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011479")
    void case_UTAPI_011479() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011479",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011479", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011479", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011479", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011479", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011479", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011479", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011479", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011479", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011479", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011479", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011479")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011480")
    void case_UTAPI_011480() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011480",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011480", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011480", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011480", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011480", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011480", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011480", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011480", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011480", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011480", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011480", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011480")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011481")
    void case_UTAPI_011481() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011481",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011481", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011481", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011481", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011481", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011481", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011481", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011481", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011481", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011481", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011481", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011481")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011482")
    void case_UTAPI_011482() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011482",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011482", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011482", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011482", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011482", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011482", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011482", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011482", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011482", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011482", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011482", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011482")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011483")
    void case_UTAPI_011483() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011483",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011483", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011483", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011483", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011483", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011483", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011483", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011483", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011483", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011483", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011483", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011483")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on n", "setting", "n", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011484")
    void case_UTAPI_011484() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011484",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011484", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011484", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011484", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011484", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011484", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011484", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011484", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011484", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011484", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011484", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011484")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011485")
    void case_UTAPI_011485() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011485",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011485", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011485", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011485", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011485", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011485", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011485", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011485", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011485", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011485", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011485", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011485")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011486")
    void case_UTAPI_011486() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011486",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011486", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011486", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011486", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011486", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011486", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011486", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011486", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011486", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011486", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011486", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011486")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011487")
    void case_UTAPI_011487() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011487",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011487", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011487", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011487", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011487", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011487", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011487", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011487", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011487", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011487", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011487", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011487")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011488")
    void case_UTAPI_011488() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011488",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011488", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011488", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011488", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011488", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011488", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011488", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011488", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011488", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011488", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011488", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011488")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011489")
    void case_UTAPI_011489() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011489",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011489", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011489", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011489", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011489", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011489", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011489", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011489", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011489", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011489", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011489", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011489")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011490")
    void case_UTAPI_011490() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011490",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011490", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011490", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011490", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011490", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011490", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011490", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011490", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011490", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011490", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011490", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011490")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

    @Test
    @DisplayName("UTAPI-011491")
    void case_UTAPI_011491() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011491",
                "com.matsushita.dbeditor.infrastructure.database.TargetDatabaseConnector",
                "createJdbcTemplate",
                "JdbcTemplate",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011491", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-011491", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-011491", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011491", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011491", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011491", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011491", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011491", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011491", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011491", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-011491")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TargetDatabaseConnector.java::TargetDatabaseConnector::createJdbcTemplate::1::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DATASOURCE_COMPOSITION)
                    .observation("the connection handle composed from the supplied ConnectionSetting")
                    .expected("host, port and database name of the settings appear in the composed JDBC url and the declared credentials are used")
                    .failure("a settings field is ignored, replaced by a default or written into the wrong part of the url")
                    .assertion("assertTrue(url.contains(field)) per field and assertEquals on the credentials")
                    .check(CheckType.RETURN_NOT_NULL, "the connector must produce a handle for the supplied settings")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbHost", "getDataSource.getUrl", "data:setting.dbHost")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain dbPort", "getDataSource.getUrl", "data:setting.dbPort")
                    .check(CheckType.RETURN_PATH_CONTAINS, "the template data source url must contain databaseName", "getDataSource.getUrl", "data:setting.databaseName")
                    .check(CheckType.RETURN_PATH_EQUALS, "the template data source must use the configured user", "getDataSource.getUsername", "data:setting.dbUsername")
                    .check(CheckType.RESULT_PATH_INDEPENDENT_OF, "the composed connection target must not depend on updatedTimestamp", "setting", "updatedTimestamp", "getDataSource.getUrl")
                    .check(CheckType.NO_EXCEPTION, "the connection settings must be accepted for this input condition")
                    .build()),
            new TargetDatabaseConnectorWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportUseCase#getExcelSheetNames.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportUseCaseGetExcelSheetNamesScenario {

    @Test
    @DisplayName("UTAPI-012533")
    void case_UTAPI_012533() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012533",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getExcelSheetNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012533", "file", "TARGET", "OBJECT", "MultipartFile")
                },
                OraclePlan.builder("UTAPI-012533")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getExcelSheetNames::2::ARG::1::-::file")
                    .mirror("-", "1:length_null", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.FILE_IMPORT_DELEGATION)
                    .observation("the outcome of reading sheet names from a missing upload")
                    .expected("the missing upload is rejected")
                    .failure("a missing upload is answered with a fabricated sheet list")
                    .assertion("assertThrows for the missing upload")
                    .check(CheckType.EXCEPTION_REQUIRED, "a missing upload cannot yield sheet names", "java.lang.Exception", "data:file")
                    .build()),
            new ImportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012534")
    void case_UTAPI_012534() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012534",
                "com.matsushita.dbeditor.usecase.file.ImportUseCase",
                "getExcelSheetNames",
                "List<String>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012534", "file", "TARGET", "OBJECT", "MultipartFile")
                },
                OraclePlan.builder("UTAPI-012534")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ImportUseCase.java::ImportUseCase::getExcelSheetNames::2::ARG::1::-::file")
                    .mirror("-", "2:length_empty", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.FILE_IMPORT_DELEGATION)
                    .observation("the sheet names read from the uploaded workbook")
                    .expected("the sheet names of the uploaded workbook are reported, or the upload is rejected as unreadable")
                    .failure("a sheet list is fabricated for an unreadable upload, or a readable workbook loses its sheet")
                    .assertion("assertTrue(names.contains(sheetName)) or rejection")
                    .check(CheckType.EXCEPTION_REQUIRED, "an upload that carries no workbook cannot yield sheet names", "java.lang.Exception", "data:file")
                    .build()),
            new ImportUseCaseWrapper());
    }

}

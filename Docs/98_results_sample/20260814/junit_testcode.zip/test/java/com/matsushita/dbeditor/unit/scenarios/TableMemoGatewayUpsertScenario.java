package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableMemoGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableMemoGateway#upsert.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableMemoGatewayUpsertScenario {

    @Test
    @DisplayName("UTAPI-004719")
    void case_UTAPI_004719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004719",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004719", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004719", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004719", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004719", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004719", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004719", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004719", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004719")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004720")
    void case_UTAPI_004720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004720",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004720", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004720", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004720", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004720", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004720", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004720", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004720", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004720")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004721")
    void case_UTAPI_004721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004721",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004721", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004721", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004721", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004721", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004721", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004721", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004721", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004721")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004722")
    void case_UTAPI_004722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004722",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004722", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004722", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004722", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004722", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004722", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004722", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004722", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004722")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004723")
    void case_UTAPI_004723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004723",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004723", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004723", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004723", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004723", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004723", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004723", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004723", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004723")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004724")
    void case_UTAPI_004724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004724",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004724", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004724", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004724", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004724", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004724", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004724", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004724", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004724")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004725")
    void case_UTAPI_004725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004725",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004725", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004725", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004725", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004725", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004725", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004725", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004725", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004725")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004726")
    void case_UTAPI_004726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004726",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004726", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004726", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004726", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004726", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004726", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004726", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004726", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004726")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004727")
    void case_UTAPI_004727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004727",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004727", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004727", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004727", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004727", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004727", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004727", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004727", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004727")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004728")
    void case_UTAPI_004728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004728",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004728", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004728", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004728", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004728", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004728", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004728", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004728", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004728")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004729")
    void case_UTAPI_004729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004729",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004729", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004729", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004729", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004729", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004729", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004729", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004729", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004729")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004730")
    void case_UTAPI_004730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004730",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004730", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004730", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004730", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004730", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004730", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004730", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004730", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004730")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004731")
    void case_UTAPI_004731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004731",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004731", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004731", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004731", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004731", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004731", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004731", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004731", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004731")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "56:space")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004732")
    void case_UTAPI_004732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004732",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004732", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004732", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004732", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004732", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004732", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004732", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004732", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004732")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004733")
    void case_UTAPI_004733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004733",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004733", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004733", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004733", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004733", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004733", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004733", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004733", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004733")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004734")
    void case_UTAPI_004734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004734",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004734", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004734", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004734", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004734", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004734", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004734", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004734", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004734")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "59:tab")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004735")
    void case_UTAPI_004735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004735",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004735", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004735", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004735", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004735", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004735", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004735", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004735", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004735")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "60:control_character_null")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004736")
    void case_UTAPI_004736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004736",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004736", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004736", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004736", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004736", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004736", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004736", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004736", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004736")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004737")
    void case_UTAPI_004737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004737",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004737", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004737", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004737", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004737", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004737", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004737", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004737", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004737")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004738")
    void case_UTAPI_004738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004738",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004738", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004738", "memo.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004738", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004738", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004738", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004738", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004738", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004738")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::contentMemo")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("memo.contentMemo", "TableMemo.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.contentMemo is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.contentMemo must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004739")
    void case_UTAPI_004739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004739",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004739", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004739", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004739", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004739", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004739", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004739", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004739", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004739")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004740")
    void case_UTAPI_004740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004740",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004740", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004740", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004740", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004740", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004740", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004740", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004740", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004740")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004741")
    void case_UTAPI_004741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004741",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004741", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004741", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004741", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004741", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004741", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004741", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004741", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004741")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004742")
    void case_UTAPI_004742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004742",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004742", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004742", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004742", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004742", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004742", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004742", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004742", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004742")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004743")
    void case_UTAPI_004743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004743",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004743", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004743", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004743", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004743", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004743", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004743", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004743", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004743")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004744")
    void case_UTAPI_004744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004744",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004744", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004744", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004744", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004744", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004744", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004744", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004744", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004744")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004745")
    void case_UTAPI_004745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004745",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004745", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004745", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004745", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004745", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004745", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004745", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004745", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004745")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004746")
    void case_UTAPI_004746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004746",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004746", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004746", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004746", "memo.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004746", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004746", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004746", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004746", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004746")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("memo.createdTimestamp", "TableMemo.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004747")
    void case_UTAPI_004747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004747",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004747", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004747", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004747", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004747", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004747", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004747", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004747", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004747")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004748")
    void case_UTAPI_004748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004748",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004748", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004748", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004748", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004748", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004748", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004748", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004748", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004748")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004749")
    void case_UTAPI_004749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004749",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004749", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004749", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004749", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004749", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004749", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004749", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004749", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004749")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004750")
    void case_UTAPI_004750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004750",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004750", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004750", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004750", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004750", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004750", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004750", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004750", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004750")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004751")
    void case_UTAPI_004751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004751",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004751", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004751", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004751", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004751", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004751", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004751", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004751", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004751")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004752")
    void case_UTAPI_004752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004752",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004752", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004752", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004752", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004752", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004752", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004752", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004752", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004752")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004753")
    void case_UTAPI_004753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004753",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004753", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004753", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004753", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004753", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004753", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004753", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004753", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004753")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004754")
    void case_UTAPI_004754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004754",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004754", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004754", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004754", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004754", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004754", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004754", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004754", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004754")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004755")
    void case_UTAPI_004755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004755",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004755", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004755", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004755", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004755", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004755", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004755", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004755", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004755")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004756")
    void case_UTAPI_004756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004756",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004756", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004756", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004756", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004756", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004756", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004756", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004756", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004756")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004757")
    void case_UTAPI_004757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004757",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004757", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004757", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004757", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004757", "memo.dbConnectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004757", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004757", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004757", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004757")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbConnectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("memo.dbConnectionId", "TableMemo.dbConnectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbConnectionId is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbConnectionId must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbConnectionId")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004758")
    void case_UTAPI_004758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004758",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004758", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004758", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004758", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004758", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004758", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004758", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004758", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004758")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004759")
    void case_UTAPI_004759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004759",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004759", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004759", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004759", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004759", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004759", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004759", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004759", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004759")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004760")
    void case_UTAPI_004760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004760",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004760", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004760", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004760", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004760", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004760", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004760", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004760", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004760")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004761")
    void case_UTAPI_004761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004761",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004761", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004761", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004761", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004761", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004761", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004761", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004761", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004761")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004762")
    void case_UTAPI_004762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004762",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004762", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004762", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004762", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004762", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004762", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004762", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004762", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004762")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004763")
    void case_UTAPI_004763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004763",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004763", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004763", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004763", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004763", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004763", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004763", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004763", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004763")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004764")
    void case_UTAPI_004764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004764",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004764", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004764", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004764", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004764", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004764", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004764", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004764", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004764")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004765")
    void case_UTAPI_004765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004765",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004765", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004765", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004765", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004765", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004765", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004765", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004765", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004765")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004766")
    void case_UTAPI_004766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004766",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004766", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004766", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004766", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004766", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004766", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004766", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004766", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004766")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004767")
    void case_UTAPI_004767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004767",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004767", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004767", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004767", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004767", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004767", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004767", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004767", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004767")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004768")
    void case_UTAPI_004768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004768",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004768", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004768", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004768", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004768", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004768", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004768", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004768", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004768")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004769")
    void case_UTAPI_004769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004769",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004769", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004769", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004769", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004769", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004769", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004769", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004769", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004769")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004770")
    void case_UTAPI_004770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004770",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004770", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004770", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004770", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004770", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004770", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004770", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004770", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004770")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004771")
    void case_UTAPI_004771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004771",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004771", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004771", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004771", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004771", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004771", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004771", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004771", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004771")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "56:space")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004772")
    void case_UTAPI_004772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004772",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004772", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004772", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004772", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004772", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004772", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004772", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004772", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004772")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004773")
    void case_UTAPI_004773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004773",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004773", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004773", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004773", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004773", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004773", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004773", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004773", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004773")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004774")
    void case_UTAPI_004774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004774",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004774", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004774", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004774", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004774", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004774", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004774", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004774", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004774")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "59:tab")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004775")
    void case_UTAPI_004775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004775",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004775", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004775", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004775", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004775", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004775", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004775", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004775", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004775")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004776")
    void case_UTAPI_004776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004776",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004776", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004776", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004776", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004776", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004776", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004776", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004776", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004776")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004777")
    void case_UTAPI_004777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004777",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004777", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004777", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004777", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004777", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004777", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004777", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004777", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004777")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004778")
    void case_UTAPI_004778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004778",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004778", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004778", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004778", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004778", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004778", "memo.dbTableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004778", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004778", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004778")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::dbTableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("memo.dbTableName", "TableMemo.dbTableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.dbTableName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the value generated for memo.dbTableName must reach the executed statement unchanged", "jdbcTemplate", "", "data:memo.dbTableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004779")
    void case_UTAPI_004779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004779",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004779", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004779", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004779", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004779", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004779", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004779", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004779", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004779")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004780")
    void case_UTAPI_004780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004780",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004780", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004780", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004780", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004780", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004780", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004780", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004780", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004780")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004781")
    void case_UTAPI_004781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004781",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004781", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004781", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004781", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004781", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004781", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004781", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004781", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004781")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "3:length_min", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004782")
    void case_UTAPI_004782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004782",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004782", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004782", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004782", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004782", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004782", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004782", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004782", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004782")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004783")
    void case_UTAPI_004783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004783",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004783", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004783", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004783", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004783", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004783", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004783", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004783", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004783")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "5:length_max", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004784")
    void case_UTAPI_004784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004784",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004784", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004784", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004784", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004784", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004784", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004784", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004784", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004784")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004785")
    void case_UTAPI_004785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004785",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004785", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004785", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004785", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004785", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004785", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004785", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004785", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004785")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004786")
    void case_UTAPI_004786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004786",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004786", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004786", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004786", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004786", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004786", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004786", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004786", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004786")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004787")
    void case_UTAPI_004787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004787",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004787", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004787", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004787", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004787", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004787", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004787", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004787", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004787")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004788")
    void case_UTAPI_004788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004788",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004788", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004788", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004788", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004788", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004788", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004788", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004788", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004788")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004789")
    void case_UTAPI_004789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004789",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004789", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004789", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004789", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004789", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004789", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004789", "memo.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004789", "memo.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004789")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("memo.n", "TableMemo.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:memo.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004790")
    void case_UTAPI_004790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004790",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004790", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004790", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004790", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004790", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004790", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004790", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004790", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004790")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004791")
    void case_UTAPI_004791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004791",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004791", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004791", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004791", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004791", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004791", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004791", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004791", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004791")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004792")
    void case_UTAPI_004792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004792",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004792", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004792", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004792", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004792", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004792", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004792", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004792", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004792")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004793")
    void case_UTAPI_004793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004793",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004793", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004793", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004793", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004793", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004793", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004793", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004793", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004793")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004794")
    void case_UTAPI_004794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004794",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004794", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004794", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004794", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004794", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004794", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004794", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004794", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004794")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004795")
    void case_UTAPI_004795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004795",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004795", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004795", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004795", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004795", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004795", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004795", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004795", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004795")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004796")
    void case_UTAPI_004796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004796",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004796", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004796", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004796", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004796", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004796", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004796", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004796", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004796")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004797")
    void case_UTAPI_004797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004797",
                "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway",
                "upsert",
                "TableMemo",
                new ParamSpec[] {
                    new ParamSpec("memo", "TableMemo", "memo")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004797", "memo", "NORMAL", "OBJECT", "TableMemo"),
                    new DataRef("UTAPI-004797", "memo.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004797", "memo.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004797", "memo.dbConnectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004797", "memo.dbTableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004797", "memo.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004797", "memo.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-004797")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableMemoGateway.java::TableMemoGateway::upsert::2::FIELD::1::TableMemo::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("memo.updatedTimestamp", "TableMemo.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for memo.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:memo.contentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getContentMemo")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableMemoGatewayWrapper());
    }

}

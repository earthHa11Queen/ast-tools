package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SavedSqlGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SavedSqlGateway#deleteById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SavedSqlGatewayDeleteByIdScenario {

    @Test
    @DisplayName("UTAPI-002932")
    void case_UTAPI_002932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002932",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002932", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002932")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002933")
    void case_UTAPI_002933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002933",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002933", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002933")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002934")
    void case_UTAPI_002934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002934",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002934", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002934")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002935")
    void case_UTAPI_002935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002935",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002935", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002935")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002936")
    void case_UTAPI_002936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002936",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002936", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002936")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002937")
    void case_UTAPI_002937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002937",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002937", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002937")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002938")
    void case_UTAPI_002938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002938",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002938", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002938")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002939")
    void case_UTAPI_002939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002939",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002939", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002939")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002940")
    void case_UTAPI_002940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002940",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002940", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002940")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002941")
    void case_UTAPI_002941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002941",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002941", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002941")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002942")
    void case_UTAPI_002942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002942",
                "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway",
                "deleteById",
                "void",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002942", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002942")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/SavedSqlGateway.java::SavedSqlGateway::deleteById::4::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SavedSqlGatewayWrapper());
    }

}

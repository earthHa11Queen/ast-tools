package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordRepository#updateCopyRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordRepositoryUpdateCopyRecordsScenario {

    @Test
    @DisplayName("UTAPI-009922")
    void case_UTAPI_009922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009922",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009922", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009922", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009922", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009922", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009922", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009922", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009922", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009922", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009922", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009922", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009922", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009922", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009922", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009922", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009922", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009922", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009922")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009923")
    void case_UTAPI_009923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009923",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009923", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009923", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009923", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009923", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009923", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009923", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009923", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009923", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009923", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009923", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009923", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009923", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009923", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009923", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009923", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009923", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009923")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009924")
    void case_UTAPI_009924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009924",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009924", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009924", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009924", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009924", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009924", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009924", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009924", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009924", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009924", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009924", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009924", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009924", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009924", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009924", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009924", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009924", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009924")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009925")
    void case_UTAPI_009925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009925",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009925", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009925", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009925", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009925", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009925", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009925", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009925", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009925", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009925", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009925", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009925", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009925", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009925", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009925", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009925", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009925", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009925")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009926")
    void case_UTAPI_009926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009926",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009926", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009926", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009926", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009926", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009926", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009926", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009926", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009926", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009926", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009926", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009926", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009926", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009926", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009926", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009926", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009926", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009926")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009927")
    void case_UTAPI_009927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009927",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009927", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009927", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009927", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009927", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009927", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009927", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009927", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009927", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009927", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009927", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009927", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009927", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009927", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009927", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009927", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009927", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009927")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009928")
    void case_UTAPI_009928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009928",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009928", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009928", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009928", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009928", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009928", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009928", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009928", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009928", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009928", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009928", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009928", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009928", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009928", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009928", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009928", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009928", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009928")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009929")
    void case_UTAPI_009929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009929",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009929", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009929", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009929", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009929", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009929", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009929", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009929", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009929", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009929", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009929", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009929", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009929", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009929", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009929", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009929", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009929", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009929")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009930")
    void case_UTAPI_009930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009930",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009930", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009930", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009930", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009930", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009930", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009930", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009930", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009930", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009930", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009930", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009930", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009930", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009930", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009930", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009930", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009930", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009930")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009931")
    void case_UTAPI_009931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009931",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009931", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009931", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009931", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009931", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009931", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009931", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009931", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009931", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009931", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009931", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009931", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009931", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009931", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009931", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009931", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009931", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009931")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009932")
    void case_UTAPI_009932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009932",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009932", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009932", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009932", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009932", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009932", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009932", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009932", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009932", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009932", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009932", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009932", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009932", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009932", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009932", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009932", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009932", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009932")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009933")
    void case_UTAPI_009933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009933",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009933", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009933", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009933", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009933", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009933", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009933", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009933", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009933", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009933", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009933", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009933", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009933", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009933", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009933", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009933", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009933", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009933")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009934")
    void case_UTAPI_009934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009934",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009934", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009934", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009934", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009934", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009934", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009934", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009934", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009934", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009934", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009934", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009934", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009934", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009934", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009934", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009934", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009934", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009934")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009935")
    void case_UTAPI_009935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009935",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009935", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009935", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009935", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009935", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009935", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009935", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009935", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009935", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009935", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009935", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009935", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009935", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009935", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009935", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009935", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009935", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009935")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009936")
    void case_UTAPI_009936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009936",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009936", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009936", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009936", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009936", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009936", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009936", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009936", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009936", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009936", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009936", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009936", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009936", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009936", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009936", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009936", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009936", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009936")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009937")
    void case_UTAPI_009937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009937",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009937", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009937", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009937", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009937", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009937", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009937", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009937", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009937", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009937", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009937", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009937", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009937", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009937", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009937", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009937", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009937", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009937")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009938")
    void case_UTAPI_009938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009938",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009938", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009938", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009938", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009938", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009938", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009938", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009938", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009938", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009938", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009938", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009938", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009938", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009938", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009938", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009938", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009938", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009938")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009939")
    void case_UTAPI_009939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009939",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009939", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009939", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009939", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009939", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009939", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009939", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009939", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009939", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009939", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009939", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009939", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009939", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009939", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009939", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009939", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009939", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009939")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009940")
    void case_UTAPI_009940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009940",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009940", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009940", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009940", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009940", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009940", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009940", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009940", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009940", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009940", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009940", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009940", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009940", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009940", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009940", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009940", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009940", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009940")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009941")
    void case_UTAPI_009941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009941",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009941", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009941", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009941", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009941", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009941", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009941", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009941", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009941", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009941", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009941", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009941", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009941", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009941", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009941", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009941", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009941", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009941")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009942")
    void case_UTAPI_009942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009942",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009942", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009942", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009942", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009942", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009942", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009942", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009942", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009942", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009942", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009942", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009942", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009942", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009942", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009942", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009942", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009942", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009942")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009943")
    void case_UTAPI_009943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009943",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009943", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009943", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009943", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009943", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009943", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009943", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009943", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009943", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009943", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009943", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009943", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009943", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009943", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009943", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009943", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009943", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009943")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009944")
    void case_UTAPI_009944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009944",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009944", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009944", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009944", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009944", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009944", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009944", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009944", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009944", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009944", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009944", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009944", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009944", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009944", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009944", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009944", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009944", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009944")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009945")
    void case_UTAPI_009945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009945",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009945", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009945", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009945", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009945", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009945", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009945", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009945", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009945", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009945", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009945", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009945", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009945", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009945", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009945", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009945", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009945", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009945")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009946")
    void case_UTAPI_009946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009946",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009946", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009946", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009946", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009946", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009946", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009946", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009946", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009946", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009946", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009946", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009946", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009946", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009946", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009946", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009946", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009946", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009946")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009947")
    void case_UTAPI_009947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009947",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009947", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009947", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009947", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009947", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009947", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009947", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009947", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009947", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009947", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009947", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009947", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009947", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009947", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009947", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009947", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009947", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009947")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009948")
    void case_UTAPI_009948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009948",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009948", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009948", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009948", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009948", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009948", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009948", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009948", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009948", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009948", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009948", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009948", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009948", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009948", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009948", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009948", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009948", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009948")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009949")
    void case_UTAPI_009949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009949",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009949", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009949", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009949", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009949", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009949", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009949", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009949", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009949", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009949", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009949", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009949", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009949", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009949", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009949", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009949", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009949", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009949")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009950")
    void case_UTAPI_009950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009950",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009950", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009950", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009950", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009950", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009950", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009950", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009950", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009950", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009950", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009950", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009950", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009950", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009950", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009950", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009950", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009950", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009950")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009951")
    void case_UTAPI_009951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009951",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009951", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009951", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009951", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009951", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009951", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009951", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009951", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009951", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009951", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009951", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009951", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009951", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009951", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009951", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009951", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009951", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009951")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009952")
    void case_UTAPI_009952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009952",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009952", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009952", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009952", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009952", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009952", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009952", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009952", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009952", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009952", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009952", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009952", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009952", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009952", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009952", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009952", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009952", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009952")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009953")
    void case_UTAPI_009953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009953",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009953", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009953", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009953", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009953", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009953", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009953", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009953", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009953", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009953", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009953", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009953", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009953", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009953", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009953", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009953", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009953", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009953")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009954")
    void case_UTAPI_009954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009954",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009954", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009954", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009954", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009954", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009954", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009954", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009954", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009954", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009954", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009954", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009954", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009954", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009954", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009954", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009954", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009954", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009954")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009955")
    void case_UTAPI_009955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009955",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009955", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009955", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009955", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009955", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009955", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009955", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009955", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009955", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009955", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009955", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009955", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009955", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009955", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009955", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009955", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009955", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009955")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009956")
    void case_UTAPI_009956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009956",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009956", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009956", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009956", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009956", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009956", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009956", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009956", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009956", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009956", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009956", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009956", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009956", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009956", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009956", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009956", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009956", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009956")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009957")
    void case_UTAPI_009957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009957",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009957", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009957", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009957", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009957", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009957", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009957", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009957", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009957", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009957", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009957", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009957", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009957", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009957", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009957", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009957", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009957", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009957")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009958")
    void case_UTAPI_009958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009958",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009958", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009958", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009958", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009958", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009958", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009958", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009958", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009958", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009958", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009958", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009958", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009958", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009958", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009958", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009958", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009958", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009958")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009959")
    void case_UTAPI_009959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009959",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009959", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009959", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009959", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009959", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009959", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009959", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009959", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009959", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009959", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009959", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009959", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009959", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009959", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009959", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009959", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009959", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009959")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009960")
    void case_UTAPI_009960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009960",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009960", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009960", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009960", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009960", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009960", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009960", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009960", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009960", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009960", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009960", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009960", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009960", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009960", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009960", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009960", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009960", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009960")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009961")
    void case_UTAPI_009961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009961",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009961", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009961", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009961", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009961", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009961", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009961", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009961", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009961", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009961", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009961", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009961", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009961", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009961", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009961", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009961", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009961", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009961")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009962")
    void case_UTAPI_009962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009962",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009962", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009962", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009962", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009962", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009962", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009962", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009962", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009962", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009962", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009962", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009962", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009962", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009962", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009962", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009962", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009962", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009962")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009963")
    void case_UTAPI_009963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009963",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009963", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009963", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009963", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009963", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009963", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009963", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009963", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009963", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009963", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009963", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009963", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009963", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009963", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009963", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009963", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009963", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009963")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009964")
    void case_UTAPI_009964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009964",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009964", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009964", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009964", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009964", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009964", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009964", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009964", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009964", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009964", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009964", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009964", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009964", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009964", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009964", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009964", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009964", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009964")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009965")
    void case_UTAPI_009965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009965",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009965", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009965", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009965", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009965", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009965", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009965", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009965", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009965", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009965", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009965", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009965", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009965", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009965", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009965", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009965", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009965", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009965")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009966")
    void case_UTAPI_009966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009966",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009966", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009966", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009966", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009966", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009966", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009966", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009966", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009966", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009966", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009966", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009966", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009966", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009966", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009966", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009966", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009966", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009966")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009967")
    void case_UTAPI_009967() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009967",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009967", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009967", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009967", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009967", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009967", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009967", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009967", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009967", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009967", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009967", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009967", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009967", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009967", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009967", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009967", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009967", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009967")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009968")
    void case_UTAPI_009968() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009968",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009968", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009968", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009968", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009968", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009968", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009968", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009968", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009968", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009968", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009968", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009968", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009968", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009968", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009968", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009968", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009968", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009968")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009969")
    void case_UTAPI_009969() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009969",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009969", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009969", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009969", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009969", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009969", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009969", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009969", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009969", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009969", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009969", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009969", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009969", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009969", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009969", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009969", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009969", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009969")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009970")
    void case_UTAPI_009970() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009970",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009970", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009970", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009970", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009970", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009970", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009970", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009970", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009970", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009970", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009970", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009970", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009970", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009970", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009970", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009970", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009970", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009970")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009971")
    void case_UTAPI_009971() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009971",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009971", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009971", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009971", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009971", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009971", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009971", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009971", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009971", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009971", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009971", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009971", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009971", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009971", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009971", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009971", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009971", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009971")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009972")
    void case_UTAPI_009972() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009972",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009972", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009972", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009972", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009972", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009972", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009972", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009972", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009972", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009972", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009972", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009972", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009972", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009972", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009972", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009972", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009972", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009972")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009973")
    void case_UTAPI_009973() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009973",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009973", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009973", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009973", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009973", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009973", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009973", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009973", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009973", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009973", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009973", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009973", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009973", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009973", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009973", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009973", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009973", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009973")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009974")
    void case_UTAPI_009974() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009974",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009974", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009974", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009974", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009974", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009974", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009974", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009974", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009974", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009974", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009974", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009974", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009974", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009974", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009974", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009974", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009974", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009974")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009975")
    void case_UTAPI_009975() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009975",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009975", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009975", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009975", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009975", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009975", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009975", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009975", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009975", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009975", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009975", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009975", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009975", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009975", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009975", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009975", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009975", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009975")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009976")
    void case_UTAPI_009976() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009976",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009976", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009976", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009976", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009976", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009976", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009976", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009976", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009976", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009976", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009976", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009976", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009976", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009976", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009976", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009976", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009976", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009976")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009977")
    void case_UTAPI_009977() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009977",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009977", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009977", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009977", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009977", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009977", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009977", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009977", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009977", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009977", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009977", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009977", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009977", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009977", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009977", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009977", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009977", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009977")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009978")
    void case_UTAPI_009978() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009978",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009978", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009978", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009978", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009978", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009978", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009978", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009978", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009978", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009978", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009978", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009978", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009978", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009978", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009978", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009978", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009978", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009978")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009979")
    void case_UTAPI_009979() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009979",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009979", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009979", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009979", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009979", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009979", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009979", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009979", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009979", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009979", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009979", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009979", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009979", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009979", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009979", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009979", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009979", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009979")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009980")
    void case_UTAPI_009980() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009980",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009980", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009980", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009980", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009980", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009980", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009980", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009980", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009980", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009980", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009980", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009980", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009980", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009980", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009980", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009980", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009980", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009980")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009981")
    void case_UTAPI_009981() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009981",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009981", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009981", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009981", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009981", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009981", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009981", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009981", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009981", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009981", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009981", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009981", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009981", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009981", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009981", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009981", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009981", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009981")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009982")
    void case_UTAPI_009982() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009982",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009982", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009982", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009982", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009982", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009982", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009982", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009982", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009982", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009982", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009982", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009982", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009982", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009982", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009982", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009982", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009982", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009982")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009983")
    void case_UTAPI_009983() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009983",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009983", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009983", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009983", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009983", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009983", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009983", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009983", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009983", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009983", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009983", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009983", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009983", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009983", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009983", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009983", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009983", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009983")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009984")
    void case_UTAPI_009984() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009984",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009984", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009984", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009984", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009984", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009984", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009984", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009984", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009984", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009984", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009984", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009984", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009984", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009984", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009984", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009984", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009984", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009984")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009985")
    void case_UTAPI_009985() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009985",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009985", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009985", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009985", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009985", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009985", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009985", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009985", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009985", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009985", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009985", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009985", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009985", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009985", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009985", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009985", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009985", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009985")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009986")
    void case_UTAPI_009986() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009986",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009986", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009986", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009986", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009986", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009986", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009986", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009986", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009986", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009986", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009986", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009986", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009986", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009986", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009986", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009986", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009986", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009986")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009987")
    void case_UTAPI_009987() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009987",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009987", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009987", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009987", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009987", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009987", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009987", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009987", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009987", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009987", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009987", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009987", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009987", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009987", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009987", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009987", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009987", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009987")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009988")
    void case_UTAPI_009988() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009988",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009988", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009988", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009988", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009988", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009988", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009988", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009988", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009988", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009988", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009988", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009988", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009988", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009988", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009988", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009988", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009988", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009988")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009989")
    void case_UTAPI_009989() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009989",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009989", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009989", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009989", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009989", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009989", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009989", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009989", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009989", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009989", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009989", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009989", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009989", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009989", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009989", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009989", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009989", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009989")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009990")
    void case_UTAPI_009990() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009990",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009990", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009990", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009990", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009990", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009990", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009990", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009990", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009990", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009990", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009990", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009990", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009990", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009990", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009990", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009990", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009990", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009990")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009991")
    void case_UTAPI_009991() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009991",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009991", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009991", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009991", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009991", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009991", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009991", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009991", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009991", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009991", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009991", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009991", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009991", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009991", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009991", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009991", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009991", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009991")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009992")
    void case_UTAPI_009992() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009992",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009992", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009992", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009992", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009992", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009992", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009992", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009992", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009992", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009992", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009992", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009992", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009992", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009992", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009992", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009992", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009992", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009992")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009993")
    void case_UTAPI_009993() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009993",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009993", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009993", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009993", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009993", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009993", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009993", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009993", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009993", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009993", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009993", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009993", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009993", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009993", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009993", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009993", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009993", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009993")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009994")
    void case_UTAPI_009994() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009994",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009994", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009994", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009994", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009994", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009994", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009994", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009994", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009994", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009994", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009994", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009994", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009994", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009994", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009994", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009994", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009994", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009994")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009995")
    void case_UTAPI_009995() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009995",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009995", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009995", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009995", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009995", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009995", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009995", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009995", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009995", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009995", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009995", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009995", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009995", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009995", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009995", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009995", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009995", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009995")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009996")
    void case_UTAPI_009996() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009996",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009996", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009996", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009996", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009996", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009996", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009996", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009996", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009996", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009996", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009996", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009996", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009996", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009996", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009996", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009996", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009996", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009996")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009997")
    void case_UTAPI_009997() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009997",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009997", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009997", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009997", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009997", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009997", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009997", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009997", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009997", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009997", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009997", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009997", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009997", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009997", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009997", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009997", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009997", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009997")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009998")
    void case_UTAPI_009998() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009998",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009998", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009998", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009998", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009998", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009998", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009998", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009998", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009998", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009998", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009998", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009998", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009998", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009998", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009998", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009998", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009998", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009998")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-009999")
    void case_UTAPI_009999() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-009999",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-009999", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-009999", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009999", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009999", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009999", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009999", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-009999", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009999", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009999", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-009999", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-009999", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-009999", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-009999", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009999", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-009999", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-009999", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-009999")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010000")
    void case_UTAPI_010000() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010000",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010000", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010000", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010000", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010000", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010000", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010000", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010000", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010000", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010000", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010000", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010000", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010000", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010000", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010000", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010000", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010000", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010000")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010001")
    void case_UTAPI_010001() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010001",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010001", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010001", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010001", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010001", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010001", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010001", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010001", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010001", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010001", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010001", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010001", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010001", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010001", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010001", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010001", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010001", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010001")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010002")
    void case_UTAPI_010002() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010002",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010002", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010002", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010002", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010002", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010002", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010002", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010002", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010002", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010002", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010002", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010002", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010002", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010002", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010002", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010002", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010002", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010002")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010003")
    void case_UTAPI_010003() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010003",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010003", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010003", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010003", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010003", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010003", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010003", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010003", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010003", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010003", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010003", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010003", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010003", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010003", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010003", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010003", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010003", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010003")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010004")
    void case_UTAPI_010004() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010004",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010004", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010004", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010004", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010004", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010004", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010004", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010004", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010004", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010004", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010004", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010004", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010004", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010004", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010004", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010004", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010004", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010004")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010005")
    void case_UTAPI_010005() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010005",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010005", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010005", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010005", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010005", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010005", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010005", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010005", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010005", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010005", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010005", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010005", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010005", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010005", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010005", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010005", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010005", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010005")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010006")
    void case_UTAPI_010006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010006",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010006", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010006", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010006", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010006", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010006", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010006", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010006", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010006", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010006", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010006", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010006", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010006", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010006", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010006", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010006", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010006", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010006")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010007")
    void case_UTAPI_010007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010007",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010007", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010007", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010007", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010007", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010007", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010007", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010007", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010007", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010007", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010007", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010007", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010007", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010007", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010007", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010007", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010007", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010007")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010008")
    void case_UTAPI_010008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010008",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010008", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010008", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010008", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010008", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010008", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010008", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010008", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010008", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010008", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010008", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010008", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010008", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010008", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010008", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010008", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010008", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010008")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010009")
    void case_UTAPI_010009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010009",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010009", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010009", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010009", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010009", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010009", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010009", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010009", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010009", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010009", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010009", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010009", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010009", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010009", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010009", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010009", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010009", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010009")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010010")
    void case_UTAPI_010010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010010",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010010", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010010", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010010", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010010", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010010", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010010", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010010", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010010", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010010", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010010", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010010", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010010", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010010", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010010", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010010", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010010", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010010")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010011")
    void case_UTAPI_010011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010011",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010011", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010011", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010011", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010011", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010011", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010011", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010011", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010011", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010011", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010011", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010011", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010011", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010011", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010011", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010011", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010011", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010011")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010012")
    void case_UTAPI_010012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010012",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010012", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010012", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010012", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010012", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010012", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010012", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010012", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010012", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010012", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010012", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010012", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010012", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010012", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010012", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010012", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010012", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010012")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010013")
    void case_UTAPI_010013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010013",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010013", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010013", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010013", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010013", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010013", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010013", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010013", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010013", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010013", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010013", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010013", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010013", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010013", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010013", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010013", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010013", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010013")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010014")
    void case_UTAPI_010014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010014",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010014", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010014", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010014", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010014", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010014", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010014", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010014", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010014", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010014", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010014", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010014", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010014", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010014", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010014", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010014", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010014", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010014")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010015")
    void case_UTAPI_010015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010015",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010015", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010015", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010015", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010015", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010015", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010015", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010015", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010015", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010015", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010015", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010015", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010015", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010015", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010015", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010015", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010015", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010015")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010016")
    void case_UTAPI_010016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010016",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010016", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010016", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010016", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010016", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010016", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010016", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010016", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010016", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010016", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010016", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010016", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010016", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010016", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010016", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010016", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010016", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010016")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010017")
    void case_UTAPI_010017() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010017",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010017", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010017", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010017", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010017", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010017", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010017", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010017", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010017", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010017", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010017", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010017", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010017", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010017", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010017", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010017", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010017", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010017")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010018")
    void case_UTAPI_010018() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010018",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010018", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010018", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010018", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010018", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010018", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010018", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010018", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010018", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010018", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010018", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010018", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010018", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010018", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010018", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010018", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010018", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010018")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010019")
    void case_UTAPI_010019() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010019",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010019", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010019", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010019", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010019", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010019", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010019", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010019", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010019", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010019", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010019", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010019", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010019", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010019", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010019", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010019", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010019", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010019")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010020")
    void case_UTAPI_010020() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010020",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010020", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010020", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010020", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010020", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010020", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010020", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010020", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010020", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010020", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010020", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010020", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010020", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010020", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010020", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010020", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010020", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010020")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010021")
    void case_UTAPI_010021() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010021",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010021", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010021", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010021", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010021", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010021", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010021", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010021", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010021", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010021", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010021", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010021", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010021", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010021", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010021", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010021", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010021", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010021")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010022")
    void case_UTAPI_010022() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010022",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010022", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010022", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010022", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010022", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010022", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010022", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010022", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010022", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010022", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010022", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010022", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010022", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010022", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010022", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010022", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010022", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010022")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010023")
    void case_UTAPI_010023() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010023",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010023", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010023", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010023", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010023", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010023", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010023", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010023", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010023", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010023", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010023", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010023", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010023", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010023", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010023", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010023", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010023", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010023")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010024")
    void case_UTAPI_010024() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010024",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010024", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010024", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010024", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010024", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010024", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010024", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010024", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010024", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010024", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010024", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010024", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010024", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010024", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010024", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010024", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010024", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010024")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010025")
    void case_UTAPI_010025() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010025",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010025", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010025", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010025", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010025", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010025", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010025", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010025", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010025", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010025", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010025", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010025", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010025", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010025", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010025", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010025", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010025", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010025")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010026")
    void case_UTAPI_010026() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010026",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010026", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010026", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010026", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010026", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010026", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010026", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010026", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010026", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010026", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010026", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010026", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010026", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010026", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010026", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010026", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010026", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010026")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010027")
    void case_UTAPI_010027() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010027",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010027", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010027", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010027", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010027", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010027", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010027", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010027", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010027", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010027", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010027", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010027", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010027", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010027", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010027", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010027", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010027", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010027")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010028")
    void case_UTAPI_010028() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010028",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010028", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010028", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010028", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010028", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010028", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010028", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010028", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010028", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010028", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010028", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010028", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010028", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010028", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010028", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010028", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010028", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010028")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010029")
    void case_UTAPI_010029() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010029",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010029", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010029", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010029", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010029", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010029", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010029", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010029", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010029", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010029", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010029", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010029", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010029", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010029", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010029", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010029", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010029", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010029")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010030")
    void case_UTAPI_010030() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010030",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010030", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010030", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010030", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010030", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010030", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010030", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010030", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010030", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010030", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010030", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010030", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010030", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010030", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010030", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010030", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010030", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010030")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010031")
    void case_UTAPI_010031() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010031",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010031", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010031", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010031", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010031", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010031", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010031", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010031", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010031", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010031", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010031", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010031", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010031", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010031", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010031", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010031", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010031", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010031")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010032")
    void case_UTAPI_010032() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010032",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010032", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010032", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010032", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010032", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010032", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010032", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010032", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010032", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010032", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010032", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010032", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010032", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010032", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010032", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010032", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010032", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010032")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010033")
    void case_UTAPI_010033() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010033",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010033", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010033", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010033", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010033", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010033", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010033", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010033", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010033", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010033", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010033", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010033", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010033", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010033", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010033", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010033", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010033", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010033")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010034")
    void case_UTAPI_010034() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010034",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010034", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010034", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010034", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010034", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010034", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010034", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010034", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010034", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010034", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010034", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010034", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010034", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010034", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010034", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010034", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010034", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010034")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010035")
    void case_UTAPI_010035() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010035",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010035", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010035", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010035", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010035", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010035", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010035", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010035", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010035", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010035", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010035", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010035", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010035", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010035", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010035", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010035", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010035", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010035")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010036")
    void case_UTAPI_010036() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010036",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010036", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010036", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010036", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010036", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010036", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010036", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010036", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010036", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010036", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010036", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010036", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010036", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010036", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010036", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010036", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010036", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010036")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010037")
    void case_UTAPI_010037() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010037",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010037", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010037", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010037", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010037", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010037", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010037", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010037", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010037", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010037", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010037", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010037", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010037", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010037", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010037", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010037", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010037", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010037")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010038")
    void case_UTAPI_010038() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010038",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010038", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010038", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010038", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010038", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010038", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010038", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010038", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010038", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010038", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010038", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010038", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010038", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010038", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010038", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010038", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010038", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010038")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010039")
    void case_UTAPI_010039() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010039",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010039", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010039", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010039", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010039", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010039", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010039", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010039", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010039", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010039", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010039", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010039", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010039", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010039", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010039", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010039", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010039", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010039")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010040")
    void case_UTAPI_010040() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010040",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010040", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010040", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010040", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010040", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010040", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010040", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010040", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010040", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010040", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010040", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010040", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010040", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010040", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010040", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010040", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010040", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010040")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010041")
    void case_UTAPI_010041() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010041",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010041", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010041", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010041", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010041", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010041", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010041", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010041", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010041", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010041", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010041", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010041", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010041", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010041", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010041", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010041", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010041", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010041")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010042")
    void case_UTAPI_010042() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010042",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010042", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010042", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010042", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010042", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010042", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010042", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010042", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010042", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010042", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010042", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010042", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010042", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010042", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010042", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010042", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010042", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010042")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010043")
    void case_UTAPI_010043() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010043",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010043", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010043", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010043", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010043", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010043", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010043", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010043", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010043", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010043", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010043", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010043", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010043", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010043", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010043", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010043", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010043", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010043")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010044")
    void case_UTAPI_010044() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010044",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010044", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010044", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010044", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010044", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010044", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010044", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010044", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010044", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010044", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010044", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010044", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010044", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010044", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010044", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010044", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010044", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010044")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010045")
    void case_UTAPI_010045() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010045",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010045", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010045", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010045", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010045", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010045", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010045", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010045", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010045", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010045", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010045", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010045", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010045", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010045", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010045", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010045", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010045", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010045")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010046")
    void case_UTAPI_010046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010046",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010046", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010046", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010046", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010046", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010046", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010046", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010046", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010046", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010046", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010046", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010046", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010046", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010046", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010046", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010046", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010046", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010046")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010047")
    void case_UTAPI_010047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010047",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010047", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010047", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010047", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010047", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010047", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010047", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010047", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010047", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010047", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010047", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010047", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010047", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010047", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010047", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010047", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010047", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010047")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010048")
    void case_UTAPI_010048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010048",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010048", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010048", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010048", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010048", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010048", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010048", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010048", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010048", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010048", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010048", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010048", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010048", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010048", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010048", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010048", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010048", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010048")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010049")
    void case_UTAPI_010049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010049",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010049", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010049", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010049", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010049", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010049", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010049", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010049", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010049", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010049", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010049", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010049", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010049", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010049", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010049", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010049", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010049", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010049")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010050")
    void case_UTAPI_010050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010050",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010050", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010050", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010050", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010050", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010050", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010050", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010050", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010050", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010050", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010050", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010050", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010050", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010050", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010050", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010050", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010050", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010050")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010051")
    void case_UTAPI_010051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010051",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010051", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010051", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010051", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010051", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010051", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010051", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010051", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010051", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010051", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010051", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010051", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010051", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010051", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010051", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010051", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010051", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010051")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010052")
    void case_UTAPI_010052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010052",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010052", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010052", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010052", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010052", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010052", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010052", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010052", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010052", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010052", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010052", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010052", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010052", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010052", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010052", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010052", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010052", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010052")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010053")
    void case_UTAPI_010053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010053",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010053", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010053", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010053", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010053", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010053", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010053", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010053", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010053", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010053", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010053", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010053", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010053", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010053", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010053", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010053", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010053", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010053")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010054")
    void case_UTAPI_010054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010054",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010054", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010054", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010054", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010054", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010054", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010054", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010054", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010054", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010054", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010054", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010054", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010054", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010054", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010054", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010054", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010054", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010054")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010055")
    void case_UTAPI_010055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010055",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010055", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010055", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010055", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010055", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010055", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010055", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010055", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010055", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010055", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010055", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010055", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010055", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010055", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010055", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010055", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010055", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010055")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010056")
    void case_UTAPI_010056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010056",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010056", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010056", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010056", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010056", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010056", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010056", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010056", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010056", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010056", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010056", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010056", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010056", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010056", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010056", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010056", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010056", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010056")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010057")
    void case_UTAPI_010057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010057",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010057", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010057", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010057", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010057", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010057", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010057", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010057", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010057", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010057", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010057", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010057", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010057", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010057", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010057", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010057", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010057", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010057")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010058")
    void case_UTAPI_010058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010058",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010058", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010058", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010058", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010058", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010058", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010058", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010058", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010058", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010058", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010058", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010058", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010058", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010058", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010058", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010058", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010058", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010058")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010059")
    void case_UTAPI_010059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010059",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010059", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010059", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010059", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010059", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010059", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010059", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010059", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010059", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010059", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010059", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010059", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010059", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010059", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010059", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010059", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010059", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010059")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010060")
    void case_UTAPI_010060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010060",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010060", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010060", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010060", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010060", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010060", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010060", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010060", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010060", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010060", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010060", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010060", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010060", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010060", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010060", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010060", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010060", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010060")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010061")
    void case_UTAPI_010061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010061",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010061", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010061", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010061", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010061", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010061", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010061", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010061", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010061", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010061", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010061", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010061", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010061", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010061", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010061", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010061", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010061", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010061")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010062")
    void case_UTAPI_010062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010062",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010062", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010062", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010062", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010062", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010062", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010062", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010062", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010062", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010062", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010062", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010062", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010062", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010062", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010062", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010062", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010062", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010062")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010063")
    void case_UTAPI_010063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010063",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010063", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010063", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010063", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010063", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010063", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010063", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010063", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010063", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010063", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010063", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010063", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010063", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010063", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010063", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010063", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010063", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010063")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010064")
    void case_UTAPI_010064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010064",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010064", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010064", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010064", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010064", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010064", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010064", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010064", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010064", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010064", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010064", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010064", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010064", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010064", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010064", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010064", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010064", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010064")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010065")
    void case_UTAPI_010065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010065",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010065", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010065", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010065", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010065", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010065", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010065", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010065", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010065", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010065", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010065", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010065", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010065", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010065", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010065", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010065", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010065", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010065")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010066")
    void case_UTAPI_010066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010066",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010066", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010066", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010066", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010066", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010066", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010066", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010066", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010066", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010066", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010066", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010066", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010066", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010066", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010066", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010066", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010066", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010066")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010067")
    void case_UTAPI_010067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010067",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010067", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010067", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010067", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010067", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010067", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010067", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010067", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010067", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010067", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010067", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010067", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010067", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010067", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010067", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010067", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010067", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010067")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010068")
    void case_UTAPI_010068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010068",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010068", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010068", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010068", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010068", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010068", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010068", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010068", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010068", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010068", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010068", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010068", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010068", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010068", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010068", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010068", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010068", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010068")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010069")
    void case_UTAPI_010069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010069",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010069", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010069", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010069", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010069", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010069", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010069", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010069", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010069", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010069", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010069", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010069", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010069", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010069", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010069", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010069", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010069", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010069")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010070")
    void case_UTAPI_010070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010070",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010070", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010070", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010070", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010070", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010070", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010070", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010070", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010070", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010070", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010070", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010070", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010070", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010070", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010070", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010070", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010070", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010070")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010071")
    void case_UTAPI_010071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010071",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010071", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010071", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010071", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010071", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010071", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010071", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010071", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010071", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010071", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010071", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010071", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010071", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010071", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010071", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010071", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010071", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010071")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010072")
    void case_UTAPI_010072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010072",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010072", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010072", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010072", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010072", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010072", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010072", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010072", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010072", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010072", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010072", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010072", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010072", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010072", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010072", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010072", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010072", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010072")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010073")
    void case_UTAPI_010073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010073",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010073", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010073", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010073", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010073", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010073", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010073", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010073", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010073", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010073", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010073", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010073", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010073", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010073", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010073", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010073", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010073", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010073")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010074")
    void case_UTAPI_010074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010074",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010074", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010074", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010074", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010074", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010074", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010074", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010074", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010074", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010074", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010074", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010074", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010074", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010074", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010074", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010074", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010074", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010074")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010075")
    void case_UTAPI_010075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010075",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010075", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010075", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010075", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010075", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010075", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010075", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010075", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010075", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010075", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010075", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010075", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010075", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010075", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010075", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010075", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010075", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010075")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010076")
    void case_UTAPI_010076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010076",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010076", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010076", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010076", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010076", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010076", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010076", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010076", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010076", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010076", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010076", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010076", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010076", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010076", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010076", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010076", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010076", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010076")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010077")
    void case_UTAPI_010077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010077",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010077", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010077", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010077", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010077", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010077", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010077", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010077", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010077", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010077", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010077", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010077", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010077", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010077", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010077", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010077", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010077", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010077")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010078")
    void case_UTAPI_010078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010078",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010078", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010078", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010078", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010078", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010078", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010078", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010078", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010078", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010078", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010078", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010078", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010078", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010078", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010078", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010078", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010078", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010078")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010079")
    void case_UTAPI_010079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010079",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010079", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010079", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010079", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010079", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010079", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010079", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010079", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010079", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010079", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010079", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010079", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010079", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010079", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010079", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010079", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010079", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010079")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010080")
    void case_UTAPI_010080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010080",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010080", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010080", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010080", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010080", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010080", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010080", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010080", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010080", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010080", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010080", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010080", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010080", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010080", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010080", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010080", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010080", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010080")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010081")
    void case_UTAPI_010081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010081",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010081", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010081", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010081", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010081", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010081", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010081", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010081", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010081", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010081", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010081", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010081", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010081", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010081", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010081", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010081", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010081", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010081")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010082")
    void case_UTAPI_010082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010082",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010082", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010082", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010082", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010082", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010082", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010082", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010082", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010082", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010082", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010082", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010082", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010082", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010082", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010082", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010082", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010082", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010082")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010083")
    void case_UTAPI_010083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010083",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010083", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010083", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010083", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010083", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010083", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010083", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010083", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010083", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010083", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010083", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010083", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010083", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010083", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010083", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010083", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010083", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010083")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010084")
    void case_UTAPI_010084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010084",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010084", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010084", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010084", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010084", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010084", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010084", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010084", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010084", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010084", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010084", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010084", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010084", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010084", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010084", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010084", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010084", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010084")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010085")
    void case_UTAPI_010085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010085",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010085", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010085", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010085", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010085", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010085", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010085", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010085", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010085", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010085", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010085", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010085", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010085", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010085", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010085", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010085", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010085", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010085")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010086")
    void case_UTAPI_010086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010086",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010086", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010086", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010086", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010086", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010086", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010086", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010086", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010086", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010086", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010086", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010086", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010086", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010086", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010086", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010086", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010086", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010086")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010087")
    void case_UTAPI_010087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010087",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010087", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010087", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010087", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010087", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010087", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010087", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010087", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010087", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010087", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010087", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010087", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010087", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010087", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010087", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010087", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010087", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010087")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010088")
    void case_UTAPI_010088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010088",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010088", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010088", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010088", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010088", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010088", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010088", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010088", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010088", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010088", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010088", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010088", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010088", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010088", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010088", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010088", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010088", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010088")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010089")
    void case_UTAPI_010089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010089",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010089", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010089", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010089", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010089", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010089", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010089", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010089", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010089", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010089", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010089", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010089", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010089", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010089", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010089", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010089", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010089", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010089")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010090")
    void case_UTAPI_010090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010090",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010090", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010090", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010090", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010090", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010090", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010090", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010090", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010090", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010090", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010090", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010090", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010090", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010090", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010090", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010090", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010090", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010090")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010091")
    void case_UTAPI_010091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010091",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010091", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010091", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010091", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010091", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010091", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010091", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010091", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010091", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010091", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010091", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010091", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010091", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010091", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010091", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010091", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010091", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010091")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010092")
    void case_UTAPI_010092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010092",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010092", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010092", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010092", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010092", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010092", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010092", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010092", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010092", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010092", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010092", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010092", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010092", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010092", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010092", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010092", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010092", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010092")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010093")
    void case_UTAPI_010093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010093",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010093", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010093", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010093", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010093", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010093", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010093", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010093", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010093", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010093", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010093", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010093", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010093", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010093", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010093", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010093", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010093", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010093")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010094")
    void case_UTAPI_010094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010094",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010094", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010094", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010094", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010094", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010094", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010094", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010094", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010094", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010094", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010094", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010094", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010094", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010094", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010094", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010094", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010094", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010094")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010095")
    void case_UTAPI_010095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010095",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010095", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010095", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010095", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010095", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010095", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010095", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010095", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010095", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010095", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010095", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010095", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010095", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010095", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010095", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010095", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010095", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010095")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010096")
    void case_UTAPI_010096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010096",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010096", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010096", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010096", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010096", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010096", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010096", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010096", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010096", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010096", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010096", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010096", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010096", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010096", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010096", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010096", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010096", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010096")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010097")
    void case_UTAPI_010097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010097",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010097", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010097", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010097", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010097", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010097", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010097", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010097", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010097", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010097", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010097", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010097", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010097", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010097", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010097", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010097", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010097", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010097")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010098")
    void case_UTAPI_010098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010098",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010098", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010098", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010098", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010098", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010098", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010098", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010098", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010098", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010098", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010098", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010098", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010098", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010098", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010098", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010098", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010098", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010098")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010099")
    void case_UTAPI_010099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010099",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010099", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010099", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010099", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010099", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010099", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010099", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010099", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010099", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010099", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010099", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010099", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010099", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010099", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010099", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010099", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010099", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010099")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010100")
    void case_UTAPI_010100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010100",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010100", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010100", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010100", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010100", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010100", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010100", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010100", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010100", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010100", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010100", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010100", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010100", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010100", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010100", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010100", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010100", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010100")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010101")
    void case_UTAPI_010101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010101",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010101", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010101", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010101", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010101", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010101", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010101", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010101", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010101", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010101", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010101", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010101", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010101", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010101", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010101", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010101", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010101", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010101")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010102")
    void case_UTAPI_010102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010102",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010102", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010102", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010102", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010102", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010102", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010102", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010102", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010102", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010102", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010102", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010102", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010102", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010102", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010102", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010102", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010102", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010102")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010103")
    void case_UTAPI_010103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010103",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010103", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010103", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010103", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010103", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010103", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010103", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010103", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010103", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010103", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010103", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010103", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010103", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010103", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010103", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010103", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010103", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010103")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010104")
    void case_UTAPI_010104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010104",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010104", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010104", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010104", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010104", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010104", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010104", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010104", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010104", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010104", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010104", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010104", "records", "NORMAL", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010104", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010104", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010104", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010104", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010104", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010104")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested records", "JdbcTemplate", "", "data:records")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010105")
    void case_UTAPI_010105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010105",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010105", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010105", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010105", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010105", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010105", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010105", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010105", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010105", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010105", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010105", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010105", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010105", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010105", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010105", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010105", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010105", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010105")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "1:length_null", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010106")
    void case_UTAPI_010106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010106",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010106", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010106", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010106", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010106", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010106", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010106", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010106", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010106", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010106", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010106", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010106", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010106", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010106", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010106", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010106", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010106", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010106")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "2:length_empty", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010107")
    void case_UTAPI_010107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010107",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010107", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010107", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010107", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010107", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010107", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010107", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010107", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010107", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010107", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010107", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010107", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010107", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010107", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010107", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010107", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010107", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010107")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "3:length_min", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010108")
    void case_UTAPI_010108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010108",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010108", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010108", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010108", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010108", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010108", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010108", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010108", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010108", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010108", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010108", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010108", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010108", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010108", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010108", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010108", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010108", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010108")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010109")
    void case_UTAPI_010109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010109",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010109", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010109", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010109", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010109", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010109", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010109", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010109", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010109", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010109", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010109", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010109", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010109", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010109", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010109", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010109", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010109", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010109")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "5:length_max", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010110")
    void case_UTAPI_010110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010110",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010110", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010110", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010110", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010110", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010110", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010110", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010110", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010110", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010110", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010110", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010110", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010110", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010110", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010110", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010110", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010110", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010110")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-010111")
    void case_UTAPI_010111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010111",
                "com.matsushita.dbeditor.domain.repository.TableRecordRepository",
                "updateCopyRecords",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("records", "List<Map<String, Object>>", "records")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010111", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-010111", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010111", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010111", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010111", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010111", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010111", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010111", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010111", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010111", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010111", "records", "TARGET", "COLLECTION", "List<Map<String, Object>>"),
                    new DataRef("UTAPI-010111", "records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-010111", "records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010111", "records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-010111", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010111", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010111")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/TableRecordRepository.java::TableRecordRepository::updateCopyRecords::4::ARG::4::-::records")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("records", "records")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for records reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for records must reach the executed statement unchanged", "JdbcTemplate", "", "data:records")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordRepositoryWrapper());
    }

}

package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for SavedSqlGateway.
 */
public final class SavedSqlGatewayWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.gateway.SavedSqlGateway";
    private static final String[] DEP_NAMES = new String[] {"jdbcTemplate", "SCHEMA", "rowMapper"};
    private static final String[] DEP_TYPES = new String[] {"JdbcTemplate", "String", "RowMapper<SavedSql>"};
    private static final String[] TYPES_deleteById = new String[] {"Integer"};
    private static final String[] TYPES_findAllByConnectionId = new String[] {"Integer"};
    private static final String[] TYPES_findById = new String[] {"Integer"};
    private static final String[] TYPES_save = new String[] {"SavedSql"};

    public SavedSqlGatewayWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
        registry().setGenericHint("SavedSql");
    }

    /** void deleteById(n) */
    public ExecutionResult deleteById(Object[] args) {
        return invoke("deleteById", TYPES_deleteById, args);
    }

    /** List<SavedSql> findAllByConnectionId(connectionId) */
    public ExecutionResult findAllByConnectionId(Object[] args) {
        return invoke("findAllByConnectionId", TYPES_findAllByConnectionId, args);
    }

    /** Optional<SavedSql> findById(n) */
    public ExecutionResult findById(Object[] args) {
        return invoke("findById", TYPES_findById, args);
    }

    /** SavedSql save(sql) */
    public ExecutionResult save(Object[] args) {
        return invoke("save", TYPES_save, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("deleteById".equals(operation)) {
            return deleteById(args);
        } else if ("findAllByConnectionId".equals(operation)) {
            return findAllByConnectionId(args);
        } else if ("findById".equals(operation)) {
            return findById(args);
        } else if ("save".equals(operation)) {
            return save(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ExportUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ExportUseCase#exportCsv.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ExportUseCaseExportCsvScenario {

    @Test
    @DisplayName("UTAPI-012094")
    void case_UTAPI_012094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012094",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012094", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012094", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012094", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012094")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012095")
    void case_UTAPI_012095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012095",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012095", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012095", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012095", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012095")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012096")
    void case_UTAPI_012096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012096",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012096", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012096", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012096", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012096")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012097")
    void case_UTAPI_012097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012097",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012097", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012097", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012097", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012097")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012098")
    void case_UTAPI_012098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012098",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012098", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012098", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012098", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012098")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012099")
    void case_UTAPI_012099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012099",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012099", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012099", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012099", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012099")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012100")
    void case_UTAPI_012100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012100",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012100", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012100", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012100", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012100")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012101")
    void case_UTAPI_012101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012101",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012101", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012101", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012101", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012101")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012102")
    void case_UTAPI_012102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012102",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012102", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012102", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012102", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012102")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012103")
    void case_UTAPI_012103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012103",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012103", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012103", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012103", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012103")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012104")
    void case_UTAPI_012104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012104",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012104", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012104", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012104", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012104")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012105")
    void case_UTAPI_012105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012105",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012105", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012105", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012105", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012105")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012106")
    void case_UTAPI_012106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012106",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012106", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012106", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012106", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012106")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012107")
    void case_UTAPI_012107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012107",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012107", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012107", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012107", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012107")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012108")
    void case_UTAPI_012108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012108",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012108", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012108", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012108", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012108")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012109")
    void case_UTAPI_012109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012109",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012109", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012109", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012109", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012109")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012110")
    void case_UTAPI_012110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012110",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012110", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012110", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012110", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012110")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012111")
    void case_UTAPI_012111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012111",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012111", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012111", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012111", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012111")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012112")
    void case_UTAPI_012112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012112",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012112", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012112", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012112", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012112")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012113")
    void case_UTAPI_012113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012113",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012113", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012113", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012113", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012113")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012114")
    void case_UTAPI_012114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012114",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012114", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012114", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012114", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012114")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012115")
    void case_UTAPI_012115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012115",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012115", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012115", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012115", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012115")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012116")
    void case_UTAPI_012116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012116",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012116", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012116", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012116", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012116")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012117")
    void case_UTAPI_012117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012117",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012117", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012117", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012117", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012117")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012118")
    void case_UTAPI_012118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012118",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012118", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012118", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012118", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012118")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012119")
    void case_UTAPI_012119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012119",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012119", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012119", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012119", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012119")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012120")
    void case_UTAPI_012120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012120",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012120", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012120", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012120", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012120")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012121")
    void case_UTAPI_012121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012121",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012121", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012121", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012121", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012121")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012122")
    void case_UTAPI_012122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012122",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012122", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012122", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012122", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012122")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012123")
    void case_UTAPI_012123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012123",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012123", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012123", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012123", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012123")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012124")
    void case_UTAPI_012124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012124",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012124", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012124", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012124", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012124")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012125")
    void case_UTAPI_012125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012125",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012125", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012125", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012125", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012125")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012126")
    void case_UTAPI_012126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012126",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012126", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012126", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012126", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012126")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012127")
    void case_UTAPI_012127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012127",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012127", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012127", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012127", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012127")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012128")
    void case_UTAPI_012128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012128",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012128", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012128", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012128", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012128")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012129")
    void case_UTAPI_012129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012129",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012129", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012129", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012129", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012129")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012130")
    void case_UTAPI_012130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012130",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012130", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012130", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012130", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012130")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012131")
    void case_UTAPI_012131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012131",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012131", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012131", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012131", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012131")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012132")
    void case_UTAPI_012132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012132",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012132", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012132", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012132", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012132")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012133")
    void case_UTAPI_012133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012133",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012133", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012133", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012133", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012133")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012134")
    void case_UTAPI_012134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012134",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012134", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012134", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012134", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012134")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012135")
    void case_UTAPI_012135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012135",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012135", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012135", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012135", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012135")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012136")
    void case_UTAPI_012136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012136",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012136", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012136", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012136", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012136")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012137")
    void case_UTAPI_012137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012137",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012137", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012137", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012137", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012137")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012138")
    void case_UTAPI_012138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012138",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012138", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012138", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012138", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012138")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012139")
    void case_UTAPI_012139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012139",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012139", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012139", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012139", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012139")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012140")
    void case_UTAPI_012140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012140",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012140", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012140", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012140", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012140")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012141")
    void case_UTAPI_012141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012141",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012141", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012141", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012141", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012141")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012142")
    void case_UTAPI_012142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012142",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012142", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012142", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012142", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012142")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012143")
    void case_UTAPI_012143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012143",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012143", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012143", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012143", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012143")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012144")
    void case_UTAPI_012144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012144",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012144", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012144", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012144", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012144")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012145")
    void case_UTAPI_012145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012145",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012145", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012145", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012145", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012145")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012146")
    void case_UTAPI_012146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012146",
                "com.matsushita.dbeditor.usecase.file.ExportUseCase",
                "exportCsv",
                "byte[]",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012146", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012146", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012146", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012146")
                    .targetId("./java/com/matsushita/dbeditor/usecase/file/ExportUseCase.java::ExportUseCase::exportCsv::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.any declared operation")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be carried out through tableRecordUseCase", "tableRecordUseCase", "")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.any declared operation must carry the value generated for connectionId", "tableRecordUseCase", "", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.any declared operation must carry the value generated for schemaName", "tableRecordUseCase", "", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.any declared operation must carry the value generated for tableName", "tableRecordUseCase", "", "2", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ExportUseCaseWrapper());
    }

}

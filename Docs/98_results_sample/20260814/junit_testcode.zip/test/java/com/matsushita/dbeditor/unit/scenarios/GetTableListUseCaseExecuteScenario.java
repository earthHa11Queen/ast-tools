package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.GetTableListUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for GetTableListUseCase#execute.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class GetTableListUseCaseExecuteScenario {

    @Test
    @DisplayName("UTAPI-013006")
    void case_UTAPI_013006() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013006",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013006", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013006")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013007")
    void case_UTAPI_013007() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013007",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013007", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013007")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013008")
    void case_UTAPI_013008() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013008",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013008", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013008")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013009")
    void case_UTAPI_013009() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013009",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013009", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013009")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013010")
    void case_UTAPI_013010() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013010",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013010", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013010")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013011")
    void case_UTAPI_013011() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013011",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013011", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013011")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013012")
    void case_UTAPI_013012() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013012",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013012", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013012")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013013")
    void case_UTAPI_013013() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013013",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013013", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013013")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013014")
    void case_UTAPI_013014() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013014",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013014", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013014")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013015")
    void case_UTAPI_013015() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013015",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013015", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013015")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013016")
    void case_UTAPI_013016() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013016",
                "com.matsushita.dbeditor.usecase.table.GetTableListUseCase",
                "execute",
                "List<TableMetadata>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013016", "connectionId", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-013016")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/GetTableListUseCase.java::GetTableListUseCase::execute::1::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableMetadataRepository.findAllTables")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableMetadataRepository.findAllTables", "tableMetadataRepository", "findAllTables")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new GetTableListUseCaseWrapper());
    }

}

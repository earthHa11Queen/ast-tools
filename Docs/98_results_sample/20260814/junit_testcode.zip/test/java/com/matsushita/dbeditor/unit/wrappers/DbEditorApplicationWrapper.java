package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;
import org.mockito.MockedStatic;
import org.springframework.boot.SpringApplication;

/**
 * Operation wrapper for DbEditorApplication.
 */
public final class DbEditorApplicationWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.DbEditorApplication";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.DbEditorApplication";
    private static final String[] DEP_NAMES = new String[] {};
    private static final String[] DEP_TYPES = new String[] {};
    private static final String[] TYPES_main = new String[] {"String[]"};

    public DbEditorApplicationWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, true);
    }

    @Override
    protected void openStatics() {
        final DbEditorApplicationWrapper self = this;
        MockedStatic<SpringApplication> mocked = org.mockito.Mockito.mockStatic(SpringApplication.class,
                invocation -> {
                    self.recordStatic("SpringApplication", invocation.getMethod().getName(), invocation.getArguments());
                    Class<?> ret = invocation.getMethod().getReturnType();
                    if (ret == void.class) {
                        return null;
                    } else if (ret.isPrimitive()) {
                        return org.mockito.Answers.RETURNS_DEFAULTS.get().answer(invocation);
                    } else if (ret.isInterface() || !java.lang.reflect.Modifier.isFinal(ret.getModifiers())) {
                        return org.mockito.Mockito.mock(ret);
                    } else {
                        return null;
                    }
                });
        registerCloseable(mocked);
    }

    /** void main(args) */
    public ExecutionResult main(Object[] args) {
        return invoke("main", TYPES_main, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("main".equals(operation)) {
            return main(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

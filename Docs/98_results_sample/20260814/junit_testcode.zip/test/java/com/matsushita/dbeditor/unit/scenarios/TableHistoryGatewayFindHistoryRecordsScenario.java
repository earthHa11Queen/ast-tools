package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryGateway#findHistoryRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryGatewayFindHistoryRecordsScenario {

    @Test
    @DisplayName("UTAPI-004065")
    void case_UTAPI_004065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004065",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004065", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004065", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004065", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004065", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004065", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004065", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004065", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004065", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004065", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004065", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004065", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004065", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004065", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004065")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004066")
    void case_UTAPI_004066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004066",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004066", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004066", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004066", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004066", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004066", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004066", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004066", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004066", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004066", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004066", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004066", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004066", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004066", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004066")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004067")
    void case_UTAPI_004067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004067",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004067", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004067", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004067", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004067", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004067", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004067", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004067", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004067", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004067", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004067", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004067", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004067", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004067", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004067")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004068")
    void case_UTAPI_004068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004068",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004068", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004068", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004068", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004068", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004068", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004068", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004068", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004068", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004068", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004068", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004068", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004068", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004068", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004068")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004069")
    void case_UTAPI_004069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004069",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004069", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004069", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004069", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004069", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004069", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004069", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004069", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004069", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004069", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004069", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004069", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004069", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004069", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004069")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004070")
    void case_UTAPI_004070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004070",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004070", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004070", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004070", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004070", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004070", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004070", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004070", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004070", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004070", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004070", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004070", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004070", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004070", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004070")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004071")
    void case_UTAPI_004071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004071",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004071", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004071", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004071", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004071", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004071", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004071", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004071", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004071", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004071", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004071", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004071", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004071", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004071", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004071")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004072")
    void case_UTAPI_004072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004072",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004072", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004072", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004072", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004072", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004072", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004072", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004072", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004072", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004072", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004072", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004072", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004072", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004072", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004072")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004073")
    void case_UTAPI_004073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004073",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004073", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004073", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004073", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004073", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004073", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004073", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004073", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004073", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004073", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004073", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004073", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004073", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004073", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004073")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004074")
    void case_UTAPI_004074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004074",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004074", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004074", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004074", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004074", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004074", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004074", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004074", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004074", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004074", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004074", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004074", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004074", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004074", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004074")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004075")
    void case_UTAPI_004075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004075",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004075", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004075", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004075", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004075", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004075", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004075", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004075", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004075", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004075", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004075", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004075", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004075", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004075", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004075")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004076")
    void case_UTAPI_004076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004076",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004076", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004076", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004076", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004076", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004076", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004076", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004076", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004076", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004076", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004076", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004076", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004076", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004076", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004076")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004077")
    void case_UTAPI_004077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004077",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004077", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004077", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004077", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004077", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004077", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004077", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004077", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004077", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004077", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004077", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004077", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004077", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004077", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004077")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004078")
    void case_UTAPI_004078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004078",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004078", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004078", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004078", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004078", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004078", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004078", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004078", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004078", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004078", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004078", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004078", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004078", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004078", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004078")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004079")
    void case_UTAPI_004079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004079",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004079", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004079", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004079", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004079", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004079", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004079", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004079", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004079", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004079", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004079", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004079", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004079", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004079", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004079")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004080")
    void case_UTAPI_004080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004080",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004080", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004080", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004080", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004080", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004080", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004080", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004080", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004080", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004080", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004080", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004080", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004080", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004080", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004080")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004081")
    void case_UTAPI_004081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004081",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004081", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004081", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004081", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004081", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004081", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004081", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004081", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004081", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004081", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004081", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004081", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004081", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004081", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004081")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004082")
    void case_UTAPI_004082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004082",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004082", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004082", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004082", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004082", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004082", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004082", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004082", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004082", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004082", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004082", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004082", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004082", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004082", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004082")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004083")
    void case_UTAPI_004083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004083",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004083", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004083", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004083", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004083", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004083", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004083", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004083", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004083", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004083", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004083", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004083", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004083", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004083", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004083")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004084")
    void case_UTAPI_004084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004084",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004084", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004084", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004084", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004084", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004084", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004084", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004084", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004084", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004084", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004084", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004084", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004084", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004084", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004084")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004085")
    void case_UTAPI_004085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004085",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004085", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004085", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004085", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004085", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004085", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004085", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004085", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004085", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004085", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004085", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004085", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004085", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004085", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004085")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004086")
    void case_UTAPI_004086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004086",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004086", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004086", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004086", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004086", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004086", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004086", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004086", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004086", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004086", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004086", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004086", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004086", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004086", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004086")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004087")
    void case_UTAPI_004087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004087",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004087", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004087", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004087", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004087", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004087", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004087", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004087", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004087", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004087", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004087", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004087", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004087", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004087", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004087")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004088")
    void case_UTAPI_004088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004088",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004088", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004088", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004088", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004088", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004088", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004088", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004088", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004088", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004088", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004088", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004088", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004088", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004088", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004088")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004089")
    void case_UTAPI_004089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004089",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004089", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004089", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004089", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004089", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004089", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004089", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004089", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004089", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004089", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004089", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004089", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004089", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004089", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004089")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004090")
    void case_UTAPI_004090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004090",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004090", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004090", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004090", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004090", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004090", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004090", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004090", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004090", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004090", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004090", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004090", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004090", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004090", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004090")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004091")
    void case_UTAPI_004091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004091",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004091", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004091", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004091", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004091", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004091", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004091", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004091", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004091", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004091", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004091", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004091", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004091", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004091", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004091")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004092")
    void case_UTAPI_004092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004092",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004092", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004092", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004092", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004092", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004092", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004092", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004092", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004092", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004092", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004092", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004092", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004092", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004092", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004092")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004093")
    void case_UTAPI_004093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004093",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004093", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004093", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004093", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004093", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004093", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004093", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004093", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004093", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004093", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004093", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004093", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004093", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004093", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004093")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004094")
    void case_UTAPI_004094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004094",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004094", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004094", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004094", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004094", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004094", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004094", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004094", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004094", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004094", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004094", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004094", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004094", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004094", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004094")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004095")
    void case_UTAPI_004095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004095",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004095", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004095", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004095", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004095", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004095", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004095", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004095", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004095", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004095", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004095", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004095", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004095", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004095", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004095")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004096")
    void case_UTAPI_004096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004096",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004096", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004096", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004096", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004096", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004096", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004096", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004096", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004096", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004096", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004096", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004096", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004096", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004096", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004096")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004097")
    void case_UTAPI_004097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004097",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004097", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004097", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004097", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004097", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004097", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004097", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004097", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004097", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004097", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004097", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004097", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004097", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004097", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004097")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004098")
    void case_UTAPI_004098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004098",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004098", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004098", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004098", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004098", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004098", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004098", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004098", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004098", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004098", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004098", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004098", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004098", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004098", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004098")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004099")
    void case_UTAPI_004099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004099",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004099", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004099", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004099", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004099", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004099", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004099", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004099", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004099", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004099", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004099", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004099", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004099", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004099", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004099")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004100")
    void case_UTAPI_004100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004100",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004100", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004100", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004100", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004100", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004100", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004100", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004100", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004100", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004100", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004100", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004100", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004100", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004100", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004100")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004101")
    void case_UTAPI_004101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004101",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004101", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004101", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004101", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004101", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004101", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004101", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004101", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004101", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004101", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004101", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004101", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004101", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004101", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004101")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004102")
    void case_UTAPI_004102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004102",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004102", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004102", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004102", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004102", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004102", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004102", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004102", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004102", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004102", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004102", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004102", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004102", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004102", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004102")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004103")
    void case_UTAPI_004103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004103",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004103", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004103", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004103", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004103", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004103", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004103", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004103", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004103", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004103", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004103", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004103", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004103", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004103", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004103")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004104")
    void case_UTAPI_004104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004104",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004104", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004104", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004104", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004104", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004104", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004104", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004104", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004104", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004104", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004104", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004104", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004104", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004104", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004104")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004105")
    void case_UTAPI_004105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004105",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004105", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004105", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004105", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004105", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004105", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004105", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004105", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004105", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004105", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004105", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004105", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004105", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004105", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004105")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004106")
    void case_UTAPI_004106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004106",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004106", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004106", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004106", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004106", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004106", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004106", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004106", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004106", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004106", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004106", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004106", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004106", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004106", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004106")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004107")
    void case_UTAPI_004107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004107",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004107", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004107", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004107", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004107", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004107", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004107", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004107", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004107", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004107", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004107", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004107", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004107", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004107", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004107")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004108")
    void case_UTAPI_004108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004108",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004108", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004108", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004108", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004108", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004108", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004108", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004108", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004108", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004108", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004108", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004108", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004108", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004108", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004108")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004109")
    void case_UTAPI_004109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004109",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004109", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004109", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004109", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004109", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004109", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004109", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004109", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004109", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004109", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004109", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004109", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004109", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004109", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004109")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004110")
    void case_UTAPI_004110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004110",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004110", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004110", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004110", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004110", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004110", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004110", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004110", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004110", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004110", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004110", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004110", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004110", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004110", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004110")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004111")
    void case_UTAPI_004111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004111",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004111", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004111", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004111", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004111", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004111", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004111", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004111", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004111", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004111", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004111", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004111", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004111", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004111", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004111")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004112")
    void case_UTAPI_004112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004112",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004112", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004112", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004112", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004112", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004112", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004112", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004112", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004112", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004112", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004112", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004112", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004112", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004112", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004112")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004113")
    void case_UTAPI_004113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004113",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004113", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004113", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004113", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004113", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004113", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004113", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004113", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004113", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004113", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004113", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004113", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004113", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004113", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004113")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004114")
    void case_UTAPI_004114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004114",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004114", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004114", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004114", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004114", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004114", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004114", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004114", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004114", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004114", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004114", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004114", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004114", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004114", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004114")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004115")
    void case_UTAPI_004115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004115",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004115", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004115", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004115", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004115", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004115", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004115", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004115", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004115", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004115", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004115", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004115", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004115", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004115", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004115")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004116")
    void case_UTAPI_004116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004116",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004116", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004116", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004116", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004116", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004116", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004116", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004116", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004116", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004116", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004116", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004116", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004116", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004116", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004116")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004117")
    void case_UTAPI_004117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004117",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004117", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004117", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004117", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004117", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004117", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004117", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004117", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004117", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004117", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004117", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004117", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004117", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004117", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004117")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004118")
    void case_UTAPI_004118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004118",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004118", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004118", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004118", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004118", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004118", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004118", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004118", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004118", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004118", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004118", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004118", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004118", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004118", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004118")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004119")
    void case_UTAPI_004119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004119",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004119", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004119", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004119", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004119", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004119", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004119", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004119", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004119", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004119", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004119", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004119", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004119", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004119", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004119")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004120")
    void case_UTAPI_004120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004120",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004120", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004120", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004120", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004120", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004120", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004120", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004120", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004120", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004120", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004120", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004120", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004120", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004120", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004120")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004121")
    void case_UTAPI_004121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004121",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004121", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004121", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004121", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004121", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004121", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004121", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004121", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004121", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004121", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004121", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004121", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004121", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004121", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004121")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004122")
    void case_UTAPI_004122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004122",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004122", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004122", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004122", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004122", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004122", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004122", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004122", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004122", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004122", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004122", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004122", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004122", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004122", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004122")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004123")
    void case_UTAPI_004123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004123",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004123", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004123", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004123", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004123", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004123", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004123", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004123", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004123", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004123", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004123", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004123", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004123", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004123", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004123")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004124")
    void case_UTAPI_004124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004124",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004124", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004124", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004124", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004124", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004124", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004124", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004124", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004124", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004124", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004124", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004124", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004124", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004124", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004124")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004125")
    void case_UTAPI_004125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004125",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004125", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004125", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004125", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004125", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004125", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004125", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004125", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004125", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004125", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004125", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004125", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004125", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004125", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004125")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004126")
    void case_UTAPI_004126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004126",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004126", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004126", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004126", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004126", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004126", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004126", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004126", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004126", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004126", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004126", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004126", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004126", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004126", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004126")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004127")
    void case_UTAPI_004127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004127",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004127", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004127", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004127", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004127", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004127", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004127", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004127", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004127", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004127", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004127", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004127", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004127", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004127", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004127")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004128")
    void case_UTAPI_004128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004128",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004128", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004128", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004128", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004128", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004128", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004128", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004128", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004128", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004128", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004128", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004128", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004128", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004128", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004128")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004129")
    void case_UTAPI_004129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004129",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004129", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004129", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004129", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004129", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004129", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004129", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004129", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004129", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004129", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004129", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004129", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004129", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004129", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004129")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004130")
    void case_UTAPI_004130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004130",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004130", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004130", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004130", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004130", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004130", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004130", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004130", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004130", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004130", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004130", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004130", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004130", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004130", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004130")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004131")
    void case_UTAPI_004131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004131",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004131", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004131", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004131", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004131", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004131", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004131", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004131", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004131", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004131", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004131", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004131", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004131", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004131", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004131")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004132")
    void case_UTAPI_004132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004132",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004132", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004132", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004132", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004132", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004132", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004132", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004132", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004132", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004132", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004132", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004132", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004132", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004132", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004132")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004133")
    void case_UTAPI_004133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004133",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004133", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004133", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004133", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004133", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004133", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004133", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004133", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004133", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004133", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004133", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004133", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004133", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004133", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004133")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004134")
    void case_UTAPI_004134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004134",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004134", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004134", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004134", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004134", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004134", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004134", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004134", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004134", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004134", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004134", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004134", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004134", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004134", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004134")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004135")
    void case_UTAPI_004135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004135",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004135", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004135", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004135", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004135", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004135", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004135", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004135", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004135", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004135", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004135", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004135", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004135", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004135", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004135")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004136")
    void case_UTAPI_004136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004136",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004136", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004136", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004136", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004136", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004136", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004136", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004136", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004136", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004136", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004136", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004136", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004136", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004136", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004136")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004137")
    void case_UTAPI_004137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004137",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004137", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004137", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004137", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004137", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004137", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004137", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004137", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004137", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004137", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004137", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004137", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004137", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004137", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004137")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004138")
    void case_UTAPI_004138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004138",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004138", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004138", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004138", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004138", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004138", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004138", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004138", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004138", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004138", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004138", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004138", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004138", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004138", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004138")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004139")
    void case_UTAPI_004139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004139",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004139", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004139", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004139", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004139", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004139", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004139", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004139", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004139", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004139", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004139", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004139", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004139", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004139", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004139")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004140")
    void case_UTAPI_004140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004140",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004140", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004140", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004140", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004140", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004140", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004140", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004140", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004140", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004140", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004140", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004140", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004140", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004140", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004140")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004141")
    void case_UTAPI_004141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004141",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004141", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004141", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004141", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004141", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004141", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004141", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004141", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004141", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004141", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004141", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004141", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004141", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004141", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004141")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004142")
    void case_UTAPI_004142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004142",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004142", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004142", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004142", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004142", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004142", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004142", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004142", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004142", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004142", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004142", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004142", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004142", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004142", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004142")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004143")
    void case_UTAPI_004143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004143",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004143", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004143", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004143", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004143", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004143", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004143", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004143", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004143", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004143", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004143", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004143", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004143", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004143", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004143")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004144")
    void case_UTAPI_004144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004144",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004144", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004144", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004144", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004144", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004144", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004144", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004144", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004144", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004144", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004144", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004144", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004144", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004144", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004144")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004145")
    void case_UTAPI_004145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004145",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004145", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004145", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004145", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004145", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004145", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004145", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004145", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004145", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004145", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004145", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004145", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004145", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004145", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004145")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004146")
    void case_UTAPI_004146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004146",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004146", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004146", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004146", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004146", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004146", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004146", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004146", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004146", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004146", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004146", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004146", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004146", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004146", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004146")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004147")
    void case_UTAPI_004147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004147",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004147", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004147", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004147", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004147", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004147", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004147", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004147", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004147", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004147", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004147", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004147", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004147", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004147", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004147")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004148")
    void case_UTAPI_004148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004148",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004148", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004148", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004148", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004148", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004148", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004148", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004148", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004148", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004148", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004148", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004148", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004148", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004148", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004148")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004149")
    void case_UTAPI_004149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004149",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004149", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004149", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004149", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004149", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004149", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004149", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004149", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004149", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004149", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004149", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004149", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004149", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004149", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004149")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004150")
    void case_UTAPI_004150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004150",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004150", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004150", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004150", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004150", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004150", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004150", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004150", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004150", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004150", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004150", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004150", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004150", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004150", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004150")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004151")
    void case_UTAPI_004151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004151",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004151", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004151", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004151", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004151", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004151", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004151", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004151", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004151", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004151", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004151", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004151", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004151", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004151", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004151")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004152")
    void case_UTAPI_004152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004152",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004152", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004152", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004152", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004152", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004152", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004152", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004152", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004152", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004152", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004152", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004152", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004152", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004152", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004152")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004153")
    void case_UTAPI_004153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004153",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004153", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004153", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004153", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004153", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004153", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004153", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004153", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004153", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004153", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004153", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004153", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004153", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004153", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004153")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004154")
    void case_UTAPI_004154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004154",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004154", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004154", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004154", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004154", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004154", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004154", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004154", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004154", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004154", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004154", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004154", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004154", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004154", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004154")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004155")
    void case_UTAPI_004155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004155",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004155", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004155", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004155", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004155", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004155", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004155", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004155", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004155", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004155", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004155", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004155", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004155", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004155", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004155")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004156")
    void case_UTAPI_004156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004156",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004156", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004156", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004156", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004156", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004156", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004156", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004156", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004156", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004156", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004156", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004156", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004156", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004156", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004156")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004157")
    void case_UTAPI_004157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004157",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004157", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004157", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004157", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004157", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004157", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004157", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004157", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004157", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004157", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004157", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004157", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004157", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004157", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004157")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004158")
    void case_UTAPI_004158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004158",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004158", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004158", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004158", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004158", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004158", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004158", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004158", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004158", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004158", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004158", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004158", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004158", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004158", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004158")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004159")
    void case_UTAPI_004159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004159",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004159", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004159", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004159", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004159", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004159", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004159", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004159", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004159", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004159", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004159", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004159", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004159", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004159", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004159")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004160")
    void case_UTAPI_004160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004160",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004160", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004160", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004160", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004160", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004160", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004160", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004160", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004160", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004160", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004160", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004160", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004160", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004160", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004160")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004161")
    void case_UTAPI_004161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004161",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004161", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004161", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004161", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004161", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004161", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004161", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004161", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004161", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004161", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004161", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004161", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004161", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004161", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004161")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004162")
    void case_UTAPI_004162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004162",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004162", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004162", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004162", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004162", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004162", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004162", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004162", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004162", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004162", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004162", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004162", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004162", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004162", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004162")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004163")
    void case_UTAPI_004163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004163",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004163", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004163", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004163", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004163", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004163", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004163", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004163", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004163", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004163", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004163", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004163", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004163", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004163", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004163")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004164")
    void case_UTAPI_004164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004164",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004164", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004164", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004164", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004164", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004164", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004164", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004164", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004164", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004164", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004164", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004164", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004164", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004164", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004164")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004165")
    void case_UTAPI_004165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004165",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004165", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004165", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004165", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004165", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004165", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004165", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004165", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004165", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004165", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004165", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004165", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004165", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004165", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004165")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004166")
    void case_UTAPI_004166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004166",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004166", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004166", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004166", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004166", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004166", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004166", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004166", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004166", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004166", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004166", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004166", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004166", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004166", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004166")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004167")
    void case_UTAPI_004167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004167",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004167", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004167", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004167", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004167", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004167", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004167", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004167", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004167", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004167", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004167", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004167", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004167", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004167", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004167")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004168")
    void case_UTAPI_004168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004168",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004168", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004168", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004168", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004168", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004168", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004168", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004168", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004168", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004168", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004168", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004168", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004168", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004168", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004168")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004169")
    void case_UTAPI_004169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004169",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004169", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004169", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004169", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004169", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004169", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004169", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004169", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004169", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004169", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004169", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004169", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004169", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004169", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004169")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004170")
    void case_UTAPI_004170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004170",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004170", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004170", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004170", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004170", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004170", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004170", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004170", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004170", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004170", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004170", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004170", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004170", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004170", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004170")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004171")
    void case_UTAPI_004171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004171",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004171", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004171", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004171", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004171", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004171", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004171", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004171", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004171", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004171", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004171", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004171", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004171", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004171", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004171")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004172")
    void case_UTAPI_004172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004172",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004172", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004172", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004172", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004172", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004172", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004172", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004172", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004172", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004172", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004172", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004172", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004172", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004172", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004172")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004173")
    void case_UTAPI_004173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004173",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004173", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004173", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004173", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004173", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004173", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004173", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004173", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004173", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004173", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004173", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004173", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004173", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004173", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004173")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004174")
    void case_UTAPI_004174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004174",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004174", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004174", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004174", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004174", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004174", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004174", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004174", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004174", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004174", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004174", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004174", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004174", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004174", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004174")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004175")
    void case_UTAPI_004175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004175",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004175", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004175", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004175", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004175", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004175", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004175", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004175", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004175", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004175", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004175", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004175", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004175", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004175", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004175")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004176")
    void case_UTAPI_004176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004176",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004176", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004176", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004176", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004176", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004176", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004176", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004176", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004176", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004176", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004176", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004176", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004176", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004176", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004176")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004177")
    void case_UTAPI_004177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004177",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004177", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004177", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004177", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004177", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004177", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004177", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004177", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004177", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004177", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004177", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004177", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004177", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004177", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004177")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004178")
    void case_UTAPI_004178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004178",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004178", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004178", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004178", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004178", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004178", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004178", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004178", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004178", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004178", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004178", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004178", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004178", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004178", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004178")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004179")
    void case_UTAPI_004179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004179",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004179", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004179", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004179", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004179", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004179", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004179", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004179", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004179", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004179", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004179", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004179", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004179", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004179", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004179")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004180")
    void case_UTAPI_004180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004180",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004180", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004180", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004180", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004180", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004180", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004180", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004180", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004180", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004180", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004180", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004180", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004180", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004180", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004180")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004181")
    void case_UTAPI_004181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004181",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004181", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004181", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004181", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004181", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004181", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004181", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004181", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004181", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004181", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004181", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004181", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004181", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004181", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004181")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004182")
    void case_UTAPI_004182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004182",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004182", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004182", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004182", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004182", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004182", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004182", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004182", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004182", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004182", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004182", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004182", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004182", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004182", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004182")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004183")
    void case_UTAPI_004183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004183",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004183", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004183", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004183", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004183", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004183", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004183", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004183", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004183", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004183", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004183", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004183", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004183", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004183", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004183")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004184")
    void case_UTAPI_004184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004184",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004184", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004184", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004184", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004184", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004184", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004184", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004184", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004184", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004184", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004184", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004184", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004184", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004184", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004184")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004185")
    void case_UTAPI_004185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004185",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004185", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004185", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004185", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004185", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004185", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004185", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004185", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004185", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004185", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004185", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004185", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004185", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004185", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004185")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004186")
    void case_UTAPI_004186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004186",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004186", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004186", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004186", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004186", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004186", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004186", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004186", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004186", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004186", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004186", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004186", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004186", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004186", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004186")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004187")
    void case_UTAPI_004187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004187",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004187", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004187", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004187", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004187", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004187", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004187", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004187", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004187", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004187", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004187", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004187", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004187", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004187", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004187")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004188")
    void case_UTAPI_004188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004188",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004188", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004188", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004188", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004188", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004188", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004188", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004188", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004188", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004188", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004188", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004188", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004188", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004188", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004188")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004189")
    void case_UTAPI_004189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004189",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004189", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004189", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004189", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004189", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004189", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004189", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004189", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004189", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004189", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004189", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004189", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004189", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004189", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004189")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004190")
    void case_UTAPI_004190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004190",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004190", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004190", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004190", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004190", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004190", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004190", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004190", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004190", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004190", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004190", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004190", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004190", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004190", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004190")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004191")
    void case_UTAPI_004191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004191",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004191", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004191", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004191", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004191", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004191", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004191", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004191", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004191", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004191", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004191", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004191", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004191", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004191", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004191")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004192")
    void case_UTAPI_004192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004192",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004192", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004192", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004192", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004192", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004192", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004192", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004192", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004192", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004192", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004192", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004192", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004192", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004192", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004192")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004193")
    void case_UTAPI_004193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004193",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004193", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004193", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004193", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004193", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004193", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004193", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004193", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004193", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004193", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004193", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004193", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004193", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004193", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004193")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004194")
    void case_UTAPI_004194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004194",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004194", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004194", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004194", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004194", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004194", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004194", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004194", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004194", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004194", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004194", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004194", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004194", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004194", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004194")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004195")
    void case_UTAPI_004195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004195",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004195", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004195", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004195", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004195", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004195", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004195", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004195", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004195", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004195", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004195", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004195", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004195", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004195", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004195")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004196")
    void case_UTAPI_004196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004196",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004196", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004196", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004196", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004196", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004196", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004196", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004196", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004196", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004196", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004196", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004196", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004196", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004196", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004196")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004197")
    void case_UTAPI_004197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004197",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004197", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004197", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004197", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004197", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004197", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004197", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004197", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004197", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004197", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004197", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004197", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004197", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004197", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004197")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004198")
    void case_UTAPI_004198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004198",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004198", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004198", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004198", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004198", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004198", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004198", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004198", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004198", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004198", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004198", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004198", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004198", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004198", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004198")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004199")
    void case_UTAPI_004199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004199",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004199", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004199", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004199", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004199", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004199", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004199", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004199", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004199", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004199", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004199", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004199", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004199", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004199", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004199")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004200")
    void case_UTAPI_004200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004200",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004200", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004200", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004200", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004200", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004200", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004200", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004200", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004200", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004200", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004200", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004200", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004200", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004200", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004200")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004201")
    void case_UTAPI_004201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004201",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004201", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004201", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004201", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004201", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004201", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004201", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004201", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004201", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004201", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004201", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004201", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004201", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004201", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004201")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004202")
    void case_UTAPI_004202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004202",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004202", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004202", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004202", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004202", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004202", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004202", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004202", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004202", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004202", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004202", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004202", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004202", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004202", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004202")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004203")
    void case_UTAPI_004203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004203",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004203", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004203", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004203", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004203", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004203", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004203", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004203", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004203", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004203", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004203", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004203", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004203", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004203", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004203")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004204")
    void case_UTAPI_004204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004204",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004204", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004204", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004204", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004204", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004204", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004204", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004204", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004204", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004204", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004204", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004204", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004204", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004204", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004204")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004205")
    void case_UTAPI_004205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004205",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004205", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004205", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004205", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004205", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004205", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004205", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004205", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004205", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004205", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004205", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004205", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004205", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004205", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004205")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004206")
    void case_UTAPI_004206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004206",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004206", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004206", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004206", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004206", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004206", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004206", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004206", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004206", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004206", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004206", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004206", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004206", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004206", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004206")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004207")
    void case_UTAPI_004207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004207",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004207", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004207", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004207", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004207", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004207", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004207", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004207", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004207", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004207", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004207", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004207", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004207", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004207", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004207")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004208")
    void case_UTAPI_004208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004208",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004208", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004208", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004208", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004208", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004208", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004208", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004208", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004208", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004208", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004208", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004208", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004208", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004208", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004208")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004209")
    void case_UTAPI_004209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004209",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004209", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004209", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004209", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004209", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004209", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004209", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004209", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004209", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004209", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004209", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004209", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004209", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004209", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004209")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004210")
    void case_UTAPI_004210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004210",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004210", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004210", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004210", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004210", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004210", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004210", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004210", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004210", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004210", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004210", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004210", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004210", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004210", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004210")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004211")
    void case_UTAPI_004211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004211",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004211", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004211", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004211", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004211", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004211", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004211", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004211", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004211", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004211", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004211", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004211", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004211", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004211", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004211")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004212")
    void case_UTAPI_004212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004212",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004212", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004212", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004212", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004212", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004212", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004212", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004212", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004212", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004212", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004212", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004212", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004212", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004212", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004212")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004213")
    void case_UTAPI_004213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004213",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004213", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004213", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004213", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004213", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004213", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004213", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004213", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004213", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004213", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004213", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004213", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004213", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004213", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004213")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004214")
    void case_UTAPI_004214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004214",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004214", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004214", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004214", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004214", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004214", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004214", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004214", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004214", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004214", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004214", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004214", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004214", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004214", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004214")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004215")
    void case_UTAPI_004215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004215",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004215", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004215", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004215", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004215", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004215", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004215", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004215", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004215", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004215", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004215", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004215", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004215", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004215", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004215")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004216")
    void case_UTAPI_004216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004216",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004216", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004216", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004216", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004216", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004216", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004216", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004216", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004216", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004216", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004216", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004216", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004216", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004216", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004216")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004217")
    void case_UTAPI_004217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004217",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004217", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004217", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004217", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004217", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004217", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004217", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004217", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004217", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004217", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004217", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004217", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004217", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004217", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004217")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004218")
    void case_UTAPI_004218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004218",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004218", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004218", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004218", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004218", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004218", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004218", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004218", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004218", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004218", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004218", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004218", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004218", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004218", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004218")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004219")
    void case_UTAPI_004219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004219",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004219", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004219", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004219", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004219", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004219", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004219", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004219", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004219", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004219", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004219", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004219", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004219", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004219", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004219")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004220")
    void case_UTAPI_004220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004220",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004220", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004220", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004220", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004220", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004220", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004220", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004220", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004220", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004220", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004220", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004220", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004220", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004220", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004220")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004221")
    void case_UTAPI_004221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004221",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004221", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004221", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004221", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004221", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004221", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004221", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004221", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004221", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004221", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004221", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004221", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004221", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004221", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004221")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004222")
    void case_UTAPI_004222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004222",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004222", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004222", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004222", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004222", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004222", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004222", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004222", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004222", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004222", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004222", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004222", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004222", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004222", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004222")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004223")
    void case_UTAPI_004223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004223",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004223", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004223", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004223", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004223", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004223", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004223", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004223", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004223", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004223", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004223", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004223", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004223", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004223", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004223")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004224")
    void case_UTAPI_004224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004224",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004224", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004224", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004224", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004224", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004224", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004224", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004224", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004224", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004224", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004224", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004224", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004224", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004224", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004224")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004225")
    void case_UTAPI_004225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004225",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004225", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004225", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004225", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004225", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004225", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004225", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004225", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004225", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004225", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004225", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004225", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004225", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004225", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004225")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004226")
    void case_UTAPI_004226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004226",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004226", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004226", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004226", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004226", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004226", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004226", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004226", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004226", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004226", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004226", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004226", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004226", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004226", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004226")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004227")
    void case_UTAPI_004227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004227",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004227", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004227", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004227", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004227", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004227", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004227", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004227", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004227", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004227", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004227", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004227", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004227", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004227", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004227")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004228")
    void case_UTAPI_004228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004228",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004228", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004228", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004228", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004228", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004228", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004228", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004228", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004228", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004228", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004228", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004228", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004228", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004228", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004228")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004229")
    void case_UTAPI_004229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004229",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004229", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004229", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004229", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004229", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004229", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004229", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004229", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004229", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004229", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004229", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004229", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004229", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004229", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004229")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004230")
    void case_UTAPI_004230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004230",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004230", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004230", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004230", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004230", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004230", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004230", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004230", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004230", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004230", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004230", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004230", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004230", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004230", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004230")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004231")
    void case_UTAPI_004231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004231",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004231", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004231", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004231", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004231", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004231", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004231", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004231", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004231", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004231", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004231", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004231", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004231", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004231", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004231")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004232")
    void case_UTAPI_004232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004232",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004232", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004232", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004232", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004232", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004232", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004232", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004232", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004232", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004232", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004232", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004232", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004232", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004232", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004232")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004233")
    void case_UTAPI_004233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004233",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004233", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004233", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004233", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004233", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004233", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004233", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004233", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004233", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004233", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004233", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004233", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004233", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004233", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004233")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004234")
    void case_UTAPI_004234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004234",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004234", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004234", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004234", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004234", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004234", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004234", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004234", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004234", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004234", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004234", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004234", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004234", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004234", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004234")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004235")
    void case_UTAPI_004235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004235",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004235", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004235", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004235", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004235", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004235", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004235", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004235", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004235", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004235", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004235", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004235", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004235", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004235", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004235")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004236")
    void case_UTAPI_004236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004236",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004236", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004236", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004236", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004236", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004236", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004236", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004236", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004236", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004236", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004236", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004236", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004236", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004236", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004236")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004237")
    void case_UTAPI_004237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004237",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004237", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004237", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004237", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004237", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004237", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004237", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004237", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004237", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004237", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004237", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004237", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004237", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004237", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004237")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004238")
    void case_UTAPI_004238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004238",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004238", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004238", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004238", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004238", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004238", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004238", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004238", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004238", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004238", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004238", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004238", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004238", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004238", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004238")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004239")
    void case_UTAPI_004239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004239",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004239", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004239", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004239", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004239", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004239", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004239", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004239", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004239", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004239", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004239", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004239", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004239", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004239", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004239")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004240")
    void case_UTAPI_004240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004240",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004240", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004240", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004240", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004240", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004240", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004240", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004240", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004240", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004240", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004240", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004240", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004240", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004240", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004240")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004241")
    void case_UTAPI_004241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004241",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004241", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004241", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004241", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004241", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004241", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004241", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004241", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004241", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004241", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004241", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004241", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004241", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004241", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004241")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004242")
    void case_UTAPI_004242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004242",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004242", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004242", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004242", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004242", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004242", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004242", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004242", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004242", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004242", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004242", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004242", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004242", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004242", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004242")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004243")
    void case_UTAPI_004243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004243",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004243", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004243", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004243", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004243", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004243", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004243", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004243", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004243", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004243", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004243", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004243", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004243", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004243", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004243")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004244")
    void case_UTAPI_004244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004244",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004244", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004244", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004244", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004244", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004244", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004244", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004244", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004244", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004244", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004244", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004244", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004244", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004244", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004244")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004245")
    void case_UTAPI_004245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004245",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004245", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004245", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004245", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004245", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004245", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004245", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004245", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004245", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004245", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004245", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004245", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004245", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004245", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004245")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004246")
    void case_UTAPI_004246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004246",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004246", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004246", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004246", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004246", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004246", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004246", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004246", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004246", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004246", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004246", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004246", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004246", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004246", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004246")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004247")
    void case_UTAPI_004247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004247",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004247", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004247", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004247", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004247", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004247", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004247", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004247", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004247", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004247", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004247", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004247", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004247", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-004247", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004247")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested seq", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004248")
    void case_UTAPI_004248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004248",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004248", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004248", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004248", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004248", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004248", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004248", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004248", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004248", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004248", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004248", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004248", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004248", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004248", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004248")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "1:length_null", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004249")
    void case_UTAPI_004249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004249",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004249", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004249", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004249", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004249", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004249", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004249", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004249", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004249", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004249", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004249", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004249", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004249", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004249", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004249")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "2:length_empty", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004250")
    void case_UTAPI_004250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004250",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004250", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004250", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004250", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004250", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004250", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004250", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004250", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004250", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004250", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004250", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004250", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004250", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004250", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004250")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "3:length_min", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004251")
    void case_UTAPI_004251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004251",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004251", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004251", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004251", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004251", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004251", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004251", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004251", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004251", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004251", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004251", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004251", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004251", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004251", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004251")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004252")
    void case_UTAPI_004252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004252",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004252", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004252", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004252", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004252", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004252", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004252", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004252", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004252", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004252", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004252", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004252", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004252", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004252", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004252")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "5:length_max", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004253")
    void case_UTAPI_004253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004253",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004253", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004253", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004253", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004253", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004253", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004253", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004253", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004253", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004253", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004253", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004253", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004253", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004253", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004253")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004254")
    void case_UTAPI_004254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004254",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004254", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004254", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004254", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004254", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004254", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004254", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004254", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004254", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004254", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004254", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004254", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004254", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004254", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004254")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004255")
    void case_UTAPI_004255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004255",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004255", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004255", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004255", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004255", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004255", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004255", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004255", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004255", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004255", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004255", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004255", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004255", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004255", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004255")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("46:hw_integer", "-", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004256")
    void case_UTAPI_004256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004256",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004256", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004256", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004256", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004256", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004256", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004256", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004256", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004256", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004256", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004256", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004256", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004256", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004256", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004256")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "-", "12:integer_positive")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004257")
    void case_UTAPI_004257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004257",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004257", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004257", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004257", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004257", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004257", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004257", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004257", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004257", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004257", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004257", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004257", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004257", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004257", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004257")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "-", "13:integer_negative")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-004258")
    void case_UTAPI_004258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-004258",
                "com.matsushita.dbeditor.adapter.gateway.TableHistoryGateway",
                "findHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-004258", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-004258", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004258", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004258", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004258", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004258", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004258", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004258", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004258", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-004258", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-004258", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004258", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-004258", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-004258")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableHistoryGateway.java::TableHistoryGateway::findHistoryRecords::5::ARG::4::-::seq")
                    .mirror("-", "-", "14:integer_zero")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for seq reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.RETURN_SIZE_EQUALS, "the read operation must expose exactly the rows the database returned", "1")
                    .check(CheckType.VALUE_REACHED, "the value generated for seq must reach the executed statement unchanged", "JdbcTemplate", "", "data:seq")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryGatewayWrapper());
    }

}

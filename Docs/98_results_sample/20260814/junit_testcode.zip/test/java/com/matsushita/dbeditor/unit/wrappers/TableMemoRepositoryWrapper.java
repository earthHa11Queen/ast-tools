package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableMemoRepository.
 *
 * <p>TableMemoRepository is an abstract contract. The contract is exercised through its
 * production implementation TableMemoGateway so the Oracle observes the real contract
 * behaviour instead of a self recorded mock invocation.</p>
 */
public final class TableMemoRepositoryWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.domain.repository.TableMemoRepository";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.gateway.TableMemoGateway";
    private static final String[] DEP_NAMES = new String[] {"jdbcTemplate", "SCHEMA", "rowMapper"};
    private static final String[] DEP_TYPES = new String[] {"JdbcTemplate", "String", "RowMapper<TableMemo>"};
    private static final String[] TYPES_findByConnectionIdAndTableName = new String[] {"Integer", "String"};
    private static final String[] TYPES_upsert = new String[] {"TableMemo"};

    public TableMemoRepositoryWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
        registry().setGenericHint("TableMemo");
    }

    /** Optional<TableMemo> findByConnectionIdAndTableName(connectionId, tableName) */
    public ExecutionResult findByConnectionIdAndTableName(Object[] args) {
        return invoke("findByConnectionIdAndTableName", TYPES_findByConnectionIdAndTableName, args);
    }

    /** TableMemo upsert(memo) */
    public ExecutionResult upsert(Object[] args) {
        return invoke("upsert", TYPES_upsert, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("findByConnectionIdAndTableName".equals(operation)) {
            return findByConnectionIdAndTableName(args);
        } else if ("upsert".equals(operation)) {
            return upsert(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

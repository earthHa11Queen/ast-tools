package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.GlobalExceptionHandlerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for GlobalExceptionHandler#handleRuntime.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class GlobalExceptionHandlerHandleRuntimeScenario {

    @Test
    @DisplayName("UTAPI-011494")
    void case_UTAPI_011494() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011494",
                "com.matsushita.dbeditor.infrastructure.exception.GlobalExceptionHandler",
                "handleRuntime",
                "ResponseEntity<Map<String,String>>",
                new ParamSpec[] {
                    new ParamSpec("ex", "RuntimeException", "ex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011494", "ex", "TARGET", "OBJECT", "RuntimeException")
                },
                OraclePlan.builder("UTAPI-011494")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/exception/GlobalExceptionHandler.java::GlobalExceptionHandler::handleRuntime::2::ARG::1::-::ex")
                    .mirror("-", "1:length_null", "-")
                    .target("ex", "ex")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.ERROR_RESPONSE_MAPPING)
                    .observation("the status and body of the response produced by the handler")
                    .expected("an invalid argument is answered with a client error status and an unexpected runtime failure with a server error status, carrying an error body")
                    .failure("the failure is answered with a success status or with an empty body")
                    .assertion("assert the status class and assertNotNull on the body")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "a missing exception cannot be mapped to a response", "java.lang.RuntimeException", "", "data:ex")
                    .check(CheckType.RETURN_NOT_NULL, "a produced response must exist")
                    .check(CheckType.RETURN_STATUS_SERVER_ERROR, "the produced response must use the status class of the handled exception")
                    .build()),
            new GlobalExceptionHandlerWrapper());
    }

    @Test
    @DisplayName("UTAPI-011495")
    void case_UTAPI_011495() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011495",
                "com.matsushita.dbeditor.infrastructure.exception.GlobalExceptionHandler",
                "handleRuntime",
                "ResponseEntity<Map<String,String>>",
                new ParamSpec[] {
                    new ParamSpec("ex", "RuntimeException", "ex")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011495", "ex", "TARGET", "OBJECT", "RuntimeException")
                },
                OraclePlan.builder("UTAPI-011495")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/exception/GlobalExceptionHandler.java::GlobalExceptionHandler::handleRuntime::2::ARG::1::-::ex")
                    .mirror("-", "2:length_empty", "-")
                    .target("ex", "ex")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.ERROR_RESPONSE_MAPPING)
                    .observation("the status and body of the response produced by the handler")
                    .expected("an invalid argument is answered with a client error status and an unexpected runtime failure with a server error status, carrying an error body")
                    .failure("the failure is answered with a success status or with an empty body")
                    .assertion("assert the status class and assertNotNull on the body")
                    .check(CheckType.NO_EXCEPTION, "the handler must map the exception instead of failing")
                    .check(CheckType.RETURN_NOT_NULL, "the handler must produce a response")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry an error body")
                    .check(CheckType.RETURN_BODY_CONTAINS_VALUE, "the error body must report the message of the handled exception", "prop:ex#getMessage")
                    .check(CheckType.RETURN_STATUS_SERVER_ERROR, "the response must use the status class of the handled exception")
                    .build()),
            new GlobalExceptionHandlerWrapper());
    }

}

package com.matsushita.dbeditor.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.matsushita.dbeditor.unit.wrappers.SutWrapper;

/**
 * Turns the Oracle Plan of one CaseNo into the real PASS / FAIL decision.
 *
 * <p>The plan is not decoration. Every check it carries is evaluated here, and the expected
 * condition of a check is resolved against the values TestDataRuntime produced for this
 * CaseNo, so two Cases that differ only in their Mirror condition are judged against
 * different expected values.</p>
 */
public final class CaseOracle {

    private CaseOracle() {
    }

    public static void verify(CaseDefinition def, SutWrapper wrapper, Arguments args, ExecutionResult result) {
        OraclePlan plan = def.plan();
        if (result.isException() && result.thrown() instanceof HarnessException) {
            throw new HarnessException("Harness failure while executing " + def.caseNo(), result.thrown());
        }
        List<Interaction> interactions = wrapper.interactions();
        List<String> failures = new ArrayList<String>();
        List<OracleCheck> checks = plan.checks();
        if (checks.isEmpty()) {
            failures.add("Oracle Plan carries no executable check.");
        }
        boolean rejectionTolerated = false;
        for (int i = 0; i < checks.size(); i++) {
            if (checks.get(i).type() == CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED) {
                rejectionTolerated = true;
            }
        }
        boolean rejected = result.isException() && rejectionTolerated;
        for (int i = 0; i < checks.size(); i++) {
            OracleCheck check = checks.get(i);
            if (rejected && !appliesAfterRejection(check.type())) {
                continue;
            }
            try {
                String failure = evaluate(check, def, wrapper, args, result, interactions);
                if (failure != null) {
                    failures.add(check.type() + ": " + check.description() + " -> " + failure);
                }
            } catch (HarnessException e) {
                throw e;
            } catch (Throwable t) {
                failures.add(check.type() + ": " + check.description() + " -> evaluation error " + t);
            }
        }
        if (!failures.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            sb.append(plan.describe()).append('\n');
            sb.append("  Observed exception=").append(result.isException() ? render(result.thrown()) : "none")
              .append('\n');
            sb.append("  Observed return=").append(ValueSupport.render(result.returnValue())).append('\n');
            sb.append("  Observed interactions=").append(interactions).append('\n');
            for (int i = 0; i < failures.size(); i++) {
                sb.append("  [FAIL] ").append(failures.get(i)).append('\n');
            }
            org.junit.jupiter.api.Assertions.fail(sb.toString());
        }
    }

    private static String render(Throwable t) {
        if (t == null) {
            return "none";
        }
        return t.getClass().getName() + "(" + t.getMessage() + ")";
    }

    private static String evaluate(OracleCheck check, CaseDefinition def, SutWrapper wrapper, Arguments args,
            ExecutionResult result, List<Interaction> interactions) throws Throwable {
        switch (check.type()) {
            case NO_EXCEPTION:
                if (result.isException()) {
                    return "the operation must complete, but it threw " + render(result.thrown());
                }
                return null;
            case EXCEPTION_REQUIRED: {
                String expectedType = check.param(0);
                if (!result.isException()) {
                    return "the input must be rejected but the operation completed and returned "
                            + ValueSupport.render(result.returnValue());
                }
                if (!isType(result.thrown(), expectedType)) {
                    return "rejection must be reported as " + expectedType + " but was " + render(result.thrown());
                }
                return null;
            }
            case EXCEPTION_ALLOWED_FAIL_CLOSED: {
                String expectedType = check.param(0);
                String guardedMock = check.param(1);
                if (!result.isException()) {
                    return null;
                }
                if (!isType(result.thrown(), expectedType)) {
                    return "the only acceptable failure for this input condition is " + expectedType
                            + " but the operation failed with " + render(result.thrown());
                }
                List<Interaction> touched = matching(interactions, guardedMock, null);
                if (!touched.isEmpty()) {
                    return "rejection must happen before any interaction with " + guardedMock
                            + " but these were observed: " + touched;
                }
                return null;
            }
            case INVOKED_ONCE: {
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.size() != 1) {
                    return "expected exactly one call to " + check.param(0) + "." + check.param(1)
                            + " but observed " + found.size();
                }
                return null;
            }
            case INVOKED_AT_LEAST_ONCE: {
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "expected at least one call to " + check.param(0) + "." + check.param(1)
                            + " but none was observed";
                }
                return null;
            }
            case NOT_INVOKED: {
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (!found.isEmpty()) {
                    return check.param(0) + "." + check.param(1) + " must not be called but was: " + found;
                }
                return null;
            }
            case ARG_EQUALS: {
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "no call to " + check.param(0) + "." + check.param(1) + " to inspect";
                }
                int index = Integer.parseInt(check.param(2));
                Object expected = resolve(check.param(3), args, wrapper);
                for (int i = 0; i < found.size(); i++) {
                    if (ValueSupport.equal(expected, found.get(i).argument(index))) {
                        return null;
                    }
                }
                return "argument " + index + " of " + check.param(0) + "." + check.param(1)
                        + " must carry " + ValueSupport.render(expected) + " but observed "
                        + ValueSupport.render(found.get(0).argument(index));
            }
            case ARG_SAME: {
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "no call to " + check.param(0) + "." + check.param(1) + " to inspect";
                }
                int index = Integer.parseInt(check.param(2));
                Object expected = resolve(check.param(3), args, wrapper);
                for (int i = 0; i < found.size(); i++) {
                    if (found.get(i).argument(index) == expected) {
                        return null;
                    }
                }
                return "argument " + index + " of " + check.param(0) + "." + check.param(1)
                        + " must be the object supplied by the caller but observed "
                        + ValueSupport.render(found.get(0).argument(index));
            }
            case ARG_FIELD_EQUALS: {
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "no call to " + check.param(0) + "." + check.param(1) + " to inspect";
                }
                int index = Integer.parseInt(check.param(2));
                String getter = check.param(3);
                Object expected = resolve(check.param(4), args, wrapper);
                Object lastSeen = null;
                for (int i = 0; i < found.size(); i++) {
                    Object holder = found.get(i).argument(index);
                    if (holder == null) {
                        continue;
                    }
                    if (!ValueSupport.hasProperty(holder, getter)) {
                        continue;
                    }
                    lastSeen = ValueSupport.property(holder, getter);
                    if (ValueSupport.equal(expected, lastSeen)) {
                        return null;
                    }
                }
                return getter + " of argument " + index + " passed to " + check.param(0) + "." + check.param(1)
                        + " must be " + ValueSupport.render(expected) + " but observed "
                        + ValueSupport.render(lastSeen);
            }
            case ARG_CONTAINS_TEXT: {
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "no call to " + check.param(0) + "." + check.param(1) + " to inspect";
                }
                int index = Integer.parseInt(check.param(2));
                Object expected = resolve(check.param(3), args, wrapper);
                if (expected == null) {
                    return null;
                }
                for (int i = 0; i < found.size(); i++) {
                    Interaction it = found.get(i);
                    if (index >= 0) {
                        if (ValueSupport.containsText(it.argument(index), expected)) {
                            return null;
                        }
                    } else {
                        Object[] all = it.arguments();
                        for (int j = 0; j < all.length; j++) {
                            if (ValueSupport.containsText(all[j], expected)) {
                                return null;
                            }
                        }
                    }
                }
                return "the value " + ValueSupport.render(expected) + " must appear in the statement passed to "
                        + check.param(0) + "." + check.param(1) + " but it did not: " + found;
            }
            case RETURN_SAME_AS_STUB: {
                Object stub = wrapper.sentinelOf(check.param(0), check.param(1));
                if (result.returnValue() != stub) {
                    return "the result must be the value produced by " + check.param(0) + "." + check.param(1)
                            + " but observed " + ValueSupport.render(result.returnValue());
                }
                return null;
            }
            case RETURN_NOT_NULL:
                if (result.returnValue() == null) {
                    return "the operation must produce a result but returned null";
                }
                return null;
            case RETURN_BODY_NOT_NULL: {
                Object body = body(result.returnValue());
                if (body == null) {
                    return "the response must carry a body but the body was null";
                }
                return null;
            }
            case RETURN_EQUALS_VALUE: {
                Object expected = resolve(check.param(0), args, wrapper);
                if (!ValueSupport.equal(expected, result.returnValue())) {
                    return "the result must be " + ValueSupport.render(expected) + " but observed "
                            + ValueSupport.render(result.returnValue());
                }
                return null;
            }
            case RETURN_DIFFERS_FROM_VALUE: {
                Object expected = resolve(check.param(0), args, wrapper);
                if (ValueSupport.equal(expected, result.returnValue())) {
                    return "the result must be derived from, and different to, "
                            + ValueSupport.render(expected) + " but it was returned unchanged";
                }
                return null;
            }
            case RETURN_CONTAINS_VALUE: {
                Object expected = resolve(check.param(0), args, wrapper);
                if (expected == null) {
                    return null;
                }
                if (!ValueSupport.containsText(result.returnValue(), expected)) {
                    return "the result must contain " + ValueSupport.render(expected) + " but observed "
                            + ValueSupport.render(result.returnValue());
                }
                return null;
            }
            case RETURN_FIELD_EQUALS: {
                Object target = result.returnValue();
                if (target == null) {
                    return "the mapped object must exist before its fields can carry the source values";
                }
                String getter = check.param(0);
                Object expected = resolve(check.param(1), args, wrapper);
                if (!ValueSupport.hasProperty(target, getter)) {
                    return "the mapped object does not declare " + getter;
                }
                Object actual = ValueSupport.property(target, getter);
                if (!ValueSupport.equal(expected, actual)) {
                    return getter + " must carry " + ValueSupport.render(expected) + " but observed "
                            + ValueSupport.render(actual);
                }
                return null;
            }
            case RETURN_FIELD_NULL: {
                Object target = result.returnValue();
                if (target == null) {
                    return "the mapped object must exist";
                }
                String getter = check.param(0);
                if (!ValueSupport.hasProperty(target, getter)) {
                    return "the mapped object does not declare " + getter;
                }
                Object actual = ValueSupport.property(target, getter);
                if (actual != null) {
                    return getter + " must not be populated by this operation but observed "
                            + ValueSupport.render(actual);
                }
                return null;
            }
            case RETURN_STATUS_2XX: {
                int status = status(result.returnValue());
                if (status < 200 || status >= 300) {
                    return "the operation must answer with a success status but observed " + status;
                }
                return null;
            }
            case RETURN_STATUS_CLIENT_ERROR: {
                int status = status(result.returnValue());
                if (status < 400 || status >= 500) {
                    return "an invalid request must be answered with a client error status but observed " + status;
                }
                return null;
            }
            case RETURN_STATUS_SERVER_ERROR: {
                int status = status(result.returnValue());
                if (status < 500 || status >= 600) {
                    return "an unexpected failure must be answered with a server error status but observed "
                            + status;
                }
                return null;
            }
            case RETURN_BODY_CONTAINS_VALUE: {
                Object expected = resolve(check.param(0), args, wrapper);
                Object body = body(result.returnValue());
                if (body == null) {
                    return "the response body must exist and carry " + ValueSupport.render(expected);
                }
                if (ValueSupport.deepContains(body, expected, 4) || ValueSupport.containsText(body, expected)) {
                    return null;
                }
                return "the response body must carry " + ValueSupport.render(expected) + " but observed "
                        + ValueSupport.render(body);
            }
            case RETURN_COLLECTION_SIZE_MATCHES_STUB: {
                Object stub = wrapper.sentinelOf(check.param(0), check.param(1));
                Object actual = body(result.returnValue());
                int expectedSize = ValueSupport.sizeOf(stub);
                int actualSize = ValueSupport.sizeOf(actual);
                if (expectedSize < 0) {
                    return null;
                }
                if (expectedSize != actualSize) {
                    return "the result must hold exactly the " + expectedSize
                            + " element(s) obtained from " + check.param(0) + "." + check.param(1)
                            + " but observed " + actualSize;
                }
                return null;
            }
            case RETURN_NO_NULL_ELEMENTS: {
                Object value = body(result.returnValue());
                if (value == null) {
                    return "the result must exist";
                }
                if (value instanceof Collection) {
                    for (Object o : (Collection<?>) value) {
                        if (o == null) {
                            return "the result must not contain null elements";
                        }
                    }
                    return null;
                }
                if (value.getClass().isArray()) {
                    int len = java.lang.reflect.Array.getLength(value);
                    for (int i = 0; i < len; i++) {
                        if (java.lang.reflect.Array.get(value, i) == null) {
                            return "the result must not contain null elements";
                        }
                    }
                }
                return null;
            }
            case CONSTRAINT_VIOLATION_EXPECTED:
            case CONSTRAINT_VIOLATION_ABSENT: {
                String dtoType = check.param(0);
                String fieldName = check.param(1);
                String constraint = check.param(2);
                Object value = resolve(check.param(3), args, wrapper);
                Class<?> type = ProjectTypes.load(dtoType);
                java.lang.annotation.Annotation annotation =
                        ConstraintContract.find(type, fieldName, constraint);
                if (annotation == null) {
                    return "the input contract of " + dtoType + "." + fieldName + " must declare " + constraint
                            + " but the declaration is missing";
                }
                boolean violates = ConstraintContract.violates(value, constraint, annotation);
                if (check.type() == CheckType.CONSTRAINT_VIOLATION_EXPECTED && !violates) {
                    return "this input condition must be rejected by " + constraint + " on " + dtoType + "."
                            + fieldName + " but the declared constraint accepts "
                            + ValueSupport.render(value);
                }
                if (check.type() == CheckType.CONSTRAINT_VIOLATION_ABSENT && violates) {
                    return "this input condition must be accepted by " + constraint + " on " + dtoType + "."
                            + fieldName + " but the declared constraint rejects "
                            + ValueSupport.render(value);
                }
                return null;
            }
            case IDEMPOTENT_ON_RESULT: {
                if (result.isException() || result.returnValue() == null) {
                    return null;
                }
                Object[] again = new Object[args.values().length];
                System.arraycopy(args.values(), 0, again, 0, again.length);
                int index = Integer.parseInt(check.param(0));
                again[index] = result.returnValue();
                Object second = wrapper.rawInvoke(def.methodName(), def.declaredTypes(), again);
                if (!ValueSupport.equal(result.returnValue(), second)) {
                    return "applying the operation to its own result must be stable, but "
                            + ValueSupport.render(result.returnValue()) + " became " + ValueSupport.render(second);
                }
                return null;
            }
            case SENSITIVE_TO_ARG: {
                if (result.isException()) {
                    return null;
                }
                int index = Integer.parseInt(check.param(0));
                Object[] again = new Object[args.values().length];
                System.arraycopy(args.values(), 0, again, 0, again.length);
                again[index] = perturb(again[index]);
                if (again[index] == null) {
                    return null;
                }
                Object second;
                try {
                    second = wrapper.rawInvoke(def.methodName(), def.declaredTypes(), again);
                } catch (Throwable t) {
                    return null;
                }
                if (ValueSupport.equal(result.returnValue(), second)) {
                    return "the result must depend on argument " + index
                            + " but changing it produced the same result "
                            + ValueSupport.render(result.returnValue());
                }
                return null;
            }
            case PRIVATE_CONSTRUCTOR_ONLY: {
                Class<?> type = ProjectTypes.load(def.sutClassName());
                java.lang.reflect.Constructor<?>[] ctors = type.getDeclaredConstructors();
                if (ctors.length == 0) {
                    return "the utility class must declare its own constructor";
                }
                for (int i = 0; i < ctors.length; i++) {
                    if (!java.lang.reflect.Modifier.isPrivate(ctors[i].getModifiers())) {
                        return "the utility class must not be instantiable from outside, but "
                                + ctors[i] + " is accessible";
                    }
                }
                return null;
            }
            case VALUE_REACHED: {
                Object expected = resolve(check.param(2), args, wrapper);
                if (expected == null) {
                    return null;
                }
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "the value must be handed to " + check.param(0)
                            + " but no interaction with it was observed";
                }
                for (int i = 0; i < found.size(); i++) {
                    Object[] all = found.get(i).arguments();
                    for (int j = 0; j < all.length; j++) {
                        if (reached(all[j], expected)) {
                            return null;
                        }
                    }
                }
                return "the input value " + ValueSupport.render(expected)
                        + " must reach " + check.param(0) + " unchanged but it did not appear in " + found;
            }
            case RETURN_CONTAINS_ELEMENTS: {
                Object expected = resolve(check.param(0), args, wrapper);
                if (expected == null) {
                    return null;
                }
                Object actual = result.returnValue();
                if (actual == null) {
                    return "the result must exist and carry every supplied element";
                }
                if (!(expected instanceof Collection)) {
                    return null;
                }
                for (Object element : (Collection<?>) expected) {
                    if (element == null) {
                        continue;
                    }
                    if (!ValueSupport.containsText(actual, element) && !ValueSupport.deepContains(actual, element, 4)) {
                        return "every supplied element must survive, but " + ValueSupport.render(element)
                                + " is missing from " + ValueSupport.render(actual);
                    }
                }
                return null;
            }
            case RETURN_FIELD_CONTAINS: {
                Object target = result.returnValue();
                if (target == null) {
                    return "the result must exist";
                }
                String getter = check.param(0);
                Object expected = resolve(check.param(1), args, wrapper);
                if (expected == null) {
                    return null;
                }
                if (!ValueSupport.hasProperty(target, getter)) {
                    return "the result does not declare " + getter;
                }
                Object actual = ValueSupport.property(target, getter);
                if (ValueSupport.deepContains(actual, expected, 4) || ValueSupport.containsText(actual, expected)) {
                    return null;
                }
                return getter + " must carry " + ValueSupport.render(expected) + " but observed "
                        + ValueSupport.render(actual);
            }
            case RETURN_PATH_EQUALS: {
                Object actual = path(result.returnValue(), check.param(0));
                Object expected = resolve(check.param(1), args, wrapper);
                if (!ValueSupport.equal(expected, actual)) {
                    return check.param(0) + " must be " + ValueSupport.render(expected) + " but observed "
                            + ValueSupport.render(actual);
                }
                return null;
            }
            case RETURN_PATH_CONTAINS: {
                Object expected = resolve(check.param(1), args, wrapper);
                if (expected == null) {
                    return null;
                }
                Object actual = path(result.returnValue(), check.param(0));
                if (actual == null) {
                    return check.param(0) + " must be composed from the connection settings but was null";
                }
                if (!ValueSupport.containsText(actual, expected)) {
                    return check.param(0) + " must contain " + ValueSupport.render(expected) + " but observed "
                            + ValueSupport.render(actual);
                }
                return null;
            }
            case CSV_SPLIT_ROUNDTRIP: {
                Object line = resolve(check.param(0), args, wrapper);
                Object actual = result.returnValue();
                if (line == null || actual == null) {
                    return null;
                }
                String text = String.valueOf(line);
                if (text.indexOf('"') >= 0) {
                    return null;
                }
                if (!actual.getClass().isArray()) {
                    return "the split result must be an array";
                }
                int len = java.lang.reflect.Array.getLength(actual);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < len; i++) {
                    if (i > 0) {
                        sb.append(',');
                    }
                    sb.append(String.valueOf(java.lang.reflect.Array.get(actual, i)));
                }
                if (!text.equals(sb.toString())) {
                    return "splitting a line without quoting must preserve every character, but "
                            + ValueSupport.render(text) + " became " + ValueSupport.render(sb.toString());
                }
                return null;
            }
            case RETURN_FIELD_NOT_NULL: {
                Object target = body(result.returnValue());
                if (target == null) {
                    return "the operation must produce a result carrying " + check.param(0);
                }
                String getter = check.param(0);
                if (!ValueSupport.hasProperty(target, getter)) {
                    return "the result does not declare " + getter;
                }
                if (ValueSupport.property(target, getter) == null) {
                    return getter + " of the produced result must be populated but stayed null";
                }
                return null;
            }
            case RETURN_SIZE_EQUALS: {
                Object value = body(result.returnValue());
                int expectedSize = Integer.parseInt(check.param(0));
                int actualSize = ValueSupport.sizeOf(value);
                if (actualSize != expectedSize) {
                    return "the result must expose exactly " + expectedSize
                            + " element(s) obtained from the database but exposed " + actualSize;
                }
                return null;
            }
            case RETURN_BODY_NOT_EMPTY: {
                Object value = body(result.returnValue());
                if (value == null) {
                    return "the response must carry a payload";
                }
                int size = ValueSupport.sizeOf(value);
                if (size == 0) {
                    return "the response payload must not be empty";
                }
                if (size < 0 && String.valueOf(value).isEmpty()) {
                    return "the response payload must not be empty";
                }
                return null;
            }
            case RESULT_TYPE_HAS_NO_PROPERTY: {
                Object target = result.returnValue();
                if (target == null) {
                    return "the mapping must produce a response object";
                }
                if (ValueSupport.hasProperty(target, check.param(0))) {
                    return "the produced type must not expose " + check.param(0)
                            + ", but the property exists on " + target.getClass().getName();
                }
                return null;
            }
            case ARG_NOT_EQUALS: {
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "no call to " + check.param(0) + "." + check.param(1) + " to inspect";
                }
                int index = Integer.parseInt(check.param(2));
                Object rejected = resolve(check.param(3), args, wrapper);
                if (rejected == null) {
                    return null;
                }
                for (int i = 0; i < found.size(); i++) {
                    if (ValueSupport.equal(rejected, found.get(i).argument(index))) {
                        return "argument " + index + " of " + check.param(0) + "." + check.param(1)
                                + " must not be taken from this input, but it carried "
                                + ValueSupport.render(rejected);
                    }
                }
                return null;
            }
            case VALUE_NOT_SUBSTITUTED: {
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "no call to " + check.param(0) + "." + check.param(1) + " to inspect";
                }
                int index = Integer.parseInt(check.param(2));
                Object expected = resolve(check.param(3), args, wrapper);
                Object rejected = resolve(check.param(4), args, wrapper);
                boolean seenExpected = false;
                for (int i = 0; i < found.size(); i++) {
                    Object actual = found.get(i).argument(index);
                    if (ValueSupport.equal(expected, actual)) {
                        seenExpected = true;
                    } else if (rejected != null && !ValueSupport.equal(expected, rejected)
                            && ValueSupport.equal(rejected, actual)) {
                        return "argument " + index + " must be taken from the addressed resource, not from the "
                                + "duplicated body value " + ValueSupport.render(rejected);
                    }
                }
                if (!seenExpected) {
                    return "argument " + index + " of " + check.param(0) + "." + check.param(1)
                            + " must carry " + ValueSupport.render(expected) + " but it did not";
                }
                return null;
            }
            case ARG_SIZE_EQUALS_VALUE: {
                Object expected = resolve(check.param(3), args, wrapper);
                int expectedSize = ValueSupport.sizeOf(expected);
                if (expectedSize < 0) {
                    return null;
                }
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "no call to " + check.param(0) + "." + check.param(1) + " to inspect";
                }
                int index = Integer.parseInt(check.param(2));
                for (int i = 0; i < found.size(); i++) {
                    if (ValueSupport.sizeOf(found.get(i).argument(index)) == expectedSize) {
                        return null;
                    }
                }
                return "every supplied element must be forwarded: argument " + index + " must hold "
                        + expectedSize + " element(s) but held "
                        + ValueSupport.sizeOf(found.get(0).argument(index));
            }
            case ARG_FIELD_RELATED_TEXT: {
                Object expected = resolve(check.param(4), args, wrapper);
                if (expected == null || String.valueOf(expected).isEmpty()) {
                    return null;
                }
                List<Interaction> found = matching(interactions, check.param(0), check.param(1));
                if (found.isEmpty()) {
                    return "no call to " + check.param(0) + "." + check.param(1) + " to inspect";
                }
                int index = Integer.parseInt(check.param(2));
                String getter = check.param(3);
                String wanted = String.valueOf(expected);
                for (int i = 0; i < found.size(); i++) {
                    Object holder = found.get(i).argument(index);
                    if (holder == null || !ValueSupport.hasProperty(holder, getter)) {
                        continue;
                    }
                    Object actual = ValueSupport.property(holder, getter);
                    if (actual == null) {
                        continue;
                    }
                    String have = String.valueOf(actual);
                    if (have.isEmpty()) {
                        continue;
                    }
                    if (have.contains(wanted) || wanted.contains(have)) {
                        return null;
                    }
                }
                return getter + " must be derived from " + ValueSupport.render(expected)
                        + " but it shares nothing with it";
            }
            case RESULT_PATH_INDEPENDENT_OF: {
                if (result.isException() || result.returnValue() == null) {
                    return null;
                }
                Object root = args.value(check.param(0));
                if (root == null) {
                    return null;
                }
                String field = check.param(1);
                String getterPath = check.param(2);
                String getter = "get" + Character.toUpperCase(field.charAt(0)) + field.substring(1);
                if (!ValueSupport.hasProperty(root, getter)) {
                    return null;
                }
                Object original = ValueSupport.property(root, getter);
                Object alternative = alternativeOf(original);
                if (alternative == null) {
                    return null;
                }
                Object before = getterPath.isEmpty() ? result.returnValue() : path(result.returnValue(), getterPath);
                String beforeText = String.valueOf(before);
                String setter = "set" + Character.toUpperCase(field.charAt(0)) + field.substring(1);
                java.lang.reflect.Method setterMethod = null;
                java.lang.reflect.Method[] methods = root.getClass().getMethods();
                for (int i = 0; i < methods.length; i++) {
                    if (methods[i].getName().equals(setter) && methods[i].getParameterCount() == 1) {
                        setterMethod = methods[i];
                        break;
                    }
                }
                if (setterMethod == null) {
                    return null;
                }
                try {
                    setterMethod.invoke(root, alternative);
                    Object second = wrapper.rawInvoke(def.methodName(), def.declaredTypes(), args.values());
                    Object after = getterPath.isEmpty() ? second : path(second, getterPath);
                    String afterText = String.valueOf(after);
                    if (!beforeText.equals(afterText)) {
                        return "the composed connection target must not depend on " + field
                                + ", but changing it turned " + ValueSupport.render(beforeText) + " into "
                                + ValueSupport.render(afterText);
                    }
                    return null;
                } catch (Throwable t) {
                    return null;
                } finally {
                    try {
                        setterMethod.invoke(root, original);
                    } catch (Throwable ignored) {
                        // the argument object is discarded after the Case
                    }
                }
            }
            case INPUT_FIELD_UNCHANGED: {
                Object root = args.value(check.param(0));
                if (root == null) {
                    return null;
                }
                String getter = check.param(1);
                if (!ValueSupport.hasProperty(root, getter)) {
                    return null;
                }
                Object expected = resolve(check.param(2), args, wrapper);
                Object actual = ValueSupport.property(root, getter);
                if (!ValueSupport.equal(expected, actual)) {
                    return "the supplied object must not be rewritten by the operation, but " + getter
                            + " changed from " + ValueSupport.render(expected) + " to " + ValueSupport.render(actual);
                }
                return null;
            }
            default:
                throw new HarnessException("Unsupported check type " + check.type());
        }
    }

    private static boolean appliesAfterRejection(CheckType type) {
        return type == CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED
                || type == CheckType.CONSTRAINT_VIOLATION_EXPECTED
                || type == CheckType.CONSTRAINT_VIOLATION_ABSENT
                || type == CheckType.PRIVATE_CONSTRUCTOR_ONLY
                || type == CheckType.NOT_INVOKED;
    }

    private static boolean reached(Object argument, Object expected) {
        if (ValueSupport.equal(expected, argument)) {
            return true;
        }
        if (ValueSupport.deepContains(argument, expected, 5)) {
            return true;
        }
        if (expected instanceof Collection) {
            Collection<?> wanted = (Collection<?>) expected;
            if (wanted.isEmpty()) {
                return ValueSupport.sizeOf(argument) == 0;
            }
            boolean allElements = true;
            boolean allText = true;
            for (Object element : wanted) {
                if (!ValueSupport.deepContains(argument, element, 5) && !ValueSupport.equal(element, argument)) {
                    allElements = false;
                }
                if (!ValueSupport.containsText(argument, element)) {
                    allText = false;
                }
            }
            if (allElements || allText) {
                return true;
            }
            return ValueSupport.sizeOf(argument) == wanted.size();
        }
        if (expected instanceof CharSequence) {
            if (((CharSequence) expected).length() == 0) {
                return false;
            }
            return ValueSupport.containsText(argument, expected);
        }
        if (expected instanceof Number || expected instanceof Boolean) {
            return ValueSupport.containsText(argument, expected);
        }
        return false;
    }

    private static Object path(Object root, String getterPath) {
        Object current = root;
        String[] steps = getterPath.split("\\.");
        for (int i = 0; i < steps.length; i++) {
            if (current == null) {
                return null;
            }
            if (!ValueSupport.hasProperty(current, steps[i])) {
                return null;
            }
            current = ValueSupport.property(current, steps[i]);
        }
        return current;
    }

    private static Object alternativeOf(Object value) {
        if (value instanceof String) {
            return "ALT-" + value;
        }
        if (value instanceof Integer) {
            return Integer.valueOf(((Integer) value).intValue() == 7 ? 8 : 7);
        }
        if (value instanceof Long) {
            return Long.valueOf(((Long) value).longValue() == 7L ? 8L : 7L);
        }
        if (value instanceof java.time.LocalDateTime) {
            return ((java.time.LocalDateTime) value).plusDays(1);
        }
        if (value == null) {
            return null;
        }
        return null;
    }

    private static Object perturb(Object value) {
        if (value instanceof Integer) {
            return Integer.valueOf(((Integer) value).intValue() + 1);
        }
        if (value instanceof Long) {
            return Long.valueOf(((Long) value).longValue() + 1L);
        }
        if (value instanceof Short) {
            return Short.valueOf((short) (((Short) value).shortValue() + 1));
        }
        return null;
    }

    private static boolean isType(Throwable t, String typeName) {
        Class<?> expected = ProjectTypes.loadOrNull(typeName);
        if (expected == null) {
            return false;
        }
        Throwable current = t;
        int depth = 0;
        while (current != null && depth < 5) {
            if (expected.isInstance(current)) {
                return true;
            }
            current = current.getCause();
            depth++;
        }
        return false;
    }

    private static List<Interaction> matching(List<Interaction> interactions, String mockField, String method) {
        List<Interaction> out = new ArrayList<Interaction>();
        for (int i = 0; i < interactions.size(); i++) {
            Interaction it = interactions.get(i);
            boolean fieldOk = mockField == null || it.mockField().equals(mockField)
                    || it.mockField().contains(mockField);
            boolean methodOk = method == null || it.methodName().equals(method);
            if (fieldOk && methodOk) {
                out.add(it);
            }
        }
        return out;
    }

    private static Object resolve(String ref, Arguments args, SutWrapper wrapper) {
        if (ref == null) {
            return null;
        }
        if (ref.startsWith("data:")) {
            return args.value(ref.substring(5));
        }
        if (ref.startsWith("arg:")) {
            return args.arg(Integer.parseInt(ref.substring(4)));
        }
        if (ref.startsWith("text:")) {
            return ref.substring(5);
        }
        if (ref.startsWith("stub:")) {
            String rest = ref.substring(5);
            int hash = rest.indexOf('#');
            return wrapper.sentinelOf(rest.substring(0, hash), rest.substring(hash + 1));
        }
        if (ref.startsWith("utf8:")) {
            Object raw = args.value(ref.substring(5));
            if (raw instanceof byte[]) {
                return new String((byte[]) raw, java.nio.charset.StandardCharsets.UTF_8);
            }
            return raw;
        }
        if (ref.startsWith("bool:")) {
            return Boolean.valueOf(ref.substring(5));
        }
        if (ref.startsWith("prop:")) {
            String rest = ref.substring(5);
            int hash = rest.indexOf('#');
            Object holder = args.value(rest.substring(0, hash));
            return ValueSupport.property(holder, rest.substring(hash + 1));
        }
        throw new HarnessException("Unsupported value reference " + ref);
    }

    private static Object body(Object value) {
        if (value == null) {
            return null;
        }
        if (ValueSupport.hasProperty(value, "getBody")) {
            return ValueSupport.property(value, "getBody");
        }
        return value;
    }

    private static int status(Object value) {
        if (value == null) {
            return -1;
        }
        if (ValueSupport.hasProperty(value, "getStatusCode")) {
            Object code = ValueSupport.property(value, "getStatusCode");
            if (code == null) {
                return -1;
            }
            if (ValueSupport.hasProperty(code, "value")) {
                Object v = ValueSupport.property(code, "value");
                if (v instanceof Number) {
                    return ((Number) v).intValue();
                }
            }
            if (code instanceof Number) {
                return ((Number) code).intValue();
            }
        }
        return -1;
    }

    static Map<String, Object> unusedImportGuard() {
        return null;
    }
}

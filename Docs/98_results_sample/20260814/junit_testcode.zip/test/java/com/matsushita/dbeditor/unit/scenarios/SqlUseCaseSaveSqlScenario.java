package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlUseCase#saveSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlUseCaseSaveSqlScenario {

    @Test
    @DisplayName("UTAPI-012915")
    void case_UTAPI_012915() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012915",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012915", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012915", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012915", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012915")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012916")
    void case_UTAPI_012916() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012916",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012916", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012916", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012916", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012916")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012917")
    void case_UTAPI_012917() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012917",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012917", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012917", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012917", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012917")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012918")
    void case_UTAPI_012918() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012918",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012918", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012918", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012918", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012918")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012919")
    void case_UTAPI_012919() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012919",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012919", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012919", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012919", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012919")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012920")
    void case_UTAPI_012920() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012920",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012920", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012920", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012920", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012920")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012921")
    void case_UTAPI_012921() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012921",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012921", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012921", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012921", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012921")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012922")
    void case_UTAPI_012922() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012922",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012922", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012922", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012922", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012922")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012923")
    void case_UTAPI_012923() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012923",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012923", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012923", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012923", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012923")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012924")
    void case_UTAPI_012924() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012924",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012924", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012924", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012924", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012924")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012925")
    void case_UTAPI_012925() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012925",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012925", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012925", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012925", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012925")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012926")
    void case_UTAPI_012926() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012926",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012926", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012926", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012926", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012926")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "1:length_null", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012927")
    void case_UTAPI_012927() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012927",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012927", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012927", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012927", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012927")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "2:length_empty", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012928")
    void case_UTAPI_012928() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012928",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012928", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012928", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012928", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012928")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "3:length_min", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012929")
    void case_UTAPI_012929() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012929",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012929", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012929", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012929", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012929")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012930")
    void case_UTAPI_012930() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012930",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012930", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012930", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012930", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012930")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "5:length_max", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012931")
    void case_UTAPI_012931() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012931",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012931", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012931", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012931", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012931")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012932")
    void case_UTAPI_012932() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012932",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012932", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012932", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012932", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012932")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012933")
    void case_UTAPI_012933() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012933",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012933", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012933", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012933", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012933")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012934")
    void case_UTAPI_012934() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012934",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012934", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012934", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012934", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012934")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012935")
    void case_UTAPI_012935() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012935",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012935", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012935", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012935", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012935")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012936")
    void case_UTAPI_012936() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012936",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012936", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012936", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012936", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012936")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012937")
    void case_UTAPI_012937() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012937",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012937", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012937", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012937", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012937")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012938")
    void case_UTAPI_012938() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012938",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012938", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012938", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012938", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012938")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012939")
    void case_UTAPI_012939() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012939",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012939", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012939", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012939", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012939")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "56:space")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012940")
    void case_UTAPI_012940() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012940",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012940", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012940", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012940", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012940")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012941")
    void case_UTAPI_012941() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012941",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012941", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012941", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012941", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012941")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012942")
    void case_UTAPI_012942() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012942",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012942", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012942", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012942", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012942")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "59:tab")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012943")
    void case_UTAPI_012943() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012943",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012943", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012943", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012943", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012943")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "60:control_character_null")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012944")
    void case_UTAPI_012944() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012944",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012944", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012944", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012944", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012944")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012945")
    void case_UTAPI_012945() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012945",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012945", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012945", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012945", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012945")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012946")
    void case_UTAPI_012946() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012946",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012946", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012946", "title", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-012946", "content", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012946")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::2::-::title")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("title", "title")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for title is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012947")
    void case_UTAPI_012947() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012947",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012947", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012947", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012947", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012947")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "1:length_null", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012948")
    void case_UTAPI_012948() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012948",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012948", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012948", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012948", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012948")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "2:length_empty", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012949")
    void case_UTAPI_012949() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012949",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012949", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012949", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012949", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012949")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "3:length_min", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012950")
    void case_UTAPI_012950() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012950",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012950", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012950", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012950", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012950")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012951")
    void case_UTAPI_012951() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012951",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012951", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012951", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012951", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012951")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "5:length_max", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012952")
    void case_UTAPI_012952() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012952",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012952", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012952", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012952", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012952")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012953")
    void case_UTAPI_012953() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012953",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012953", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012953", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012953", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012953")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012954")
    void case_UTAPI_012954() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012954",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012954", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012954", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012954", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012954")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012955")
    void case_UTAPI_012955() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012955",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012955", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012955", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012955", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012955")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012956")
    void case_UTAPI_012956() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012956",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012956", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012956", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012956", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012956")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012957")
    void case_UTAPI_012957() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012957",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012957", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012957", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012957", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012957")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012958")
    void case_UTAPI_012958() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012958",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012958", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012958", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012958", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012958")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012959")
    void case_UTAPI_012959() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012959",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012959", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012959", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012959", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012959")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "56:space")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012960")
    void case_UTAPI_012960() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012960",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012960", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012960", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012960", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012960")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012961")
    void case_UTAPI_012961() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012961",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012961", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012961", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012961", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012961")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012962")
    void case_UTAPI_012962() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012962",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012962", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012962", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012962", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012962")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "59:tab")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012963")
    void case_UTAPI_012963() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012963",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012963", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012963", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012963", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012963")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "60:control_character_null")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012964")
    void case_UTAPI_012964() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012964",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012964", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012964", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012964", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012964")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012965")
    void case_UTAPI_012965() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012965",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012965", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012965", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012965", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012965")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012966")
    void case_UTAPI_012966() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012966",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "saveSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("title", "String", "title"),
                    new ParamSpec("content", "String", "content")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012966", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-012966", "title", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-012966", "content", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-012966")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::saveSql::3::ARG::3::-::content")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("content", "content")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.save")
                    .expected("the value generated for content is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.save", "savedSqlRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbConnectionId of the object handed to savedSqlRepository.save must carry connectionId", "savedSqlRepository", "save", "0", "getDbConnectionId", "data:connectionId")
                    .check(CheckType.ARG_FIELD_EQUALS, "getTitleSql of the object handed to savedSqlRepository.save must carry title", "savedSqlRepository", "save", "0", "getTitleSql", "data:title")
                    .check(CheckType.ARG_FIELD_EQUALS, "getContentSql of the object handed to savedSqlRepository.save must carry content", "savedSqlRepository", "save", "0", "getContentSql", "data:content")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

}

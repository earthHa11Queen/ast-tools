package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TableController.
 */
public final class TableControllerWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.adapter.controller.TableController";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.adapter.controller.TableController";
    private static final String[] DEP_NAMES = new String[] {"getTableListUseCase", "tableRecordUseCase", "tableHistoryUseCase", "conflictUseCase"};
    private static final String[] DEP_TYPES = new String[] {"GetTableListUseCase", "TableRecordUseCase", "TableHistoryUseCase", "ConflictUseCase"};
    private static final String[] TYPES_applyToReal = new String[] {"String", "ConflictCheckRequest"};
    private static final String[] TYPES_conflictCheck = new String[] {"String", "ConflictCheckRequest"};
    private static final String[] TYPES_conflictDiff = new String[] {"String", "ConflictCheckRequest"};
    private static final String[] TYPES_createBackup = new String[] {"String", "ConflictCheckRequest"};
    private static final String[] TYPES_createCopy = new String[] {"String", "Integer", "String"};
    private static final String[] TYPES_dropStaleTable = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_getHistoryList = new String[] {"String", "Integer", "String"};
    private static final String[] TYPES_getRecords = new String[] {"String", "Integer", "String"};
    private static final String[] TYPES_getStaleTables = new String[] {"Integer", "String"};
    private static final String[] TYPES_getTables = new String[] {"Integer"};
    private static final String[] TYPES_restoreHistory = new String[] {"String", "int", "Integer", "String"};
    private static final String[] TYPES_saveHistory = new String[] {"String", "TableHistorySaveRequest"};
    private static final String[] TYPES_updateCopyRecords = new String[] {"String", "TableRecordUpdateRequest"};

    public TableControllerWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, false);
    }

    /** ResponseEntity<Void> applyToReal(name, request) */
    public ExecutionResult applyToReal(Object[] args) {
        return invoke("applyToReal", TYPES_applyToReal, args);
    }

    /** ResponseEntity<ConflictCheckResponse> conflictCheck(name, request) */
    public ExecutionResult conflictCheck(Object[] args) {
        return invoke("conflictCheck", TYPES_conflictCheck, args);
    }

    /** ResponseEntity<List<Map<String,Object>>> conflictDiff(name, request) */
    public ExecutionResult conflictDiff(Object[] args) {
        return invoke("conflictDiff", TYPES_conflictDiff, args);
    }

    /** ResponseEntity<Void> createBackup(name, request) */
    public ExecutionResult createBackup(Object[] args) {
        return invoke("createBackup", TYPES_createBackup, args);
    }

    /** ResponseEntity<List<Map<String,Object>>> createCopy(name, connectionId, schema) */
    public ExecutionResult createCopy(Object[] args) {
        return invoke("createCopy", TYPES_createCopy, args);
    }

    /** ResponseEntity<Void> dropStaleTable(connectionId, tableName, schema) */
    public ExecutionResult dropStaleTable(Object[] args) {
        return invoke("dropStaleTable", TYPES_dropStaleTable, args);
    }

    /** ResponseEntity<List<Map<String,Object>>> getHistoryList(name, connectionId, schema) */
    public ExecutionResult getHistoryList(Object[] args) {
        return invoke("getHistoryList", TYPES_getHistoryList, args);
    }

    /** ResponseEntity<List<Map<String,Object>>> getRecords(name, connectionId, schema) */
    public ExecutionResult getRecords(Object[] args) {
        return invoke("getRecords", TYPES_getRecords, args);
    }

    /** ResponseEntity<List<String>> getStaleTables(connectionId, schema) */
    public ExecutionResult getStaleTables(Object[] args) {
        return invoke("getStaleTables", TYPES_getStaleTables, args);
    }

    /** ResponseEntity<List<TableMetadataResponse>> getTables(connectionId) */
    public ExecutionResult getTables(Object[] args) {
        return invoke("getTables", TYPES_getTables, args);
    }

    /** ResponseEntity<List<Map<String,Object>>> restoreHistory(name, seq, connectionId, schema) */
    public ExecutionResult restoreHistory(Object[] args) {
        return invoke("restoreHistory", TYPES_restoreHistory, args);
    }

    /** ResponseEntity<Map<String,Object>> saveHistory(name, request) */
    public ExecutionResult saveHistory(Object[] args) {
        return invoke("saveHistory", TYPES_saveHistory, args);
    }

    /** ResponseEntity<Void> updateCopyRecords(name, request) */
    public ExecutionResult updateCopyRecords(Object[] args) {
        return invoke("updateCopyRecords", TYPES_updateCopyRecords, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("applyToReal".equals(operation)) {
            return applyToReal(args);
        } else if ("conflictCheck".equals(operation)) {
            return conflictCheck(args);
        } else if ("conflictDiff".equals(operation)) {
            return conflictDiff(args);
        } else if ("createBackup".equals(operation)) {
            return createBackup(args);
        } else if ("createCopy".equals(operation)) {
            return createCopy(args);
        } else if ("dropStaleTable".equals(operation)) {
            return dropStaleTable(args);
        } else if ("getHistoryList".equals(operation)) {
            return getHistoryList(args);
        } else if ("getRecords".equals(operation)) {
            return getRecords(args);
        } else if ("getStaleTables".equals(operation)) {
            return getStaleTables(args);
        } else if ("getTables".equals(operation)) {
            return getTables(args);
        } else if ("restoreHistory".equals(operation)) {
            return restoreHistory(args);
        } else if ("saveHistory".equals(operation)) {
            return saveHistory(args);
        } else if ("updateCopyRecords".equals(operation)) {
            return updateCopyRecords(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

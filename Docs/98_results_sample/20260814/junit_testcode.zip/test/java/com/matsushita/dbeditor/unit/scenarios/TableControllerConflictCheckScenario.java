package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#conflictCheck.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerConflictCheckScenario {

    @Test
    @DisplayName("UTAPI-001160")
    void case_UTAPI_001160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001160",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001160", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001160", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001160", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001160", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001160")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001161")
    void case_UTAPI_001161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001161",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001161", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001161", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001161", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001161", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001161")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001162")
    void case_UTAPI_001162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001162",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001162", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001162", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001162", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001162", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001162")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001163")
    void case_UTAPI_001163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001163",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001163", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001163", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001163", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001163", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001163")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001164")
    void case_UTAPI_001164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001164",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001164", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001164", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001164", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001164", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001164")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001165")
    void case_UTAPI_001165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001165",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001165", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001165", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001165", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001165", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001165")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001166")
    void case_UTAPI_001166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001166",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001166", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001166", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001166", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001166", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001166")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001167")
    void case_UTAPI_001167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001167",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001167", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001167", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001167", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001167", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001167")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001168")
    void case_UTAPI_001168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001168",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001168", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001168", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001168", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001168", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001168")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001169")
    void case_UTAPI_001169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001169",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001169", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001169", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001169", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001169", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001169")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001170")
    void case_UTAPI_001170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001170",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001170", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001170", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001170", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001170", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001170")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001171")
    void case_UTAPI_001171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001171",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001171", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001171", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001171", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001171", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001171")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001172")
    void case_UTAPI_001172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001172",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001172", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001172", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001172", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001172", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001172")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001173")
    void case_UTAPI_001173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001173",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001173", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001173", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001173", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001173", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001173")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001174")
    void case_UTAPI_001174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001174",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001174", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001174", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001174", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001174", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001174")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001175")
    void case_UTAPI_001175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001175",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001175", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001175", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001175", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001175", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001175")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001176")
    void case_UTAPI_001176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001176",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001176", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001176", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001176", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001176", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001176")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001177")
    void case_UTAPI_001177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001177",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001177", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001177", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001177", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001177", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001177")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001178")
    void case_UTAPI_001178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001178",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001178", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001178", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001178", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001178", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001178")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001179")
    void case_UTAPI_001179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001179",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001179", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001179", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001179", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001179", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001179")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001180")
    void case_UTAPI_001180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001180",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001180", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001180", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001180", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001180", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001180")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001181")
    void case_UTAPI_001181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001181",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001181", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001181", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001181", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001181", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001181")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001182")
    void case_UTAPI_001182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001182",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001182", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001182", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001182", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001182", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001182")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001183")
    void case_UTAPI_001183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001183",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001183", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001183", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001183", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001183", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001183")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001184")
    void case_UTAPI_001184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001184",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001184", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001184", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001184", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001184", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001184")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001185")
    void case_UTAPI_001185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001185",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001185", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001185", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001185", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001185", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001185")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001186")
    void case_UTAPI_001186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001186",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001186", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001186", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001186", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001186", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001186")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConflictCheckRequest.connectionId classifies this input condition", "ConflictCheckRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001187")
    void case_UTAPI_001187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001187",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001187", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001187", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001187", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001187", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001187")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001188")
    void case_UTAPI_001188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001188",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001188", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001188", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001188", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001188", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001188")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001189")
    void case_UTAPI_001189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001189",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001189", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001189", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001189", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001189", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001189")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001190")
    void case_UTAPI_001190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001190",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001190", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001190", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001190", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001190", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001190")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "ConflictCheckRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001191")
    void case_UTAPI_001191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001191",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001191", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001191", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001191", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001191", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001191")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001192")
    void case_UTAPI_001192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001192",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001192", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001192", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001192", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001192", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001192")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001193")
    void case_UTAPI_001193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001193",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001193", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001193", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001193", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001193", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001193")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001194")
    void case_UTAPI_001194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001194",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001194", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001194", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001194", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001194", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001194")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001195")
    void case_UTAPI_001195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001195",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001195", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001195", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001195", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001195", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001195")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001196")
    void case_UTAPI_001196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001196",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001196", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001196", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001196", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001196", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001196")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001197")
    void case_UTAPI_001197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001197",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001197", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001197", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001197", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001197", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001197")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001198")
    void case_UTAPI_001198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001198",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001198", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001198", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001198", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001198", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001198")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001199")
    void case_UTAPI_001199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001199",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001199", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001199", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001199", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001199", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001199")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001200")
    void case_UTAPI_001200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001200",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001200", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001200", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001200", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001200", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001200")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001201")
    void case_UTAPI_001201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001201",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001201", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001201", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001201", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001201", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001201")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001202")
    void case_UTAPI_001202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001202",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001202", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001202", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001202", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001202", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001202")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001203")
    void case_UTAPI_001203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001203",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001203", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001203", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001203", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001203", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001203")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001204")
    void case_UTAPI_001204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001204",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001204", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001204", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001204", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001204", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001204")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001205")
    void case_UTAPI_001205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001205",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001205", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001205", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001205", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001205", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001205")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001206")
    void case_UTAPI_001206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001206",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001206", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001206", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001206", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001206", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001206")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001207")
    void case_UTAPI_001207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001207",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001207", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001207", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001207", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001207", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001207")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001208")
    void case_UTAPI_001208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001208",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001208", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001208", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001208", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001208", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001208")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001209")
    void case_UTAPI_001209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001209",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001209", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001209", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001209", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001209", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001209")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001210")
    void case_UTAPI_001210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001210",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001210", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001210", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001210", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001210", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001210")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001211")
    void case_UTAPI_001211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001211",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "conflictCheck",
                "ResponseEntity<ConflictCheckResponse>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "ConflictCheckRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001211", "request", "NORMAL", "OBJECT", "ConflictCheckRequest"),
                    new DataRef("UTAPI-001211", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001211", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001211", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001211")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::conflictCheck::11::FIELD::2::ConflictCheckRequest::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.schemaName", "ConflictCheckRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of conflictUseCase.hasConflict")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through conflictUseCase.hasConflict", "conflictUseCase", "hasConflict")
                    .check(CheckType.ARG_EQUALS, "argument 0 of conflictUseCase.hasConflict must carry the value generated for request.connectionId", "conflictUseCase", "hasConflict", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of conflictUseCase.hasConflict must carry the value generated for request.schemaName", "conflictUseCase", "hasConflict", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of conflictUseCase.hasConflict must carry the value generated for name", "conflictUseCase", "hasConflict", "2", "data:name")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

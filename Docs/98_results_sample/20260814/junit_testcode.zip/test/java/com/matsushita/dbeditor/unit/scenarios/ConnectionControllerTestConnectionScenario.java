package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionController#testConnection.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionControllerTestConnectionScenario {

    @Test
    @DisplayName("UTAPI-000139")
    void case_UTAPI_000139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000139",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000139", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000139", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000139", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000139", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000139", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000139", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000139", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000139", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000139")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000140")
    void case_UTAPI_000140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000140",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000140", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000140", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000140", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000140", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000140", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000140", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000140", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000140", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000140")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000141")
    void case_UTAPI_000141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000141",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000141", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000141", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000141", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000141", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000141", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000141", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000141", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000141", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000141")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000142")
    void case_UTAPI_000142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000142",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000142", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000142", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000142", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000142", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000142", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000142", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000142", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000142", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000142")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000143")
    void case_UTAPI_000143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000143",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000143", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000143", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000143", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000143", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000143", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000143", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000143", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000143", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000143")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000144")
    void case_UTAPI_000144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000144",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000144", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000144", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000144", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000144", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000144", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000144", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000144", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000144", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000144")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000145")
    void case_UTAPI_000145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000145",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000145", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000145", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000145", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000145", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000145", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000145", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000145", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000145", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000145")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000146")
    void case_UTAPI_000146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000146",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000146", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000146", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000146", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000146", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000146", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000146", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000146", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000146", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000146")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000147")
    void case_UTAPI_000147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000147",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000147", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000147", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000147", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000147", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000147", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000147", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000147", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000147", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000147")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000148")
    void case_UTAPI_000148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000148",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000148", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000148", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000148", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000148", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000148", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000148", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000148", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000148", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000148")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000149")
    void case_UTAPI_000149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000149",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000149", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000149", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000149", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000149", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000149", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000149", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000149", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000149", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000149")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "ConnectionTestRequest.connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000150")
    void case_UTAPI_000150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000150",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000150", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000150", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000150", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000150", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000150", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000150", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000150", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000150", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000150")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000151")
    void case_UTAPI_000151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000151",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000151", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000151", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000151", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000151", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000151", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000151", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000151", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000151", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000151")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000152")
    void case_UTAPI_000152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000152",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000152", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000152", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000152", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000152", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000152", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000152", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000152", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000152", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000152")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000153")
    void case_UTAPI_000153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000153",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000153", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000153", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000153", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000153", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000153", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000153", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000153", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000153", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000153")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000154")
    void case_UTAPI_000154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000154",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000154", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000154", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000154", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000154", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000154", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000154", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000154", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000154", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000154")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000155")
    void case_UTAPI_000155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000155",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000155", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000155", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000155", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000155", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000155", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000155", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000155", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000155", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000155")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000156")
    void case_UTAPI_000156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000156",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000156", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000156", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000156", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000156", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000156", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000156", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000156", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000156", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000156")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000157")
    void case_UTAPI_000157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000157",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000157", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000157", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000157", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000157", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000157", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000157", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000157", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000157", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000157")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000158")
    void case_UTAPI_000158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000158",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000158", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000158", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000158", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000158", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000158", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000158", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000158", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000158", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000158")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000159")
    void case_UTAPI_000159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000159",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000159", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000159", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000159", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000159", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000159", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000159", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000159", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000159", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000159")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000160")
    void case_UTAPI_000160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000160",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000160", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000160", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000160", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000160", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000160", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000160", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000160", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000160", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000160")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000161")
    void case_UTAPI_000161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000161",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000161", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000161", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000161", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000161", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000161", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000161", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000161", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000161", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000161")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000162")
    void case_UTAPI_000162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000162",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000162", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000162", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000162", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000162", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000162", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000162", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000162", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000162", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000162")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000163")
    void case_UTAPI_000163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000163",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000163", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000163", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000163", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000163", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000163", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000163", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000163", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000163", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000163")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000164")
    void case_UTAPI_000164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000164",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000164", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000164", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000164", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000164", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000164", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000164", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000164", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000164", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000164")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000165")
    void case_UTAPI_000165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000165",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000165", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000165", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000165", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000165", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000165", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000165", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000165", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000165", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000165")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000166")
    void case_UTAPI_000166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000166",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000166", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000166", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000166", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000166", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000166", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000166", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000166", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000166", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000166")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000167")
    void case_UTAPI_000167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000167",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000167", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000167", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000167", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000167", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000167", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000167", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000167", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000167", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000167")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000168")
    void case_UTAPI_000168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000168",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000168", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000168", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000168", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000168", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000168", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000168", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000168", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000168", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000168")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000169")
    void case_UTAPI_000169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000169",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000169", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000169", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000169", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000169", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000169", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000169", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000169", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000169", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000169")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000170")
    void case_UTAPI_000170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000170",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000170", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000170", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000170", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000170", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000170", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000170", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000170", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000170", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000170")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.databaseName", "ConnectionTestRequest.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000171")
    void case_UTAPI_000171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000171",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000171", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000171", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000171", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000171", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000171", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000171", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000171", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000171", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000171")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000172")
    void case_UTAPI_000172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000172",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000172", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000172", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000172", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000172", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000172", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000172", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000172", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000172", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000172")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000173")
    void case_UTAPI_000173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000173",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000173", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000173", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000173", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000173", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000173", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000173", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000173", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000173", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000173")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000174")
    void case_UTAPI_000174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000174",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000174", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000174", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000174", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000174", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000174", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000174", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000174", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000174", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000174")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000175")
    void case_UTAPI_000175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000175",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000175", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000175", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000175", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000175", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000175", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000175", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000175", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000175", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000175")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000176")
    void case_UTAPI_000176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000176",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000176", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000176", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000176", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000176", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000176", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000176", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000176", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000176", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000176")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000177")
    void case_UTAPI_000177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000177",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000177", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000177", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000177", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000177", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000177", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000177", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000177", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000177", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000177")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000178")
    void case_UTAPI_000178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000178",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000178", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000178", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000178", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000178", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000178", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000178", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000178", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000178", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000178")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000179")
    void case_UTAPI_000179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000179",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000179", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000179", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000179", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000179", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000179", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000179", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000179", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000179", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000179")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000180")
    void case_UTAPI_000180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000180",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000180", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000180", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000180", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000180", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000180", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000180", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000180", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000180", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000180")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000181")
    void case_UTAPI_000181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000181",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000181", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000181", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000181", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000181", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000181", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000181", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000181", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000181", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000181")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000182")
    void case_UTAPI_000182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000182",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000182", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000182", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000182", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000182", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000182", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000182", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000182", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000182", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000182")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000183")
    void case_UTAPI_000183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000183",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000183", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000183", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000183", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000183", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000183", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000183", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000183", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000183", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000183")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000184")
    void case_UTAPI_000184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000184",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000184", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000184", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000184", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000184", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000184", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000184", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000184", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000184", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000184")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000185")
    void case_UTAPI_000185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000185",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000185", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000185", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000185", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000185", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000185", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000185", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000185", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000185", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000185")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000186")
    void case_UTAPI_000186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000186",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000186", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000186", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000186", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000186", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000186", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000186", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000186", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000186", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000186")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000187")
    void case_UTAPI_000187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000187",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000187", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000187", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000187", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000187", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000187", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000187", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000187", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000187", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000187")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000188")
    void case_UTAPI_000188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000188",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000188", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000188", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000188", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000188", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000188", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000188", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000188", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000188", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000188")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000189")
    void case_UTAPI_000189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000189",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000189", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000189", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000189", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000189", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000189", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000189", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000189", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000189", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000189")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000190")
    void case_UTAPI_000190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000190",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000190", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000190", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000190", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000190", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000190", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000190", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000190", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000190", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000190")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbHost", "ConnectionTestRequest.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000191")
    void case_UTAPI_000191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000191",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000191", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000191", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000191", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000191", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000191", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000191", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000191", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000191", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000191")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000192")
    void case_UTAPI_000192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000192",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000192", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000192", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000192", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000192", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000192", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000192", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000192", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000192", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000192")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000193")
    void case_UTAPI_000193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000193",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000193", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000193", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000193", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000193", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000193", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000193", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000193", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000193", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000193")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000194")
    void case_UTAPI_000194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000194",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000194", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000194", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000194", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000194", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000194", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000194", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000194", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000194", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000194")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000195")
    void case_UTAPI_000195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000195",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000195", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000195", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000195", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000195", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000195", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000195", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000195", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000195", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000195")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000196")
    void case_UTAPI_000196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000196",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000196", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000196", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000196", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000196", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000196", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000196", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000196", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000196", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000196")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000197")
    void case_UTAPI_000197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000197",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000197", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000197", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000197", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000197", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000197", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000197", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000197", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000197", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000197")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000198")
    void case_UTAPI_000198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000198",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000198", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000198", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000198", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000198", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000198", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000198", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000198", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000198", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000198")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000199")
    void case_UTAPI_000199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000199",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000199", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000199", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000199", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000199", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000199", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000199", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000199", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000199", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000199")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000200")
    void case_UTAPI_000200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000200",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000200", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000200", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000200", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000200", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000200", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000200", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000200", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000200", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000200")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000201")
    void case_UTAPI_000201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000201",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000201", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000201", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000201", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000201", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000201", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000201", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000201", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000201", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000201")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000202")
    void case_UTAPI_000202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000202",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000202", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000202", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000202", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000202", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000202", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000202", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000202", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000202", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000202")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000203")
    void case_UTAPI_000203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000203",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000203", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000203", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000203", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000203", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000203", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000203", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000203", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000203", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000203")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000204")
    void case_UTAPI_000204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000204",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000204", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000204", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000204", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000204", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000204", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000204", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000204", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000204", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000204")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "56:space")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000205")
    void case_UTAPI_000205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000205",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000205", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000205", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000205", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000205", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000205", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000205", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000205", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000205", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000205")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000206")
    void case_UTAPI_000206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000206",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000206", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000206", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000206", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000206", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000206", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000206", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000206", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000206", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000206")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000207")
    void case_UTAPI_000207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000207",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000207", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000207", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000207", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000207", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000207", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000207", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000207", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000207", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000207")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000208")
    void case_UTAPI_000208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000208",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000208", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000208", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000208", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000208", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000208", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000208", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000208", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000208", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000208")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000209")
    void case_UTAPI_000209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000209",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000209", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000209", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000209", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000209", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000209", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000209", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000209", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000209", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000209")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000210")
    void case_UTAPI_000210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000210",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000210", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000210", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000210", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000210", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000210", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000210", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000210", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000210", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000210")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000211")
    void case_UTAPI_000211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000211",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000211", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000211", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000211", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000211", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000211", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000211", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000211", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000211", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000211")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbName", "ConnectionTestRequest.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000212")
    void case_UTAPI_000212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000212",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000212", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000212", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000212", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000212", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000212", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000212", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000212", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000212", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000212")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000213")
    void case_UTAPI_000213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000213",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000213", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000213", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000213", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000213", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000213", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000213", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000213", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000213", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000213")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000214")
    void case_UTAPI_000214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000214",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000214", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000214", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000214", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000214", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000214", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000214", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000214", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000214", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000214")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000215")
    void case_UTAPI_000215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000215",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000215", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000215", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000215", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000215", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000215", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000215", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000215", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000215", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000215")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000216")
    void case_UTAPI_000216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000216",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000216", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000216", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000216", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000216", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000216", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000216", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000216", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000216", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000216")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000217")
    void case_UTAPI_000217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000217",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000217", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000217", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000217", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000217", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000217", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000217", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000217", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000217", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000217")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000218")
    void case_UTAPI_000218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000218",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000218", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000218", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000218", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000218", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000218", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000218", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000218", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000218", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000218")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000219")
    void case_UTAPI_000219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000219",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000219", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000219", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000219", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000219", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000219", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000219", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000219", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000219", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000219")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000220")
    void case_UTAPI_000220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000220",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000220", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000220", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000220", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000220", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000220", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000220", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000220", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000220", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000220")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000221")
    void case_UTAPI_000221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000221",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000221", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000221", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000221", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000221", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000221", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000221", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000221", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000221", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000221")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000222")
    void case_UTAPI_000222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000222",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000222", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000222", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000222", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000222", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000222", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000222", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000222", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000222", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000222")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000223")
    void case_UTAPI_000223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000223",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000223", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000223", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000223", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000223", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000223", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000223", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000223", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000223", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000223")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000224")
    void case_UTAPI_000224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000224",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000224", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000224", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000224", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000224", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000224", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000224", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000224", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000224", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000224")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000225")
    void case_UTAPI_000225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000225",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000225", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000225", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000225", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000225", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000225", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000225", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000225", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000225", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000225")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000226")
    void case_UTAPI_000226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000226",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000226", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000226", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000226", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000226", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000226", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000226", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000226", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000226", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000226")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000227")
    void case_UTAPI_000227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000227",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000227", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000227", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000227", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000227", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000227", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000227", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000227", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000227", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000227")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000228")
    void case_UTAPI_000228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000228",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000228", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000228", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000228", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000228", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000228", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000228", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000228", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000228", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000228")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000229")
    void case_UTAPI_000229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000229",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000229", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000229", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000229", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000229", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000229", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000229", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000229", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000229", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000229")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000230")
    void case_UTAPI_000230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000230",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000230", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000230", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000230", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000230", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000230", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000230", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000230", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000230", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000230")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000231")
    void case_UTAPI_000231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000231",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000231", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000231", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000231", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000231", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000231", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000231", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000231", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000231", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000231")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbPassword", "ConnectionTestRequest.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000232")
    void case_UTAPI_000232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000232",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000232", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000232", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000232", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000232", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000232", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000232", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000232", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000232", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000232")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000233")
    void case_UTAPI_000233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000233",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000233", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000233", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000233", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000233", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000233", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000233", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000233", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000233", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000233")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000234")
    void case_UTAPI_000234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000234",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000234", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000234", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000234", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000234", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000234", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000234", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000234", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000234", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000234")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000235")
    void case_UTAPI_000235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000235",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000235", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000235", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000235", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000235", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000235", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000235", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000235", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000235", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000235")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000236")
    void case_UTAPI_000236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000236",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000236", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000236", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000236", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000236", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000236", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000236", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000236", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000236", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000236")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000237")
    void case_UTAPI_000237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000237",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000237", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000237", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000237", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000237", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000237", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000237", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000237", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000237", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000237")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000238")
    void case_UTAPI_000238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000238",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000238", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000238", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000238", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000238", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000238", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000238", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000238", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000238", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000238")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000239")
    void case_UTAPI_000239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000239",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000239", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000239", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000239", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000239", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000239", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000239", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000239", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000239", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000239")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000240")
    void case_UTAPI_000240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000240",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000240", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000240", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000240", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000240", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000240", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000240", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000240", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000240", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000240")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000241")
    void case_UTAPI_000241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000241",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000241", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000241", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000241", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000241", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000241", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000241", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000241", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000241", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000241")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000242")
    void case_UTAPI_000242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000242",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000242", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000242", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000242", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000242", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000242", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000242", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000242", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000242", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000242")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.dbPort", "ConnectionTestRequest.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000243")
    void case_UTAPI_000243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000243",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000243", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000243", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000243", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000243", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000243", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000243", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000243", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000243", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000243")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000244")
    void case_UTAPI_000244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000244",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000244", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000244", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000244", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000244", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000244", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000244", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000244", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000244", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000244")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000245")
    void case_UTAPI_000245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000245",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000245", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000245", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000245", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000245", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000245", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000245", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000245", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000245", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000245")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000246")
    void case_UTAPI_000246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000246",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000246", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000246", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000246", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000246", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000246", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000246", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000246", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000246", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000246")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000247")
    void case_UTAPI_000247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000247",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000247", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000247", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000247", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000247", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000247", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000247", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000247", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000247", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000247")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000248")
    void case_UTAPI_000248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000248",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000248", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000248", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000248", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000248", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000248", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000248", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000248", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000248", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000248")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000249")
    void case_UTAPI_000249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000249",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000249", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000249", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000249", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000249", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000249", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000249", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000249", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000249", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000249")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000250")
    void case_UTAPI_000250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000250",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000250", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000250", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000250", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000250", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000250", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000250", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000250", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000250", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000250")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000251")
    void case_UTAPI_000251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000251",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000251", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000251", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000251", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000251", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000251", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000251", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000251", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000251", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000251")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000252")
    void case_UTAPI_000252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000252",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000252", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000252", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000252", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000252", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000252", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000252", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000252", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000252", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000252")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000253")
    void case_UTAPI_000253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000253",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000253", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000253", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000253", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000253", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000253", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000253", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000253", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000253", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000253")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000254")
    void case_UTAPI_000254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000254",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000254", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000254", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000254", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000254", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000254", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000254", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000254", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000254", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000254")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000255")
    void case_UTAPI_000255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000255",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000255", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000255", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000255", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000255", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000255", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000255", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000255", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000255", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000255")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000256")
    void case_UTAPI_000256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000256",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000256", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000256", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000256", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000256", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000256", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000256", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000256", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000256", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000256")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000257")
    void case_UTAPI_000257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000257",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000257", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000257", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000257", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000257", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000257", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000257", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000257", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000257", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000257")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000258")
    void case_UTAPI_000258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000258",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000258", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000258", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000258", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000258", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000258", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000258", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000258", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000258", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000258")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000259")
    void case_UTAPI_000259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000259",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000259", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000259", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000259", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000259", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000259", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000259", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000259", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000259", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000259")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000260")
    void case_UTAPI_000260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000260",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000260", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000260", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000260", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000260", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000260", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000260", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000260", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000260", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000260")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000261")
    void case_UTAPI_000261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000261",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000261", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000261", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000261", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000261", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000261", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000261", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000261", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000261", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000261")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000262")
    void case_UTAPI_000262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000262",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000262", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000262", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000262", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000262", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000262", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000262", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000262", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000262", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000262")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000263")
    void case_UTAPI_000263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000263",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "testConnection",
                "ResponseEntity<ConnectionTestResponse>",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionTestRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000263", "request", "NORMAL", "OBJECT", "ConnectionTestRequest"),
                    new DataRef("UTAPI-000263", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000263", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000263", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000263", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000263", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000263", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000263", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000263")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::testConnection::6::FIELD::1::ConnectionTestRequest::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbUsername", "ConnectionTestRequest.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.testConnection")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.testConnection", "connectionUseCase", "testConnection")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.testConnection must carry the value generated for request", "connectionUseCase", "testConnection", "0", "data:request")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

}

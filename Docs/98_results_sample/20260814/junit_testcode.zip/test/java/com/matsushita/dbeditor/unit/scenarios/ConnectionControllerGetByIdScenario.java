package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionController#getById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionControllerGetByIdScenario {

    @Test
    @DisplayName("UTAPI-000128")
    void case_UTAPI_000128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000128",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000128", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000128")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "1:length_null", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000129")
    void case_UTAPI_000129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000129",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000129", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000129")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "2:length_empty", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000130")
    void case_UTAPI_000130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000130",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000130", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000130")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "3:length_min", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000131")
    void case_UTAPI_000131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000131",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000131", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000131")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000132")
    void case_UTAPI_000132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000132",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000132", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000132")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "5:length_max", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000133")
    void case_UTAPI_000133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000133",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000133", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000133")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000134")
    void case_UTAPI_000134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000134",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000134", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000134")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000135")
    void case_UTAPI_000135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000135",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000135", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000135")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("46:hw_integer", "-", "-")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000136")
    void case_UTAPI_000136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000136",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000136", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000136")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "-", "12:integer_positive")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000137")
    void case_UTAPI_000137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000137",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000137", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000137")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "-", "13:integer_negative")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000138")
    void case_UTAPI_000138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000138",
                "com.matsushita.dbeditor.adapter.controller.ConnectionController",
                "getById",
                "ResponseEntity<ConnectionSettingResponse>",
                new ParamSpec[] {
                    new ParamSpec("id", "Integer", "id")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000138", "id", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-000138")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ConnectionController.java::ConnectionController::getById::2::ARG::1::-::id")
                    .mirror("-", "-", "14:integer_zero")
                    .target("id", "id")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionUseCase.getById")
                    .expected("the value generated for id is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionUseCase.getById", "connectionUseCase", "getById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionUseCase.getById must carry the value generated for id", "connectionUseCase", "getById", "0", "data:id")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionControllerWrapper());
    }

}

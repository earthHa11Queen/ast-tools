package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableMetadataResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableMetadataResponse#fromEntity.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableMetadataResponseFromEntityScenario {

    @Test
    @DisplayName("UTAPI-010561")
    void case_UTAPI_010561() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010561",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010561", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010561", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010561", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010561", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010561")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010562")
    void case_UTAPI_010562() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010562",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010562", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010562", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010562", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010562", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010562")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010563")
    void case_UTAPI_010563() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010563",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010563", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010563", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010563", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010563", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010563")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010564")
    void case_UTAPI_010564() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010564",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010564", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010564", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010564", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010564", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010564")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010565")
    void case_UTAPI_010565() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010565",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010565", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010565", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010565", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010565", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010565")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010566")
    void case_UTAPI_010566() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010566",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010566", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010566", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010566", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010566", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010566")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010567")
    void case_UTAPI_010567() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010567",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010567", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010567", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010567", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010567", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010567")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010568")
    void case_UTAPI_010568() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010568",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010568", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010568", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010568", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010568", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010568")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010569")
    void case_UTAPI_010569() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010569",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010569", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010569", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010569", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010569", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010569")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010570")
    void case_UTAPI_010570() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010570",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010570", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010570", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010570", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010570", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010570")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010571")
    void case_UTAPI_010571() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010571",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010571", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010571", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010571", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010571", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010571")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010572")
    void case_UTAPI_010572() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010572",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010572", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010572", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010572", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010572", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010572")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010573")
    void case_UTAPI_010573() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010573",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010573", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010573", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010573", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010573", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010573")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010574")
    void case_UTAPI_010574() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010574",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010574", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010574", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010574", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010574", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010574")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010575")
    void case_UTAPI_010575() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010575",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010575", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010575", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010575", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010575", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010575")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010576")
    void case_UTAPI_010576() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010576",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010576", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010576", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010576", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010576", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010576")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010577")
    void case_UTAPI_010577() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010577",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010577", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010577", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010577", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010577", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010577")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010578")
    void case_UTAPI_010578() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010578",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010578", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010578", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010578", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010578", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010578")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010579")
    void case_UTAPI_010579() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010579",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010579", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010579", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010579", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010579", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010579")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010580")
    void case_UTAPI_010580() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010580",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010580", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010580", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010580", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010580", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010580")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010581")
    void case_UTAPI_010581() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010581",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010581", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010581", "entity.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010581", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010581", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010581")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("entity.schemaName", "TableMetadata.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.schemaName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010582")
    void case_UTAPI_010582() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010582",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010582", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010582", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010582", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010582", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010582")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010583")
    void case_UTAPI_010583() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010583",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010583", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010583", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010583", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010583", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010583")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010584")
    void case_UTAPI_010584() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010584",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010584", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010584", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010584", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010584", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010584")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010585")
    void case_UTAPI_010585() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010585",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010585", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010585", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010585", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010585", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010585")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010586")
    void case_UTAPI_010586() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010586",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010586", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010586", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010586", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010586", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010586")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010587")
    void case_UTAPI_010587() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010587",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010587", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010587", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010587", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010587", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010587")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010588")
    void case_UTAPI_010588() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010588",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010588", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010588", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010588", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010588", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010588")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010589")
    void case_UTAPI_010589() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010589",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010589", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010589", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010589", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010589", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010589")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010590")
    void case_UTAPI_010590() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010590",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010590", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010590", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010590", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010590", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010590")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010591")
    void case_UTAPI_010591() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010591",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010591", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010591", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010591", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010591", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010591")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010592")
    void case_UTAPI_010592() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010592",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010592", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010592", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010592", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010592", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010592")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010593")
    void case_UTAPI_010593() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010593",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010593", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010593", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010593", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010593", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010593")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010594")
    void case_UTAPI_010594() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010594",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010594", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010594", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010594", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010594", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010594")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010595")
    void case_UTAPI_010595() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010595",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010595", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010595", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010595", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010595", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010595")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "56:space")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010596")
    void case_UTAPI_010596() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010596",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010596", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010596", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010596", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010596", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010596")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010597")
    void case_UTAPI_010597() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010597",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010597", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010597", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010597", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010597", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010597")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010598")
    void case_UTAPI_010598() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010598",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010598", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010598", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010598", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010598", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010598")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010599")
    void case_UTAPI_010599() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010599",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010599", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010599", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010599", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010599", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010599")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010600")
    void case_UTAPI_010600() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010600",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010600", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010600", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010600", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010600", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010600")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010601")
    void case_UTAPI_010601() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010601",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010601", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010601", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010601", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010601", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010601")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010602")
    void case_UTAPI_010602() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010602",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010602", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010602", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010602", "entity.tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010602", "entity.tableType", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010602")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("entity.tableName", "TableMetadata.tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableName survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010603")
    void case_UTAPI_010603() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010603",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010603", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010603", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010603", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010603", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010603")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "1:length_null", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010604")
    void case_UTAPI_010604() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010604",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010604", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010604", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010604", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010604", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010604")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "2:length_empty", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010605")
    void case_UTAPI_010605() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010605",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010605", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010605", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010605", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010605", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010605")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "3:length_min", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010606")
    void case_UTAPI_010606() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010606",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010606", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010606", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010606", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010606", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010606")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010607")
    void case_UTAPI_010607() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010607",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010607", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010607", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010607", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010607", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010607")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "5:length_max", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010608")
    void case_UTAPI_010608() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010608",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010608", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010608", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010608", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010608", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010608")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010609")
    void case_UTAPI_010609() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010609",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010609", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010609", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010609", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010609", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010609")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010610")
    void case_UTAPI_010610() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010610",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010610", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010610", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010610", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010610", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010610")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010611")
    void case_UTAPI_010611() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010611",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010611", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010611", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010611", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010611", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010611")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010612")
    void case_UTAPI_010612() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010612",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010612", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010612", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010612", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010612", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010612")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010613")
    void case_UTAPI_010613() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010613",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010613", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010613", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010613", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010613", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010613")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010614")
    void case_UTAPI_010614() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010614",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010614", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010614", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010614", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010614", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010614")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010615")
    void case_UTAPI_010615() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010615",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010615", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010615", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010615", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010615", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010615")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "56:space")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010616")
    void case_UTAPI_010616() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010616",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010616", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010616", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010616", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010616", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010616")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010617")
    void case_UTAPI_010617() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010617",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010617", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010617", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010617", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010617", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010617")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010618")
    void case_UTAPI_010618() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010618",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010618", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010618", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010618", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010618", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010618")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "59:tab")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010619")
    void case_UTAPI_010619() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010619",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010619", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010619", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010619", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010619", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010619")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "60:control_character_null")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010620")
    void case_UTAPI_010620() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010620",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010620", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010620", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010620", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010620", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010620")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010621")
    void case_UTAPI_010621() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010621",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010621", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010621", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010621", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010621", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010621")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010622")
    void case_UTAPI_010622() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010622",
                "com.matsushita.dbeditor.dto.outdto.TableMetadataResponse",
                "fromEntity",
                "TableMetadataResponse",
                new ParamSpec[] {
                    new ParamSpec("entity", "TableMetadata", "entity")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010622", "entity", "NORMAL", "OBJECT", "TableMetadata"),
                    new DataRef("UTAPI-010622", "entity.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010622", "entity.tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010622", "entity.tableType", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010622")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TableMetadataResponse.java::TableMetadataResponse::fromEntity::1::FIELD::1::TableMetadata::tableType")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("entity.tableType", "TableMetadata.tableType")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TableMetadataResponse.fromEntity")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for entity.tableType survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getSchemaName must carry entity.schemaName", "getSchemaName", "data:entity.schemaName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableName must carry entity.tableName", "getTableName", "data:entity.tableName")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTableType must carry entity.tableType", "getTableType", "data:entity.tableType")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TableMetadataResponseWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionSettingRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionSettingRepository#save.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionSettingRepositorySaveScenario {

    @Test
    @DisplayName("UTAPI-006046")
    void case_UTAPI_006046() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006046",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006046", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006046", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006046", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006046", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006046", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006046", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006046", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006046", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006046", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006046", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006046")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006047")
    void case_UTAPI_006047() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006047",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006047", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006047", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006047", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006047", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006047", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006047", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006047", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006047", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006047", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006047", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006047")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006048")
    void case_UTAPI_006048() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006048",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006048", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006048", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006048", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006048", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006048", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006048", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006048", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006048", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006048", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006048", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006048")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006049")
    void case_UTAPI_006049() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006049",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006049", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006049", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006049", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006049", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006049", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006049", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006049", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006049", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006049", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006049", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006049")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006050")
    void case_UTAPI_006050() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006050",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006050", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006050", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006050", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006050", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006050", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006050", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006050", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006050", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006050", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006050", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006050")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006051")
    void case_UTAPI_006051() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006051",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006051", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006051", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006051", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006051", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006051", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006051", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006051", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006051", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006051", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006051", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006051")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006052")
    void case_UTAPI_006052() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006052",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006052", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006052", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006052", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006052", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006052", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006052", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006052", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006052", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006052", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006052", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006052")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006053")
    void case_UTAPI_006053() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006053",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006053", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006053", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006053", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006053", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006053", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006053", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006053", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006053", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006053", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006053", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006053")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getCreatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006054")
    void case_UTAPI_006054() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006054",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006054", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006054", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006054", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006054", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006054", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006054", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006054", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006054", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006054", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006054", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006054")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006055")
    void case_UTAPI_006055() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006055",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006055", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006055", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006055", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006055", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006055", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006055", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006055", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006055", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006055", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006055", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006055")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006056")
    void case_UTAPI_006056() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006056",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006056", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006056", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006056", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006056", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006056", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006056", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006056", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006056", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006056", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006056", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006056")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006057")
    void case_UTAPI_006057() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006057",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006057", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006057", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006057", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006057", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006057", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006057", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006057", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006057", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006057", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006057", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006057")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006058")
    void case_UTAPI_006058() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006058",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006058", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006058", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006058", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006058", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006058", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006058", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006058", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006058", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006058", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006058", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006058")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006059")
    void case_UTAPI_006059() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006059",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006059", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006059", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006059", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006059", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006059", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006059", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006059", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006059", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006059", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006059", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006059")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006060")
    void case_UTAPI_006060() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006060",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006060", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006060", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006060", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006060", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006060", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006060", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006060", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006060", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006060", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006060", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006060")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006061")
    void case_UTAPI_006061() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006061",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006061", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006061", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006061", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006061", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006061", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006061", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006061", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006061", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006061", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006061", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006061")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006062")
    void case_UTAPI_006062() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006062",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006062", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006062", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006062", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006062", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006062", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006062", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006062", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006062", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006062", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006062", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006062")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006063")
    void case_UTAPI_006063() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006063",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006063", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006063", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006063", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006063", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006063", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006063", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006063", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006063", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006063", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006063", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006063")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006064")
    void case_UTAPI_006064() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006064",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006064", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006064", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006064", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006064", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006064", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006064", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006064", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006064", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006064", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006064", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006064")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006065")
    void case_UTAPI_006065() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006065",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006065", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006065", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006065", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006065", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006065", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006065", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006065", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006065", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006065", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006065", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006065")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006066")
    void case_UTAPI_006066() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006066",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006066", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006066", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006066", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006066", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006066", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006066", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006066", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006066", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006066", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006066", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006066")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006067")
    void case_UTAPI_006067() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006067",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006067", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006067", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006067", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006067", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006067", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006067", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006067", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006067", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006067", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006067", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006067")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006068")
    void case_UTAPI_006068() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006068",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006068", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006068", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006068", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006068", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006068", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006068", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006068", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006068", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006068", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006068", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006068")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006069")
    void case_UTAPI_006069() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006069",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006069", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006069", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006069", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006069", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006069", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006069", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006069", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006069", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006069", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006069", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006069")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006070")
    void case_UTAPI_006070() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006070",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006070", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006070", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006070", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006070", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006070", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006070", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006070", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006070", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006070", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006070", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006070")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006071")
    void case_UTAPI_006071() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006071",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006071", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006071", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006071", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006071", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006071", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006071", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006071", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006071", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006071", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006071", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006071")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006072")
    void case_UTAPI_006072() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006072",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006072", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006072", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006072", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006072", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006072", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006072", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006072", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006072", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006072", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006072", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006072")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006073")
    void case_UTAPI_006073() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006073",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006073", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006073", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006073", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006073", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006073", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006073", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006073", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006073", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006073", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006073", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006073")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006074")
    void case_UTAPI_006074() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006074",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006074", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006074", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006074", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006074", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006074", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006074", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006074", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006074", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006074", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006074", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006074")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006075")
    void case_UTAPI_006075() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006075",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006075", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006075", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006075", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006075", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006075", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006075", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006075", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006075", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006075", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006075", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006075")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006076")
    void case_UTAPI_006076() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006076",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006076", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006076", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006076", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006076", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006076", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006076", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006076", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006076", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006076", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006076", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006076")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006077")
    void case_UTAPI_006077() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006077",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006077", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006077", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006077", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006077", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006077", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006077", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006077", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006077", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006077", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006077", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006077")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006078")
    void case_UTAPI_006078() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006078",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006078", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006078", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006078", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006078", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006078", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006078", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006078", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006078", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006078", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006078", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006078")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006079")
    void case_UTAPI_006079() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006079",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006079", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006079", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006079", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006079", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006079", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006079", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006079", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006079", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006079", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006079", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006079")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006080")
    void case_UTAPI_006080() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006080",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006080", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006080", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006080", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006080", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006080", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006080", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006080", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006080", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006080", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006080", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006080")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006081")
    void case_UTAPI_006081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006081",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006081", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006081", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006081", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006081", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006081", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006081", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006081", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006081", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006081", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006081", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006081")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006082")
    void case_UTAPI_006082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006082",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006082", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006082", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006082", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006082", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006082", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006082", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006082", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006082", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006082", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006082", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006082")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006083")
    void case_UTAPI_006083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006083",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006083", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006083", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006083", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006083", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006083", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006083", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006083", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006083", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006083", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006083", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006083")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006084")
    void case_UTAPI_006084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006084",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006084", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006084", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006084", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006084", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006084", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006084", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006084", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006084", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006084", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006084", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006084")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006085")
    void case_UTAPI_006085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006085",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006085", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006085", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006085", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006085", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006085", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006085", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006085", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006085", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006085", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006085", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006085")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006086")
    void case_UTAPI_006086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006086",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006086", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006086", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006086", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006086", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006086", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006086", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006086", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006086", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006086", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006086", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006086")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006087")
    void case_UTAPI_006087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006087",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006087", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006087", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006087", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006087", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006087", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006087", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006087", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006087", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006087", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006087", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006087")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006088")
    void case_UTAPI_006088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006088",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006088", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006088", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006088", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006088", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006088", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006088", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006088", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006088", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006088", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006088", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006088")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006089")
    void case_UTAPI_006089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006089",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006089", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006089", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006089", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006089", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006089", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006089", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006089", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006089", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006089", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006089", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006089")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006090")
    void case_UTAPI_006090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006090",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006090", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006090", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006090", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006090", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006090", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006090", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006090", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006090", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006090", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006090", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006090")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006091")
    void case_UTAPI_006091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006091",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006091", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006091", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006091", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006091", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006091", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006091", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006091", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006091", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006091", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006091", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006091")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006092")
    void case_UTAPI_006092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006092",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006092", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006092", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006092", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006092", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006092", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006092", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006092", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006092", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006092", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006092", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006092")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006093")
    void case_UTAPI_006093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006093",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006093", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006093", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006093", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006093", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006093", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006093", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006093", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006093", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006093", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006093", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006093")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006094")
    void case_UTAPI_006094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006094",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006094", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006094", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006094", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006094", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006094", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006094", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006094", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006094", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006094", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006094", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006094")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006095")
    void case_UTAPI_006095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006095",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006095", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006095", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006095", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006095", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006095", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006095", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006095", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006095", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006095", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006095", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006095")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006096")
    void case_UTAPI_006096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006096",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006096", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006096", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006096", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006096", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006096", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006096", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006096", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006096", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006096", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006096", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006096")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006097")
    void case_UTAPI_006097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006097",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006097", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006097", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006097", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006097", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006097", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006097", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006097", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006097", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006097", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006097", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006097")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006098")
    void case_UTAPI_006098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006098",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006098", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006098", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006098", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006098", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006098", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006098", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006098", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006098", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006098", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006098", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006098")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006099")
    void case_UTAPI_006099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006099",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006099", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006099", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006099", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006099", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006099", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006099", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006099", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006099", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006099", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006099", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006099")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006100")
    void case_UTAPI_006100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006100",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006100", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006100", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006100", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006100", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006100", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006100", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006100", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006100", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006100", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006100", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006100")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006101")
    void case_UTAPI_006101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006101",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006101", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006101", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006101", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006101", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006101", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006101", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006101", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006101", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006101", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006101", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006101")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006102")
    void case_UTAPI_006102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006102",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006102", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006102", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006102", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006102", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006102", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006102", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006102", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006102", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006102", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006102", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006102")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006103")
    void case_UTAPI_006103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006103",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006103", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006103", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006103", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006103", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006103", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006103", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006103", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006103", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006103", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006103", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006103")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006104")
    void case_UTAPI_006104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006104",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006104", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006104", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006104", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006104", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006104", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006104", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006104", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006104", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006104", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006104", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006104")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006105")
    void case_UTAPI_006105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006105",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006105", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006105", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006105", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006105", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006105", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006105", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006105", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006105", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006105", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006105", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006105")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006106")
    void case_UTAPI_006106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006106",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006106", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006106", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006106", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006106", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006106", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006106", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006106", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006106", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006106", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006106", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006106")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006107")
    void case_UTAPI_006107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006107",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006107", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006107", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006107", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006107", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006107", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006107", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006107", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006107", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006107", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006107", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006107")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006108")
    void case_UTAPI_006108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006108",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006108", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006108", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006108", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006108", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006108", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006108", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006108", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006108", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006108", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006108", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006108")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006109")
    void case_UTAPI_006109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006109",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006109", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006109", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006109", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006109", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006109", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006109", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006109", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006109", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006109", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006109", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006109")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006110")
    void case_UTAPI_006110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006110",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006110", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006110", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006110", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006110", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006110", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006110", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006110", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006110", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006110", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006110", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006110")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006111")
    void case_UTAPI_006111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006111",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006111", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006111", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006111", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006111", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006111", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006111", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006111", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006111", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006111", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006111", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006111")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006112")
    void case_UTAPI_006112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006112",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006112", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006112", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006112", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006112", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006112", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006112", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006112", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006112", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006112", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006112", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006112")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006113")
    void case_UTAPI_006113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006113",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006113", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006113", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006113", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006113", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006113", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006113", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006113", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006113", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006113", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006113", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006113")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006114")
    void case_UTAPI_006114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006114",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006114", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006114", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006114", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006114", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006114", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006114", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006114", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006114", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006114", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006114", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006114")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006115")
    void case_UTAPI_006115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006115",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006115", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006115", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006115", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006115", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006115", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006115", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006115", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006115", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006115", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006115", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006115")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006116")
    void case_UTAPI_006116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006116",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006116", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006116", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006116", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006116", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006116", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006116", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006116", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006116", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006116", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006116", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006116")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006117")
    void case_UTAPI_006117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006117",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006117", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006117", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006117", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006117", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006117", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006117", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006117", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006117", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006117", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006117", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006117")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006118")
    void case_UTAPI_006118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006118",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006118", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006118", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006118", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006118", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006118", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006118", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006118", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006118", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006118", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006118", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006118")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006119")
    void case_UTAPI_006119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006119",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006119", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006119", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006119", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006119", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006119", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006119", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006119", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006119", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006119", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006119", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006119")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006120")
    void case_UTAPI_006120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006120",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006120", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006120", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006120", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006120", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006120", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006120", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006120", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006120", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006120", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006120", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006120")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006121")
    void case_UTAPI_006121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006121",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006121", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006121", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006121", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006121", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006121", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006121", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006121", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006121", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006121", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006121", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006121")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006122")
    void case_UTAPI_006122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006122",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006122", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006122", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006122", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006122", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006122", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006122", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006122", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006122", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006122", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006122", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006122")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006123")
    void case_UTAPI_006123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006123",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006123", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006123", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006123", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006123", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006123", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006123", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006123", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006123", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006123", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006123", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006123")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006124")
    void case_UTAPI_006124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006124",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006124", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006124", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006124", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006124", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006124", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006124", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006124", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006124", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006124", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006124", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006124")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006125")
    void case_UTAPI_006125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006125",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006125", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006125", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006125", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006125", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006125", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006125", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006125", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006125", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006125", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006125", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006125")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006126")
    void case_UTAPI_006126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006126",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006126", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006126", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006126", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006126", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006126", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006126", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006126", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006126", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006126", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006126", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006126")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006127")
    void case_UTAPI_006127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006127",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006127", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006127", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006127", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006127", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006127", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006127", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006127", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006127", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006127", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006127", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006127")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006128")
    void case_UTAPI_006128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006128",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006128", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006128", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006128", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006128", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006128", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006128", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006128", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006128", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006128", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006128", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006128")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006129")
    void case_UTAPI_006129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006129",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006129", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006129", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006129", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006129", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006129", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006129", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006129", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006129", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006129", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006129", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006129")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006130")
    void case_UTAPI_006130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006130",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006130", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006130", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006130", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006130", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006130", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006130", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006130", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006130", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006130", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006130", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006130")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006131")
    void case_UTAPI_006131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006131",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006131", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006131", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006131", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006131", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006131", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006131", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006131", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006131", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006131", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006131", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006131")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006132")
    void case_UTAPI_006132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006132",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006132", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006132", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006132", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006132", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006132", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006132", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006132", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006132", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006132", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006132", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006132")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006133")
    void case_UTAPI_006133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006133",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006133", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006133", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006133", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006133", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006133", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006133", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006133", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006133", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006133", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006133", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006133")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006134")
    void case_UTAPI_006134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006134",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006134", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006134", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006134", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006134", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006134", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006134", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006134", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006134", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006134", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006134", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006134")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006135")
    void case_UTAPI_006135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006135",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006135", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006135", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006135", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006135", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006135", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006135", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006135", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006135", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006135", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006135", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006135")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006136")
    void case_UTAPI_006136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006136",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006136", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006136", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006136", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006136", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006136", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006136", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006136", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006136", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006136", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006136", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006136")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006137")
    void case_UTAPI_006137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006137",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006137", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006137", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006137", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006137", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006137", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006137", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006137", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006137", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006137", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006137", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006137")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006138")
    void case_UTAPI_006138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006138",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006138", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006138", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006138", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006138", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006138", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006138", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006138", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006138", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006138", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006138", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006138")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006139")
    void case_UTAPI_006139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006139",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006139", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006139", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006139", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006139", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006139", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006139", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006139", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006139", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006139", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006139", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006139")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006140")
    void case_UTAPI_006140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006140",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006140", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006140", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006140", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006140", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006140", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006140", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006140", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006140", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006140", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006140", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006140")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006141")
    void case_UTAPI_006141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006141",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006141", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006141", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006141", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006141", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006141", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006141", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006141", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006141", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006141", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006141", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006141")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006142")
    void case_UTAPI_006142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006142",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006142", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006142", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006142", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006142", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006142", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006142", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006142", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006142", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006142", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006142", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006142")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006143")
    void case_UTAPI_006143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006143",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006143", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006143", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006143", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006143", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006143", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006143", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006143", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006143", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006143", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006143", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006143")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006144")
    void case_UTAPI_006144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006144",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006144", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006144", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006144", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006144", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006144", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006144", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006144", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006144", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006144", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006144", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006144")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006145")
    void case_UTAPI_006145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006145",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006145", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006145", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006145", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006145", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006145", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006145", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006145", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006145", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006145", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006145", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006145")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006146")
    void case_UTAPI_006146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006146",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006146", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006146", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006146", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006146", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006146", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006146", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006146", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006146", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006146", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006146", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006146")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006147")
    void case_UTAPI_006147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006147",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006147", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006147", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006147", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006147", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006147", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006147", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006147", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006147", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006147", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006147", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006147")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006148")
    void case_UTAPI_006148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006148",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006148", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006148", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006148", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006148", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006148", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006148", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006148", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006148", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006148", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006148", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006148")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006149")
    void case_UTAPI_006149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006149",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006149", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006149", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006149", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006149", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006149", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006149", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006149", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006149", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006149", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006149", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006149")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006150")
    void case_UTAPI_006150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006150",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006150", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006150", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006150", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006150", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006150", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006150", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006150", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006150", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006150", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006150", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006150")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006151")
    void case_UTAPI_006151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006151",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006151", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006151", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006151", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006151", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006151", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006151", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006151", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006151", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006151", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006151", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006151")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006152")
    void case_UTAPI_006152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006152",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006152", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006152", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006152", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006152", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006152", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006152", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006152", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006152", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006152", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006152", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006152")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006153")
    void case_UTAPI_006153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006153",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006153", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006153", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006153", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006153", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006153", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006153", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006153", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006153", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006153", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006153", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006153")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006154")
    void case_UTAPI_006154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006154",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006154", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006154", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006154", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006154", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006154", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006154", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006154", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006154", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006154", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006154", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006154")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006155")
    void case_UTAPI_006155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006155",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006155", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006155", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006155", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006155", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006155", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006155", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006155", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006155", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006155", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006155", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006155")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006156")
    void case_UTAPI_006156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006156",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006156", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006156", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006156", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006156", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006156", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006156", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006156", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006156", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006156", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006156", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006156")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006157")
    void case_UTAPI_006157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006157",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006157", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006157", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006157", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006157", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006157", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006157", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006157", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006157", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006157", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006157", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006157")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006158")
    void case_UTAPI_006158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006158",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006158", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006158", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006158", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006158", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006158", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006158", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006158", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006158", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006158", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006158", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006158")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006159")
    void case_UTAPI_006159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006159",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006159", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006159", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006159", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006159", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006159", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006159", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006159", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006159", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006159", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006159", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006159")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006160")
    void case_UTAPI_006160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006160",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006160", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006160", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006160", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006160", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006160", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006160", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006160", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006160", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006160", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006160", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006160")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006161")
    void case_UTAPI_006161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006161",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006161", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006161", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006161", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006161", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006161", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006161", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006161", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006161", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006161", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006161", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006161")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006162")
    void case_UTAPI_006162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006162",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006162", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006162", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006162", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006162", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006162", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006162", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006162", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006162", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006162", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006162", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006162")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006163")
    void case_UTAPI_006163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006163",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006163", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006163", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006163", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006163", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006163", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006163", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006163", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006163", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006163", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006163", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006163")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006164")
    void case_UTAPI_006164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006164",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006164", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006164", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006164", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006164", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006164", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006164", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006164", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006164", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006164", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006164", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006164")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006165")
    void case_UTAPI_006165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006165",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006165", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006165", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006165", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006165", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006165", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006165", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006165", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006165", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006165", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006165", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006165")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006166")
    void case_UTAPI_006166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006166",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006166", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006166", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006166", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006166", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006166", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006166", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006166", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006166", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006166", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006166", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006166")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006167")
    void case_UTAPI_006167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006167",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006167", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006167", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006167", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006167", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006167", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006167", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006167", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006167", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006167", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006167", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006167")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006168")
    void case_UTAPI_006168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006168",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006168", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006168", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006168", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006168", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006168", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006168", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006168", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006168", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006168", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006168", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006168")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006169")
    void case_UTAPI_006169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006169",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006169", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006169", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006169", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006169", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006169", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006169", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006169", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006169", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006169", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006169", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006169")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006170")
    void case_UTAPI_006170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006170",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006170", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006170", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006170", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006170", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006170", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006170", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006170", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006170", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006170", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006170", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006170")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006171")
    void case_UTAPI_006171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006171",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006171", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006171", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006171", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006171", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006171", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006171", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006171", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006171", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006171", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006171", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006171")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006172")
    void case_UTAPI_006172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006172",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006172", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006172", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006172", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006172", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006172", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006172", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006172", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006172", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006172", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006172", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006172")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006173")
    void case_UTAPI_006173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006173",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006173", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006173", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006173", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006173", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006173", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006173", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006173", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006173", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006173", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006173", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006173")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006174")
    void case_UTAPI_006174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006174",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006174", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006174", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006174", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006174", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006174", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006174", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006174", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006174", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006174", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006174", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006174")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006175")
    void case_UTAPI_006175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006175",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006175", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006175", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006175", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006175", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006175", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006175", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006175", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006175", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006175", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006175", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006175")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006176")
    void case_UTAPI_006176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006176",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006176", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006176", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006176", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006176", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006176", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006176", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006176", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006176", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006176", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006176", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006176")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006177")
    void case_UTAPI_006177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006177",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006177", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006177", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006177", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006177", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006177", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006177", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006177", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006177", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006177", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006177", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006177")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006178")
    void case_UTAPI_006178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006178",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006178", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006178", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006178", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006178", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006178", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006178", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006178", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006178", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006178", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006178", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006178")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry an identity", "getN")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006179")
    void case_UTAPI_006179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006179",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006179", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006179", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006179", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006179", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006179", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006179", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006179", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006179", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006179", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006179", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006179")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006180")
    void case_UTAPI_006180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006180",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006180", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006180", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006180", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006180", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006180", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006180", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006180", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006180", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006180", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006180", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006180")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006181")
    void case_UTAPI_006181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006181",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006181", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006181", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006181", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006181", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006181", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006181", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006181", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006181", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006181", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006181", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006181")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006182")
    void case_UTAPI_006182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006182",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006182", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006182", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006182", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006182", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006182", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006182", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006182", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006182", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006182", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006182", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006182")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006183")
    void case_UTAPI_006183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006183",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006183", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006183", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006183", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006183", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006183", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006183", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006183", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006183", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006183", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006183", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006183")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006184")
    void case_UTAPI_006184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006184",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006184", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006184", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006184", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006184", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006184", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006184", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006184", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006184", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006184", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006184", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006184")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006185")
    void case_UTAPI_006185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006185",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006185", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006185", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006185", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006185", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006185", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006185", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006185", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006185", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006185", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006185", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006185")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006186")
    void case_UTAPI_006186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006186",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "save",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006186", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006186", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006186", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006186", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006186", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006186", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006186", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006186", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006186", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006186", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006186")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::save::3::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

}

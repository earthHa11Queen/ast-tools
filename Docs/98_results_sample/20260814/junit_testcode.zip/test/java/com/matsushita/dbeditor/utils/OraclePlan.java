package com.matsushita.dbeditor.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The Oracle Plan decided for one CaseNo.
 *
 * <p>Observation / Expected / Failure discrimination / Assertion are kept together with
 * the executable checks so the semantic decision taken while reading the validated test
 * specification, the Mirror conditions, the AST and the test data instruction is not lost
 * on the way to the JUnit assertion.</p>
 */
public final class OraclePlan {

    private final String caseNo;
    private final String targetId;
    private final String mirrorX;
    private final String mirrorY;
    private final String mirrorZ;
    private final String targetDataId;
    private final String targetPath;
    private final String nullable;
    private final String validationMin;
    private final String validationMax;
    private final String targetAnnotations;
    private final OracleKind kind;
    private final String observation;
    private final String expected;
    private final String failureDiscrimination;
    private final String assertionText;
    private final List<OracleCheck> checks;

    private OraclePlan(Builder b) {
        this.caseNo = b.caseNo;
        this.targetId = b.targetId;
        this.mirrorX = b.mirrorX;
        this.mirrorY = b.mirrorY;
        this.mirrorZ = b.mirrorZ;
        this.targetDataId = b.targetDataId;
        this.targetPath = b.targetPath;
        this.nullable = b.nullable;
        this.validationMin = b.validationMin;
        this.validationMax = b.validationMax;
        this.targetAnnotations = b.targetAnnotations;
        this.kind = b.kind;
        this.observation = b.observation;
        this.expected = b.expected;
        this.failureDiscrimination = b.failureDiscrimination;
        this.assertionText = b.assertionText;
        this.checks = Collections.unmodifiableList(new ArrayList<OracleCheck>(b.checks));
    }

    public String caseNo() {
        return caseNo;
    }

    public String targetId() {
        return targetId;
    }

    public String mirrorX() {
        return mirrorX;
    }

    public String mirrorY() {
        return mirrorY;
    }

    public String mirrorZ() {
        return mirrorZ;
    }

    public String targetDataId() {
        return targetDataId;
    }

    public String targetPath() {
        return targetPath;
    }

    public String nullable() {
        return nullable;
    }

    public String validationMin() {
        return validationMin;
    }

    public String validationMax() {
        return validationMax;
    }

    public String targetAnnotations() {
        return targetAnnotations;
    }

    public OracleKind kind() {
        return kind;
    }

    public String observation() {
        return observation;
    }

    public String expected() {
        return expected;
    }

    public String failureDiscrimination() {
        return failureDiscrimination;
    }

    public String assertionText() {
        return assertionText;
    }

    public List<OracleCheck> checks() {
        return checks;
    }

    public String describe() {
        StringBuilder sb = new StringBuilder();
        sb.append("CaseNo=").append(caseNo).append('\n');
        sb.append("  targetId=").append(targetId).append('\n');
        sb.append("  Mirror X=").append(mirrorX).append(" Y=").append(mirrorY).append(" Z=").append(mirrorZ).append('\n');
        sb.append("  target=").append(targetDataId);
        sb.append(" nullable=").append(nullable);
        sb.append(" validationMin=").append(validationMin);
        sb.append(" validationMax=").append(validationMax);
        sb.append(" annotations=").append(targetAnnotations).append('\n');
        sb.append("  Oracle kind=").append(kind).append('\n');
        sb.append("  Observation=").append(observation).append('\n');
        sb.append("  Expected=").append(expected).append('\n');
        sb.append("  Failure discrimination=").append(failureDiscrimination).append('\n');
        sb.append("  Assertion=").append(assertionText);
        return sb.toString();
    }

    public static Builder builder(String caseNo) {
        return new Builder(caseNo);
    }

    /** Builder used by the generated scenarios. */
    public static final class Builder {

        private final String caseNo;
        private String targetId = "-";
        private String mirrorX = "-";
        private String mirrorY = "-";
        private String mirrorZ = "-";
        private String targetDataId = "-";
        private String targetPath = "-";
        private String nullable = "-1";
        private String validationMin = "-1";
        private String validationMax = "-1";
        private String targetAnnotations = "-";
        private OracleKind kind = OracleKind.DELEGATION_CONTRACT;
        private String observation = "-";
        private String expected = "-";
        private String failureDiscrimination = "-";
        private String assertionText = "-";
        private final List<OracleCheck> checks = new ArrayList<OracleCheck>();

        private Builder(String caseNo) {
            this.caseNo = caseNo;
        }

        public Builder targetId(String v) {
            this.targetId = v;
            return this;
        }

        public Builder mirror(String x, String y, String z) {
            this.mirrorX = x;
            this.mirrorY = y;
            this.mirrorZ = z;
            return this;
        }

        public Builder target(String dataId, String path) {
            this.targetDataId = dataId;
            this.targetPath = path;
            return this;
        }

        public Builder validation(String nullable, String min, String max, String annotations) {
            this.nullable = nullable;
            this.validationMin = min;
            this.validationMax = max;
            this.targetAnnotations = annotations;
            return this;
        }

        public Builder kind(OracleKind v) {
            this.kind = v;
            return this;
        }

        public Builder observation(String v) {
            this.observation = v;
            return this;
        }

        public Builder expected(String v) {
            this.expected = v;
            return this;
        }

        public Builder failure(String v) {
            this.failureDiscrimination = v;
            return this;
        }

        public Builder assertion(String v) {
            this.assertionText = v;
            return this;
        }

        public Builder check(CheckType type, String description, String... params) {
            this.checks.add(new OracleCheck(type, description, params));
            return this;
        }

        public OraclePlan build() {
            return new OraclePlan(this);
        }
    }
}

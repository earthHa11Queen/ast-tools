package com.matsushita.dbeditor.utils;

/**
 * One row of test-data-instruction that the scenario needs at execution time.
 */
public final class DataRef {

    private final String caseNo;
    private final String dataId;
    private final String dataRole;
    private final String convModel;
    private final String referenceType;

    public DataRef(String caseNo, String dataId, String dataRole, String convModel, String referenceType) {
        this.caseNo = caseNo;
        this.dataId = dataId;
        this.dataRole = dataRole;
        this.convModel = convModel;
        this.referenceType = referenceType;
    }

    public String caseNo() {
        return caseNo;
    }

    public String dataId() {
        return dataId;
    }

    public String dataRole() {
        return dataRole;
    }

    public String convModel() {
        return convModel;
    }

    public String referenceType() {
        return referenceType;
    }

    @Override
    public String toString() {
        return dataId + "[" + dataRole + "/" + convModel + "/" + referenceType + "]";
    }
}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableController#updateCopyRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableControllerUpdateCopyRecordsScenario {

    @Test
    @DisplayName("UTAPI-001687")
    void case_UTAPI_001687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001687",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001687", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001687", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001687", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001687", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001687", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001687", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001687", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001687", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001687")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "1:length_null", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001688")
    void case_UTAPI_001688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001688",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001688", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001688", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001688", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001688", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001688", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001688", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001688", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001688", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001688")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "2:length_empty", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001689")
    void case_UTAPI_001689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001689",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001689", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001689", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001689", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001689", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001689", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001689", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001689", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001689", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001689")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "3:length_min", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001690")
    void case_UTAPI_001690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001690",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001690", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001690", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001690", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001690", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001690", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001690", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001690", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001690", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001690")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001691")
    void case_UTAPI_001691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001691",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001691", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001691", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001691", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001691", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001691", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001691", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001691", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001691", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001691")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "5:length_max", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001692")
    void case_UTAPI_001692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001692",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001692", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001692", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001692", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001692", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001692", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001692", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001692", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001692", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001692")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001693")
    void case_UTAPI_001693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001693",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001693", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001693", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001693", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001693", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001693", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001693", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001693", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001693", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001693")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001694")
    void case_UTAPI_001694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001694",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001694", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001694", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001694", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001694", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001694", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001694", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001694", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001694", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001694")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001695")
    void case_UTAPI_001695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001695",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001695", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001695", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001695", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001695", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001695", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001695", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001695", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001695", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001695")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001696")
    void case_UTAPI_001696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001696",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001696", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001696", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001696", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001696", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001696", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001696", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001696", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001696", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001696")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001697")
    void case_UTAPI_001697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001697",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001697", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001697", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001697", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001697", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001697", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001697", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001697", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001697", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001697")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001698")
    void case_UTAPI_001698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001698",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001698", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001698", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001698", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001698", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001698", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001698", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001698", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001698", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001698")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001699")
    void case_UTAPI_001699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001699",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001699", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001699", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001699", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001699", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001699", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001699", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001699", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001699", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001699")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001700")
    void case_UTAPI_001700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001700",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001700", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001700", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001700", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001700", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001700", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001700", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001700", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001700", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001700")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "56:space")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001701")
    void case_UTAPI_001701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001701",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001701", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001701", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001701", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001701", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001701", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001701", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001701", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001701", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001701")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001702")
    void case_UTAPI_001702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001702",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001702", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001702", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001702", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001702", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001702", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001702", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001702", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001702", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001702")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001703")
    void case_UTAPI_001703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001703",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001703", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001703", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001703", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001703", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001703", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001703", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001703", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001703", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001703")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "59:tab")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001704")
    void case_UTAPI_001704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001704",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001704", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001704", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001704", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001704", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001704", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001704", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001704", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001704", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001704")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "60:control_character_null")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001705")
    void case_UTAPI_001705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001705",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001705", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001705", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001705", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001705", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001705", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001705", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001705", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001705", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001705")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001706")
    void case_UTAPI_001706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001706",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001706", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001706", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001706", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001706", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001706", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001706", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001706", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001706", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001706")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001707")
    void case_UTAPI_001707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001707",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001707", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001707", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001707", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001707", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001707", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001707", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001707", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001707", "name", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001707")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::ARG::1::-::name")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("name", "name")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for name is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001708")
    void case_UTAPI_001708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001708",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001708", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001708", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001708", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001708", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001708", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001708", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001708", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001708", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001708")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.connectionId classifies this input condition", "TableRecordUpdateRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001709")
    void case_UTAPI_001709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001709",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001709", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001709", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001709", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001709", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001709", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001709", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001709", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001709", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001709")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.connectionId classifies this input condition", "TableRecordUpdateRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001710")
    void case_UTAPI_001710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001710",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001710", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001710", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001710", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001710", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001710", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001710", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001710", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001710", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001710")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.connectionId classifies this input condition", "TableRecordUpdateRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001711")
    void case_UTAPI_001711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001711",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001711", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001711", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001711", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001711", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001711", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001711", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001711", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001711", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001711")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.connectionId classifies this input condition", "TableRecordUpdateRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001712")
    void case_UTAPI_001712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001712",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001712", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001712", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001712", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001712", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001712", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001712", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001712", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001712", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001712")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.connectionId classifies this input condition", "TableRecordUpdateRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001713")
    void case_UTAPI_001713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001713",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001713", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001713", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001713", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001713", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001713", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001713", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001713", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001713", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001713")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.connectionId classifies this input condition", "TableRecordUpdateRequest", "connectionId", "NotNull", "data:request.connectionId")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001714")
    void case_UTAPI_001714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001714",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001714", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001714", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001714", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001714", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001714", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001714", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001714", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001714", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001714")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001715")
    void case_UTAPI_001715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001715",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001715", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001715", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001715", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001715", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001715", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001715", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001715", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001715", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001715")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001716")
    void case_UTAPI_001716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001716",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001716", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001716", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001716", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001716", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001716", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001716", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001716", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001716", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001716")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001717")
    void case_UTAPI_001717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001717",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001717", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001717", "request.connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001717", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001717", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001717", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001717", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001717", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001717", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001717")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.connectionId", "TableRecordUpdateRequest.connectionId")
                    .validation("0", "1", "18", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001718")
    void case_UTAPI_001718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001718",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001718", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001718", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001718", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001718", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001718", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001718", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001718", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001718", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001718")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::records")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.records", "TableRecordUpdateRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.records classifies this input condition", "TableRecordUpdateRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001719")
    void case_UTAPI_001719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001719",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001719", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001719", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001719", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001719", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001719", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001719", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001719", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001719", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001719")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::records")
                    .mirror("-", "3:length_min", "-")
                    .target("request.records", "TableRecordUpdateRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.records classifies this input condition", "TableRecordUpdateRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001720")
    void case_UTAPI_001720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001720",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001720", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001720", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001720", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001720", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001720", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001720", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001720", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001720", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001720")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::records")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.records", "TableRecordUpdateRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.records classifies this input condition", "TableRecordUpdateRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001721")
    void case_UTAPI_001721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001721",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001721", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001721", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001721", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001721", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001721", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001721", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001721", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001721", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001721")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::records")
                    .mirror("-", "5:length_max", "-")
                    .target("request.records", "TableRecordUpdateRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.records classifies this input condition", "TableRecordUpdateRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001722")
    void case_UTAPI_001722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001722",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001722", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001722", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001722", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001722", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001722", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001722", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001722", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001722", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001722")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::records")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.records", "TableRecordUpdateRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.records classifies this input condition", "TableRecordUpdateRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001723")
    void case_UTAPI_001723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001723",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001723", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001723", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001723", "request.records", "TARGET", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001723", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001723", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001723", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001723", "request.schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001723", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001723")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::records")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.records", "TableRecordUpdateRequest.records")
                    .validation("0", "1", "255", "@NotNull")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.records is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of TableRecordUpdateRequest.records classifies this input condition", "TableRecordUpdateRequest", "records", "NotNull", "data:request.records")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001724")
    void case_UTAPI_001724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001724",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001724", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001724", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001724", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001724", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001724", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001724", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001724", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001724", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001724")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001725")
    void case_UTAPI_001725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001725",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001725", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001725", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001725", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001725", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001725", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001725", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001725", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001725", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001725")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001726")
    void case_UTAPI_001726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001726",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001726", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001726", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001726", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001726", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001726", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001726", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001726", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001726", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001726")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001727")
    void case_UTAPI_001727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001727",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001727", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001727", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001727", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001727", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001727", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001727", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001727", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001727", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001727")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001728")
    void case_UTAPI_001728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001728",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001728", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001728", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001728", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001728", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001728", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001728", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001728", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001728", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001728")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001729")
    void case_UTAPI_001729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001729",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001729", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001729", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001729", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001729", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001729", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001729", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001729", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001729", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001729")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001730")
    void case_UTAPI_001730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001730",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001730", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001730", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001730", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001730", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001730", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001730", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001730", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001730", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001730")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001731")
    void case_UTAPI_001731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001731",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001731", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001731", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001731", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001731", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001731", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001731", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001731", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001731", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001731")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001732")
    void case_UTAPI_001732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001732",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001732", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001732", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001732", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001732", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001732", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001732", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001732", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001732", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001732")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001733")
    void case_UTAPI_001733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001733",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001733", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001733", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001733", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001733", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001733", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001733", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001733", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001733", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001733")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001734")
    void case_UTAPI_001734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001734",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001734", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001734", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001734", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001734", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001734", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001734", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001734", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001734", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001734")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001735")
    void case_UTAPI_001735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001735",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001735", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001735", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001735", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001735", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001735", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001735", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001735", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001735", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001735")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001736")
    void case_UTAPI_001736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001736",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001736", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001736", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001736", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001736", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001736", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001736", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001736", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001736", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001736")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001737")
    void case_UTAPI_001737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001737",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001737", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001737", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001737", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001737", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001737", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001737", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001737", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001737", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001737")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001738")
    void case_UTAPI_001738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001738",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001738", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001738", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001738", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001738", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001738", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001738", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001738", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001738", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001738")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001739")
    void case_UTAPI_001739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001739",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001739", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001739", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001739", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001739", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001739", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001739", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001739", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001739", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001739")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001740")
    void case_UTAPI_001740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001740",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001740", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001740", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001740", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001740", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001740", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001740", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001740", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001740", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001740")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001741")
    void case_UTAPI_001741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001741",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001741", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001741", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001741", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001741", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001741", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001741", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001741", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001741", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001741")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001742")
    void case_UTAPI_001742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001742",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001742", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001742", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001742", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001742", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001742", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001742", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001742", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001742", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001742")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001743")
    void case_UTAPI_001743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001743",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001743", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001743", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001743", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001743", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001743", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001743", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001743", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001743", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001743")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-001744")
    void case_UTAPI_001744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-001744",
                "com.matsushita.dbeditor.adapter.controller.TableController",
                "updateCopyRecords",
                "ResponseEntity<Void>",
                new ParamSpec[] {
                    new ParamSpec("name", "String", "name"),
                    new ParamSpec("request", "TableRecordUpdateRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-001744", "request", "NORMAL", "OBJECT", "TableRecordUpdateRequest"),
                    new DataRef("UTAPI-001744", "request.connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-001744", "request.records", "NORMAL", "COLLECTION", "List<Map<String,Object>>"),
                    new DataRef("UTAPI-001744", "request.records[]", "NORMAL", "MAP", "Map<String, Object>"),
                    new DataRef("UTAPI-001744", "request.records[]{key}", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-001744", "request.records[]{value}", "NORMAL", "OBJECT", "Object"),
                    new DataRef("UTAPI-001744", "request.schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-001744", "name", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-001744")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/TableController.java::TableController::updateCopyRecords::6::FIELD::2::TableRecordUpdateRequest::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.schemaName", "TableRecordUpdateRequest.schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of tableRecordUseCase.updateCopyRecords")
                    .expected("the value generated for request.schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableRecordUseCase.updateCopyRecords", "tableRecordUseCase", "updateCopyRecords")
                    .check(CheckType.ARG_EQUALS, "argument 0 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.connectionId", "tableRecordUseCase", "updateCopyRecords", "0", "data:request.connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.schemaName", "tableRecordUseCase", "updateCopyRecords", "1", "data:request.schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableRecordUseCase.updateCopyRecords must carry the value generated for name", "tableRecordUseCase", "updateCopyRecords", "2", "data:name")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableRecordUseCase.updateCopyRecords must carry the value generated for request.records", "tableRecordUseCase", "updateCopyRecords", "3", "data:request.records")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableControllerWrapper());
    }

}

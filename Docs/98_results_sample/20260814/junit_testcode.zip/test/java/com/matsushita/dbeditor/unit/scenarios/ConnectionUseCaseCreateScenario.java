package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionUseCase#create.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionUseCaseCreateScenario {

    @Test
    @DisplayName("UTAPI-011719")
    void case_UTAPI_011719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011719",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011719", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011719", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011719", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011719", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011719", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011719", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011719", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011719")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.databaseName classifies this input condition", "ConnectionSettingRequest", "databaseName", "NotBlank", "data:request.databaseName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011720")
    void case_UTAPI_011720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011720",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011720", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011720", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011720", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011720", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011720", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011720", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011720", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011720")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011721")
    void case_UTAPI_011721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011721",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011721", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011721", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011721", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011721", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011721", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011721", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011721", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011721")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011722")
    void case_UTAPI_011722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011722",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011722", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011722", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011722", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011722", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011722", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011722", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011722", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011722")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011723")
    void case_UTAPI_011723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011723",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011723", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011723", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011723", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011723", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011723", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011723", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011723", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011723")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011724")
    void case_UTAPI_011724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011724",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011724", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011724", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011724", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011724", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011724", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011724", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011724", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011724")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011725")
    void case_UTAPI_011725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011725",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011725", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011725", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011725", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011725", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011725", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011725", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011725", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011725")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011726")
    void case_UTAPI_011726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011726",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011726", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011726", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011726", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011726", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011726", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011726", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011726", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011726")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011727")
    void case_UTAPI_011727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011727",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011727", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011727", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011727", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011727", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011727", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011727", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011727", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011727")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011728")
    void case_UTAPI_011728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011728",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011728", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011728", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011728", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011728", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011728", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011728", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011728", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011728")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011729")
    void case_UTAPI_011729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011729",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011729", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011729", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011729", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011729", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011729", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011729", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011729", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011729")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011730")
    void case_UTAPI_011730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011730",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011730", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011730", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011730", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011730", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011730", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011730", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011730", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011730")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011731")
    void case_UTAPI_011731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011731",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011731", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011731", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011731", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011731", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011731", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011731", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011731", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011731")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011732")
    void case_UTAPI_011732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011732",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011732", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011732", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011732", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011732", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011732", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011732", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011732", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011732")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011733")
    void case_UTAPI_011733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011733",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011733", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011733", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011733", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011733", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011733", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011733", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011733", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011733")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011734")
    void case_UTAPI_011734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011734",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011734", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011734", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011734", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011734", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011734", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011734", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011734", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011734")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011735")
    void case_UTAPI_011735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011735",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011735", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011735", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011735", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011735", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011735", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011735", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011735", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011735")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011736")
    void case_UTAPI_011736() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011736",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011736", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011736", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011736", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011736", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011736", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011736", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011736", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011736")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011737")
    void case_UTAPI_011737() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011737",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011737", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011737", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011737", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011737", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011737", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011737", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011737", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011737")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011738")
    void case_UTAPI_011738() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011738",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011738", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011738", "request.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011738", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011738", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011738", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011738", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011738", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011738")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.databaseName", "ConnectionSettingRequest.databaseName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.databaseName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011739")
    void case_UTAPI_011739() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011739",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011739", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011739", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011739", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011739", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011739", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011739", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011739", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011739")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbHost classifies this input condition", "ConnectionSettingRequest", "dbHost", "NotBlank", "data:request.dbHost")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011740")
    void case_UTAPI_011740() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011740",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011740", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011740", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011740", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011740", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011740", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011740", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011740", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011740")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011741")
    void case_UTAPI_011741() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011741",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011741", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011741", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011741", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011741", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011741", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011741", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011741", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011741")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011742")
    void case_UTAPI_011742() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011742",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011742", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011742", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011742", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011742", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011742", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011742", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011742", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011742")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011743")
    void case_UTAPI_011743() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011743",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011743", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011743", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011743", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011743", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011743", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011743", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011743", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011743")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011744")
    void case_UTAPI_011744() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011744",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011744", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011744", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011744", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011744", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011744", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011744", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011744", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011744")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011745")
    void case_UTAPI_011745() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011745",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011745", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011745", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011745", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011745", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011745", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011745", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011745", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011745")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011746")
    void case_UTAPI_011746() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011746",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011746", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011746", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011746", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011746", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011746", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011746", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011746", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011746")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011747")
    void case_UTAPI_011747() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011747",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011747", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011747", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011747", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011747", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011747", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011747", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011747", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011747")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011748")
    void case_UTAPI_011748() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011748",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011748", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011748", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011748", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011748", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011748", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011748", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011748", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011748")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011749")
    void case_UTAPI_011749() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011749",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011749", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011749", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011749", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011749", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011749", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011749", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011749", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011749")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011750")
    void case_UTAPI_011750() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011750",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011750", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011750", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011750", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011750", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011750", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011750", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011750", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011750")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011751")
    void case_UTAPI_011751() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011751",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011751", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011751", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011751", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011751", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011751", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011751", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011751", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011751")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011752")
    void case_UTAPI_011752() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011752",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011752", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011752", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011752", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011752", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011752", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011752", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011752", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011752")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011753")
    void case_UTAPI_011753() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011753",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011753", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011753", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011753", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011753", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011753", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011753", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011753", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011753")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011754")
    void case_UTAPI_011754() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011754",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011754", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011754", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011754", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011754", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011754", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011754", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011754", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011754")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011755")
    void case_UTAPI_011755() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011755",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011755", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011755", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011755", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011755", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011755", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011755", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011755", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011755")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011756")
    void case_UTAPI_011756() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011756",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011756", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011756", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011756", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011756", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011756", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011756", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011756", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011756")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011757")
    void case_UTAPI_011757() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011757",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011757", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011757", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011757", "request.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011757", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011757", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011757", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011757", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011757")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbHost", "ConnectionSettingRequest.dbHost")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbHost is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011758")
    void case_UTAPI_011758() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011758",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011758", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011758", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011758", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011758", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011758", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011758", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011758", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011758")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbName classifies this input condition", "ConnectionSettingRequest", "dbName", "NotBlank", "data:request.dbName")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011759")
    void case_UTAPI_011759() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011759",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011759", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011759", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011759", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011759", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011759", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011759", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011759", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011759")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011760")
    void case_UTAPI_011760() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011760",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011760", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011760", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011760", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011760", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011760", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011760", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011760", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011760")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011761")
    void case_UTAPI_011761() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011761",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011761", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011761", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011761", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011761", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011761", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011761", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011761", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011761")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011762")
    void case_UTAPI_011762() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011762",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011762", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011762", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011762", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011762", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011762", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011762", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011762", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011762")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011763")
    void case_UTAPI_011763() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011763",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011763", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011763", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011763", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011763", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011763", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011763", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011763", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011763")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011764")
    void case_UTAPI_011764() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011764",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011764", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011764", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011764", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011764", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011764", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011764", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011764", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011764")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011765")
    void case_UTAPI_011765() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011765",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011765", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011765", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011765", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011765", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011765", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011765", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011765", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011765")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011766")
    void case_UTAPI_011766() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011766",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011766", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011766", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011766", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011766", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011766", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011766", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011766", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011766")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011767")
    void case_UTAPI_011767() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011767",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011767", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011767", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011767", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011767", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011767", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011767", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011767", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011767")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011768")
    void case_UTAPI_011768() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011768",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011768", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011768", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011768", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011768", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011768", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011768", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011768", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011768")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011769")
    void case_UTAPI_011769() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011769",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011769", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011769", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011769", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011769", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011769", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011769", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011769", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011769")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011770")
    void case_UTAPI_011770() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011770",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011770", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011770", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011770", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011770", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011770", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011770", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011770", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011770")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "56:space")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011771")
    void case_UTAPI_011771() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011771",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011771", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011771", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011771", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011771", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011771", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011771", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011771", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011771")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011772")
    void case_UTAPI_011772() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011772",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011772", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011772", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011772", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011772", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011772", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011772", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011772", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011772")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011773")
    void case_UTAPI_011773() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011773",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011773", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011773", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011773", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011773", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011773", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011773", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011773", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011773")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011774")
    void case_UTAPI_011774() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011774",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011774", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011774", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011774", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011774", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011774", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011774", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011774", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011774")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011775")
    void case_UTAPI_011775() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011775",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011775", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011775", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011775", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011775", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011775", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011775", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011775", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011775")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011776")
    void case_UTAPI_011776() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011776",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011776", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011776", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011776", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011776", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011776", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011776", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011776", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011776")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011777")
    void case_UTAPI_011777() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011777",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011777", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011777", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011777", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011777", "request.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011777", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011777", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011777", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011777")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbName", "ConnectionSettingRequest.dbName")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011778")
    void case_UTAPI_011778() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011778",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011778", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011778", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011778", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011778", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011778", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011778", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011778", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011778")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbPassword classifies this input condition", "ConnectionSettingRequest", "dbPassword", "NotBlank", "data:request.dbPassword")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011779")
    void case_UTAPI_011779() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011779",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011779", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011779", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011779", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011779", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011779", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011779", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011779", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011779")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011780")
    void case_UTAPI_011780() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011780",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011780", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011780", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011780", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011780", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011780", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011780", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011780", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011780")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011781")
    void case_UTAPI_011781() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011781",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011781", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011781", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011781", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011781", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011781", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011781", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011781", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011781")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011782")
    void case_UTAPI_011782() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011782",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011782", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011782", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011782", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011782", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011782", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011782", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011782", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011782")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011783")
    void case_UTAPI_011783() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011783",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011783", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011783", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011783", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011783", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011783", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011783", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011783", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011783")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011784")
    void case_UTAPI_011784() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011784",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011784", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011784", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011784", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011784", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011784", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011784", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011784", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011784")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011785")
    void case_UTAPI_011785() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011785",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011785", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011785", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011785", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011785", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011785", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011785", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011785", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011785")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011786")
    void case_UTAPI_011786() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011786",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011786", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011786", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011786", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011786", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011786", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011786", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011786", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011786")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011787")
    void case_UTAPI_011787() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011787",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011787", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011787", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011787", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011787", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011787", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011787", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011787", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011787")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011788")
    void case_UTAPI_011788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011788",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011788", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011788", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011788", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011788", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011788", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011788", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011788", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011788")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011789")
    void case_UTAPI_011789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011789",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011789", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011789", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011789", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011789", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011789", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011789", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011789", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011789")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011790")
    void case_UTAPI_011790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011790",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011790", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011790", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011790", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011790", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011790", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011790", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011790", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011790")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011791")
    void case_UTAPI_011791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011791",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011791", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011791", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011791", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011791", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011791", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011791", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011791", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011791")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011792")
    void case_UTAPI_011792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011792",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011792", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011792", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011792", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011792", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011792", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011792", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011792", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011792")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011793")
    void case_UTAPI_011793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011793",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011793", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011793", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011793", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011793", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011793", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011793", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011793", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011793")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011794")
    void case_UTAPI_011794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011794",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011794", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011794", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011794", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011794", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011794", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011794", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011794", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011794")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011795")
    void case_UTAPI_011795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011795",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011795", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011795", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011795", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011795", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011795", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011795", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011795", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011795")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011796")
    void case_UTAPI_011796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011796",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011796", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011796", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011796", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011796", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011796", "request.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-011796", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011796", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011796")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbPassword", "ConnectionSettingRequest.dbPassword")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPassword is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011797")
    void case_UTAPI_011797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011797",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011797", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011797", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011797", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011797", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011797", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011797", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011797", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011797")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011798")
    void case_UTAPI_011798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011798",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011798", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011798", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011798", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011798", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011798", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011798", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011798", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011798")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011799")
    void case_UTAPI_011799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011799",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011799", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011799", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011799", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011799", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011799", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011799", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011799", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011799")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011800")
    void case_UTAPI_011800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011800",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011800", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011800", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011800", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011800", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011800", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011800", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011800", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011800")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011801")
    void case_UTAPI_011801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011801",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011801", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011801", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011801", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011801", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011801", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011801", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011801", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011801")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011802")
    void case_UTAPI_011802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011802",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011802", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011802", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011802", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011802", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011802", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011802", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011802", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011802")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared NotNull contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "NotNull", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Min contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Min", "data:request.dbPort")
                    .check(CheckType.CONSTRAINT_VIOLATION_ABSENT, "declared Max contract of ConnectionSettingRequest.dbPort classifies this input condition", "ConnectionSettingRequest", "dbPort", "Max", "data:request.dbPort")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011803")
    void case_UTAPI_011803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011803",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011803", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011803", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011803", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011803", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011803", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011803", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011803", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011803")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011804")
    void case_UTAPI_011804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011804",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011804", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011804", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011804", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011804", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011804", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011804", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011804", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011804")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011805")
    void case_UTAPI_011805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011805",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011805", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011805", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011805", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011805", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011805", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011805", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011805", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011805")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011806")
    void case_UTAPI_011806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011806",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011806", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011806", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011806", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011806", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011806", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011806", "request.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011806", "request.dbUsername", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011806")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("request.dbPort", "ConnectionSettingRequest.dbPort")
                    .validation("0", "1", "65535", "@NotNull @Min(1) @Max(65535)")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbPort is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011807")
    void case_UTAPI_011807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011807",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011807", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011807", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011807", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011807", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011807", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011807", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011807", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011807")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.CONSTRAINT_VIOLATION_EXPECTED, "declared NotBlank contract of ConnectionSettingRequest.dbUsername classifies this input condition", "ConnectionSettingRequest", "dbUsername", "NotBlank", "data:request.dbUsername")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011808")
    void case_UTAPI_011808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011808",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011808", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011808", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011808", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011808", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011808", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011808", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011808", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011808")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011809")
    void case_UTAPI_011809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011809",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011809", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011809", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011809", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011809", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011809", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011809", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011809", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011809")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011810")
    void case_UTAPI_011810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011810",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011810", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011810", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011810", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011810", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011810", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011810", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011810", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011810")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011811")
    void case_UTAPI_011811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011811",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011811", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011811", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011811", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011811", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011811", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011811", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011811", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011811")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011812")
    void case_UTAPI_011812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011812",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011812", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011812", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011812", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011812", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011812", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011812", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011812", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011812")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011813")
    void case_UTAPI_011813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011813",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011813", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011813", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011813", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011813", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011813", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011813", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011813", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011813")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011814")
    void case_UTAPI_011814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011814",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011814", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011814", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011814", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011814", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011814", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011814", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011814", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011814")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011815")
    void case_UTAPI_011815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011815",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011815", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011815", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011815", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011815", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011815", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011815", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011815", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011815")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011816")
    void case_UTAPI_011816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011816",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011816", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011816", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011816", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011816", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011816", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011816", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011816", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011816")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011817")
    void case_UTAPI_011817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011817",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011817", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011817", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011817", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011817", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011817", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011817", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011817", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011817")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011818")
    void case_UTAPI_011818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011818",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011818", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011818", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011818", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011818", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011818", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011818", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011818", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011818")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011819")
    void case_UTAPI_011819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011819",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011819", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011819", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011819", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011819", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011819", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011819", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011819", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011819")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011820")
    void case_UTAPI_011820() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011820",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011820", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011820", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011820", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011820", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011820", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011820", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011820", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011820")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011821")
    void case_UTAPI_011821() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011821",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011821", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011821", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011821", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011821", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011821", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011821", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011821", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011821")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011822")
    void case_UTAPI_011822() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011822",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011822", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011822", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011822", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011822", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011822", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011822", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011822", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011822")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011823")
    void case_UTAPI_011823() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011823",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011823", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011823", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011823", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011823", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011823", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011823", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011823", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011823")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011824")
    void case_UTAPI_011824() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011824",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011824", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011824", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011824", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011824", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011824", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011824", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011824", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011824")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011825")
    void case_UTAPI_011825() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011825",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011825", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011825", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011825", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011825", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011825", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011825", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011825", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011825")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-011826")
    void case_UTAPI_011826() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-011826",
                "com.matsushita.dbeditor.usecase.connection.ConnectionUseCase",
                "create",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("request", "ConnectionSettingRequest", "request")
                },
                new DataRef[] {
                    new DataRef("UTAPI-011826", "request", "NORMAL", "OBJECT", "ConnectionSettingRequest"),
                    new DataRef("UTAPI-011826", "request.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011826", "request.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011826", "request.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011826", "request.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-011826", "request.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-011826", "request.dbUsername", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-011826")
                    .targetId("./java/com/matsushita/dbeditor/usecase/connection/ConnectionUseCase.java::ConnectionUseCase::create::3::FIELD::1::ConnectionSettingRequest::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("request.dbUsername", "ConnectionSettingRequest.dbUsername")
                    .validation("0", "1", "255", "@NotBlank")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.save")
                    .expected("the value generated for request.dbUsername is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.save", "connectionSettingRepository", "save")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbName of the object handed to connectionSettingRepository.save must carry request.dbName", "connectionSettingRepository", "save", "0", "getDbName", "data:request.dbName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbHost of the object handed to connectionSettingRepository.save must carry request.dbHost", "connectionSettingRepository", "save", "0", "getDbHost", "data:request.dbHost")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPort of the object handed to connectionSettingRepository.save must carry request.dbPort", "connectionSettingRepository", "save", "0", "getDbPort", "data:request.dbPort")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDatabaseName of the object handed to connectionSettingRepository.save must carry request.databaseName", "connectionSettingRepository", "save", "0", "getDatabaseName", "data:request.databaseName")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbUsername of the object handed to connectionSettingRepository.save must carry request.dbUsername", "connectionSettingRepository", "save", "0", "getDbUsername", "data:request.dbUsername")
                    .check(CheckType.ARG_FIELD_EQUALS, "getDbPassword of the object handed to connectionSettingRepository.save must carry request.dbPassword", "connectionSettingRepository", "save", "0", "getDbPassword", "data:request.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionUseCaseWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ConnectionSettingRepositoryWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ConnectionSettingRepository#update.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ConnectionSettingRepositoryUpdateScenario {

    @Test
    @DisplayName("UTAPI-006280")
    void case_UTAPI_006280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006280",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006280", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006280", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006280", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006280", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006280", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006280", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006280", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006280", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006280", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006280", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006280")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006281")
    void case_UTAPI_006281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006281",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006281", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006281", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006281", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006281", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006281", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006281", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006281", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006281", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006281", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006281", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006281")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006282")
    void case_UTAPI_006282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006282",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006282", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006282", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006282", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006282", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006282", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006282", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006282", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006282", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006282", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006282", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006282")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006283")
    void case_UTAPI_006283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006283",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006283", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006283", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006283", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006283", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006283", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006283", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006283", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006283", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006283", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006283", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006283")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006284")
    void case_UTAPI_006284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006284",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006284", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006284", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006284", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006284", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006284", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006284", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006284", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006284", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006284", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006284", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006284")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006285")
    void case_UTAPI_006285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006285",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006285", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006285", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006285", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006285", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006285", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006285", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006285", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006285", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006285", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006285", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006285")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006286")
    void case_UTAPI_006286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006286",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006286", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006286", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006286", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006286", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006286", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006286", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006286", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006286", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006286", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006286", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006286")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006287")
    void case_UTAPI_006287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006287",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006287", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006287", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006287", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006287", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006287", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006287", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006287", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006287", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006287", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006287", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006287")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.createdTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.INPUT_FIELD_UNCHANGED, "an update must not rewrite the creation time of the supplied record", "setting", "getCreatedTimestamp", "data:setting.createdTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006288")
    void case_UTAPI_006288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006288",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006288", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006288", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006288", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006288", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006288", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006288", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006288", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006288", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006288", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006288", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006288")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006289")
    void case_UTAPI_006289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006289",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006289", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006289", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006289", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006289", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006289", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006289", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006289", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006289", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006289", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006289", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006289")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006290")
    void case_UTAPI_006290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006290",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006290", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006290", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006290", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006290", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006290", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006290", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006290", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006290", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006290", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006290", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006290")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006291")
    void case_UTAPI_006291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006291",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006291", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006291", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006291", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006291", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006291", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006291", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006291", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006291", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006291", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006291", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006291")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006292")
    void case_UTAPI_006292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006292",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006292", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006292", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006292", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006292", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006292", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006292", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006292", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006292", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006292", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006292", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006292")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006293")
    void case_UTAPI_006293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006293",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006293", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006293", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006293", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006293", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006293", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006293", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006293", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006293", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006293", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006293", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006293")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006294")
    void case_UTAPI_006294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006294",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006294", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006294", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006294", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006294", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006294", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006294", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006294", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006294", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006294", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006294", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006294")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006295")
    void case_UTAPI_006295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006295",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006295", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006295", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006295", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006295", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006295", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006295", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006295", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006295", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006295", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006295", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006295")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006296")
    void case_UTAPI_006296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006296",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006296", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006296", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006296", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006296", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006296", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006296", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006296", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006296", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006296", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006296", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006296")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006297")
    void case_UTAPI_006297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006297",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006297", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006297", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006297", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006297", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006297", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006297", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006297", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006297", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006297", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006297", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006297")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006298")
    void case_UTAPI_006298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006298",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006298", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006298", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006298", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006298", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006298", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006298", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006298", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006298", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006298", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006298", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006298")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006299")
    void case_UTAPI_006299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006299",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006299", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006299", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006299", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006299", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006299", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006299", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006299", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006299", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006299", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006299", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006299")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006300")
    void case_UTAPI_006300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006300",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006300", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006300", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006300", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006300", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006300", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006300", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006300", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006300", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006300", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006300", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006300")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006301")
    void case_UTAPI_006301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006301",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006301", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006301", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006301", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006301", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006301", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006301", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006301", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006301", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006301", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006301", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006301")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006302")
    void case_UTAPI_006302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006302",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006302", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006302", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006302", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006302", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006302", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006302", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006302", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006302", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006302", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006302", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006302")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006303")
    void case_UTAPI_006303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006303",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006303", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006303", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006303", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006303", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006303", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006303", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006303", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006303", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006303", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006303", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006303")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006304")
    void case_UTAPI_006304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006304",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006304", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006304", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006304", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006304", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006304", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006304", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006304", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006304", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006304", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006304", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006304")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006305")
    void case_UTAPI_006305() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006305",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006305", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006305", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006305", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006305", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006305", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006305", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006305", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006305", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006305", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006305", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006305")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006306")
    void case_UTAPI_006306() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006306",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006306", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006306", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006306", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006306", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006306", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006306", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006306", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006306", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006306", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006306", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006306")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006307")
    void case_UTAPI_006307() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006307",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006307", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006307", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006307", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006307", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006307", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006307", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006307", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006307", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006307", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006307", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006307")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006308")
    void case_UTAPI_006308() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006308",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006308", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006308", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006308", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006308", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006308", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006308", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006308", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006308", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006308", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006308", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006308")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.databaseName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.databaseName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006309")
    void case_UTAPI_006309() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006309",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006309", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006309", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006309", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006309", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006309", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006309", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006309", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006309", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006309", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006309", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006309")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006310")
    void case_UTAPI_006310() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006310",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006310", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006310", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006310", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006310", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006310", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006310", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006310", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006310", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006310", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006310", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006310")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006311")
    void case_UTAPI_006311() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006311",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006311", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006311", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006311", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006311", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006311", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006311", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006311", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006311", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006311", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006311", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006311")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006312")
    void case_UTAPI_006312() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006312",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006312", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006312", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006312", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006312", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006312", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006312", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006312", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006312", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006312", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006312", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006312")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006313")
    void case_UTAPI_006313() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006313",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006313", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006313", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006313", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006313", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006313", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006313", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006313", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006313", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006313", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006313", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006313")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006314")
    void case_UTAPI_006314() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006314",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006314", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006314", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006314", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006314", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006314", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006314", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006314", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006314", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006314", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006314", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006314")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006315")
    void case_UTAPI_006315() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006315",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006315", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006315", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006315", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006315", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006315", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006315", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006315", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006315", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006315", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006315", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006315")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006316")
    void case_UTAPI_006316() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006316",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006316", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006316", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006316", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006316", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006316", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006316", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006316", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006316", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006316", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006316", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006316")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006317")
    void case_UTAPI_006317() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006317",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006317", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006317", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006317", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006317", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006317", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006317", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006317", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006317", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006317", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006317", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006317")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006318")
    void case_UTAPI_006318() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006318",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006318", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006318", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006318", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006318", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006318", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006318", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006318", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006318", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006318", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006318", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006318")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006319")
    void case_UTAPI_006319() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006319",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006319", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006319", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006319", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006319", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006319", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006319", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006319", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006319", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006319", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006319", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006319")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006320")
    void case_UTAPI_006320() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006320",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006320", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006320", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006320", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006320", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006320", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006320", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006320", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006320", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006320", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006320", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006320")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006321")
    void case_UTAPI_006321() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006321",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006321", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006321", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006321", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006321", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006321", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006321", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006321", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006321", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006321", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006321", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006321")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006322")
    void case_UTAPI_006322() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006322",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006322", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006322", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006322", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006322", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006322", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006322", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006322", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006322", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006322", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006322", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006322")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006323")
    void case_UTAPI_006323() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006323",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006323", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006323", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006323", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006323", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006323", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006323", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006323", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006323", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006323", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006323", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006323")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006324")
    void case_UTAPI_006324() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006324",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006324", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006324", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006324", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006324", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006324", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006324", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006324", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006324", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006324", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006324", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006324")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006325")
    void case_UTAPI_006325() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006325",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006325", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006325", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006325", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006325", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006325", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006325", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006325", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006325", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006325", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006325", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006325")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006326")
    void case_UTAPI_006326() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006326",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006326", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006326", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006326", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006326", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006326", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006326", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006326", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006326", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006326", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006326", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006326")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006327")
    void case_UTAPI_006327() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006327",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006327", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006327", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006327", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006327", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006327", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006327", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006327", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006327", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006327", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006327", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006327")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006328")
    void case_UTAPI_006328() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006328",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006328", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006328", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006328", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006328", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006328", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006328", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006328", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006328", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006328", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006328", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006328")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbHost is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbHost must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbHost")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006329")
    void case_UTAPI_006329() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006329",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006329", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006329", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006329", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006329", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006329", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006329", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006329", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006329", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006329", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006329", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006329")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006330")
    void case_UTAPI_006330() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006330",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006330", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006330", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006330", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006330", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006330", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006330", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006330", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006330", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006330", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006330", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006330")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006331")
    void case_UTAPI_006331() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006331",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006331", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006331", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006331", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006331", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006331", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006331", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006331", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006331", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006331", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006331", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006331")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006332")
    void case_UTAPI_006332() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006332",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006332", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006332", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006332", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006332", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006332", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006332", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006332", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006332", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006332", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006332", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006332")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006333")
    void case_UTAPI_006333() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006333",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006333", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006333", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006333", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006333", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006333", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006333", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006333", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006333", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006333", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006333", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006333")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006334")
    void case_UTAPI_006334() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006334",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006334", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006334", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006334", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006334", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006334", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006334", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006334", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006334", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006334", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006334", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006334")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006335")
    void case_UTAPI_006335() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006335",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006335", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006335", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006335", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006335", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006335", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006335", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006335", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006335", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006335", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006335", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006335")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006336")
    void case_UTAPI_006336() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006336",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006336", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006336", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006336", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006336", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006336", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006336", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006336", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006336", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006336", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006336", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006336")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006337")
    void case_UTAPI_006337() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006337",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006337", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006337", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006337", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006337", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006337", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006337", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006337", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006337", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006337", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006337", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006337")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006338")
    void case_UTAPI_006338() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006338",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006338", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006338", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006338", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006338", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006338", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006338", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006338", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006338", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006338", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006338", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006338")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006339")
    void case_UTAPI_006339() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006339",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006339", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006339", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006339", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006339", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006339", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006339", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006339", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006339", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006339", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006339", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006339")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006340")
    void case_UTAPI_006340() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006340",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006340", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006340", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006340", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006340", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006340", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006340", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006340", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006340", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006340", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006340", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006340")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006341")
    void case_UTAPI_006341() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006341",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006341", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006341", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006341", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006341", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006341", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006341", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006341", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006341", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006341", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006341", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006341")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006342")
    void case_UTAPI_006342() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006342",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006342", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006342", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006342", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006342", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006342", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006342", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006342", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006342", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006342", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006342", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006342")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006343")
    void case_UTAPI_006343() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006343",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006343", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006343", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006343", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006343", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006343", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006343", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006343", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006343", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006343", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006343", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006343")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006344")
    void case_UTAPI_006344() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006344",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006344", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006344", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006344", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006344", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006344", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006344", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006344", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006344", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006344", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006344", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006344")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006345")
    void case_UTAPI_006345() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006345",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006345", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006345", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006345", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006345", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006345", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006345", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006345", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006345", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006345", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006345", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006345")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006346")
    void case_UTAPI_006346() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006346",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006346", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006346", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006346", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006346", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006346", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006346", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006346", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006346", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006346", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006346", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006346")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006347")
    void case_UTAPI_006347() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006347",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006347", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006347", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006347", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006347", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006347", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006347", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006347", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006347", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006347", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006347", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006347")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006348")
    void case_UTAPI_006348() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006348",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006348", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006348", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006348", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006348", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006348", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006348", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006348", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006348", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006348", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006348", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006348")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006349")
    void case_UTAPI_006349() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006349",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006349", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006349", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006349", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006349", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006349", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006349", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006349", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006349", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006349", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006349", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006349")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbName is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbName must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbName")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006350")
    void case_UTAPI_006350() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006350",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006350", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006350", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006350", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006350", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006350", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006350", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006350", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006350", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006350", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006350", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006350")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006351")
    void case_UTAPI_006351() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006351",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006351", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006351", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006351", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006351", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006351", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006351", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006351", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006351", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006351", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006351", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006351")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006352")
    void case_UTAPI_006352() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006352",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006352", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006352", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006352", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006352", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006352", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006352", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006352", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006352", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006352", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006352", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006352")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006353")
    void case_UTAPI_006353() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006353",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006353", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006353", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006353", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006353", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006353", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006353", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006353", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006353", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006353", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006353", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006353")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006354")
    void case_UTAPI_006354() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006354",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006354", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006354", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006354", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006354", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006354", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006354", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006354", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006354", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006354", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006354", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006354")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006355")
    void case_UTAPI_006355() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006355",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006355", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006355", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006355", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006355", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006355", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006355", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006355", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006355", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006355", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006355", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006355")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006356")
    void case_UTAPI_006356() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006356",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006356", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006356", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006356", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006356", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006356", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006356", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006356", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006356", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006356", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006356", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006356")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006357")
    void case_UTAPI_006357() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006357",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006357", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006357", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006357", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006357", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006357", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006357", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006357", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006357", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006357", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006357", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006357")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006358")
    void case_UTAPI_006358() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006358",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006358", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006358", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006358", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006358", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006358", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006358", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006358", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006358", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006358", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006358", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006358")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006359")
    void case_UTAPI_006359() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006359",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006359", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006359", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006359", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006359", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006359", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006359", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006359", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006359", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006359", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006359", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006359")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006360")
    void case_UTAPI_006360() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006360",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006360", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006360", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006360", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006360", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006360", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006360", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006360", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006360", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006360", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006360", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006360")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006361")
    void case_UTAPI_006361() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006361",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006361", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006361", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006361", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006361", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006361", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006361", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006361", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006361", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006361", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006361", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006361")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006362")
    void case_UTAPI_006362() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006362",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006362", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006362", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006362", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006362", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006362", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006362", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006362", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006362", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006362", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006362", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006362")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006363")
    void case_UTAPI_006363() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006363",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006363", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006363", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006363", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006363", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006363", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006363", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006363", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006363", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006363", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006363", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006363")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006364")
    void case_UTAPI_006364() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006364",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006364", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006364", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006364", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006364", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006364", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006364", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006364", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006364", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006364", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006364", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006364")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006365")
    void case_UTAPI_006365() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006365",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006365", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006365", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006365", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006365", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006365", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006365", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006365", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006365", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006365", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006365", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006365")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006366")
    void case_UTAPI_006366() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006366",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006366", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006366", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006366", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006366", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006366", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006366", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006366", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006366", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006366", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006366", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006366")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006367")
    void case_UTAPI_006367() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006367",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006367", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006367", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006367", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006367", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006367", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006367", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006367", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006367", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006367", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006367", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006367")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006368")
    void case_UTAPI_006368() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006368",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006368", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006368", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006368", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006368", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006368", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006368", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006368", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006368", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006368", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006368", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006368")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006369")
    void case_UTAPI_006369() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006369",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006369", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006369", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006369", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006369", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006369", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006369", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006369", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006369", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006369", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006369", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006369")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPassword is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPassword must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPassword")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006370")
    void case_UTAPI_006370() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006370",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006370", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006370", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006370", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006370", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006370", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006370", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006370", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006370", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006370", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006370", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006370")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006371")
    void case_UTAPI_006371() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006371",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006371", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006371", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006371", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006371", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006371", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006371", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006371", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006371", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006371", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006371", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006371")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006372")
    void case_UTAPI_006372() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006372",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006372", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006372", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006372", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006372", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006372", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006372", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006372", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006372", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006372", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006372", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006372")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006373")
    void case_UTAPI_006373() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006373",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006373", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006373", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006373", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006373", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006373", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006373", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006373", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006373", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006373", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006373", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006373")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006374")
    void case_UTAPI_006374() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006374",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006374", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006374", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006374", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006374", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006374", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006374", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006374", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006374", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006374", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006374", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006374")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006375")
    void case_UTAPI_006375() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006375",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006375", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006375", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006375", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006375", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006375", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006375", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006375", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006375", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006375", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006375", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006375")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006376")
    void case_UTAPI_006376() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006376",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006376", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006376", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006376", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006376", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006376", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006376", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006376", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006376", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006376", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006376", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006376")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006377")
    void case_UTAPI_006377() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006377",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006377", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006377", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006377", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006377", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006377", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006377", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006377", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006377", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006377", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006377", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006377")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006378")
    void case_UTAPI_006378() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006378",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006378", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006378", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006378", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006378", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006378", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006378", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006378", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006378", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006378", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006378", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006378")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006379")
    void case_UTAPI_006379() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006379",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006379", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006379", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006379", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006379", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006379", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006379", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006379", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006379", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006379", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006379", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006379")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006380")
    void case_UTAPI_006380() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006380",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006380", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006380", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006380", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006380", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006380", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006380", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006380", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006380", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006380", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006380", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006380")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbPort is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbPort must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbPort")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006381")
    void case_UTAPI_006381() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006381",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006381", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006381", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006381", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006381", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006381", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006381", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006381", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006381", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006381", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006381", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006381")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006382")
    void case_UTAPI_006382() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006382",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006382", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006382", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006382", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006382", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006382", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006382", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006382", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006382", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006382", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006382", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006382")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006383")
    void case_UTAPI_006383() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006383",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006383", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006383", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006383", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006383", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006383", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006383", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006383", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006383", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006383", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006383", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006383")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006384")
    void case_UTAPI_006384() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006384",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006384", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006384", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006384", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006384", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006384", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006384", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006384", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006384", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006384", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006384", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006384")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006385")
    void case_UTAPI_006385() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006385",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006385", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006385", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006385", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006385", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006385", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006385", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006385", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006385", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006385", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006385", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006385")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006386")
    void case_UTAPI_006386() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006386",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006386", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006386", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006386", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006386", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006386", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006386", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006386", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006386", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006386", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006386", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006386")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006387")
    void case_UTAPI_006387() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006387",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006387", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006387", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006387", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006387", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006387", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006387", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006387", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006387", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006387", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006387", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006387")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006388")
    void case_UTAPI_006388() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006388",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006388", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006388", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006388", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006388", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006388", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006388", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006388", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006388", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006388", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006388", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006388")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006389")
    void case_UTAPI_006389() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006389",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006389", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006389", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006389", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006389", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006389", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006389", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006389", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006389", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006389", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006389", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006389")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006390")
    void case_UTAPI_006390() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006390",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006390", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006390", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006390", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006390", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006390", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006390", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006390", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006390", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006390", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006390", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006390")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006391")
    void case_UTAPI_006391() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006391",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006391", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006391", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006391", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006391", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006391", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006391", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006391", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006391", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006391", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006391", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006391")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006392")
    void case_UTAPI_006392() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006392",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006392", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006392", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006392", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006392", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006392", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006392", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006392", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006392", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006392", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006392", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006392")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006393")
    void case_UTAPI_006393() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006393",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006393", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006393", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006393", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006393", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006393", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006393", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006393", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006393", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006393", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006393", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006393")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006394")
    void case_UTAPI_006394() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006394",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006394", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006394", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006394", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006394", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006394", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006394", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006394", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006394", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006394", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006394", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006394")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006395")
    void case_UTAPI_006395() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006395",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006395", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006395", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006395", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006395", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006395", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006395", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006395", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006395", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006395", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006395", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006395")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006396")
    void case_UTAPI_006396() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006396",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006396", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006396", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006396", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006396", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006396", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006396", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006396", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006396", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006396", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006396", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006396")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006397")
    void case_UTAPI_006397() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006397",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006397", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006397", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006397", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006397", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006397", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006397", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006397", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006397", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006397", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006397", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006397")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006398")
    void case_UTAPI_006398() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006398",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006398", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006398", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006398", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006398", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006398", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006398", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006398", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006398", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006398", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006398", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006398")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006399")
    void case_UTAPI_006399() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006399",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006399", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006399", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006399", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006399", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006399", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006399", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006399", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006399", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006399", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006399", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006399")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006400")
    void case_UTAPI_006400() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006400",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006400", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006400", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006400", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006400", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006400", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006400", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006400", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006400", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006400", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006400", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006400")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006401")
    void case_UTAPI_006401() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006401",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006401", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006401", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006401", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006401", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006401", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006401", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006401", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006401", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-006401", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006401", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006401")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.dbUsername is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the value generated for setting.dbUsername must reach the executed statement unchanged", "jdbcTemplate", "", "data:setting.dbUsername")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006402")
    void case_UTAPI_006402() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006402",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006402", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006402", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006402", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006402", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006402", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006402", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006402", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006402", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006402", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006402", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006402")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006403")
    void case_UTAPI_006403() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006403",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006403", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006403", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006403", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006403", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006403", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006403", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006403", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006403", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006403", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006403", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006403")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006404")
    void case_UTAPI_006404() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006404",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006404", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006404", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006404", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006404", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006404", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006404", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006404", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006404", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006404", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006404", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006404")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006405")
    void case_UTAPI_006405() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006405",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006405", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006405", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006405", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006405", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006405", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006405", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006405", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006405", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006405", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006405", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006405")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006406")
    void case_UTAPI_006406() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006406",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006406", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006406", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006406", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006406", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006406", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006406", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006406", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006406", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006406", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006406", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006406")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006407")
    void case_UTAPI_006407() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006407",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006407", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006407", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006407", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006407", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006407", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006407", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006407", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006407", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006407", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006407", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006407")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006408")
    void case_UTAPI_006408() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006408",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006408", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006408", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006408", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006408", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006408", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006408", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006408", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006408", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006408", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006408", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006408")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006409")
    void case_UTAPI_006409() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006409",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006409", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006409", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006409", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006409", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006409", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006409", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006409", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006409", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006409", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006409", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006409")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006410")
    void case_UTAPI_006410() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006410",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006410", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006410", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006410", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006410", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006410", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006410", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006410", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006410", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006410", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006410", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006410")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006411")
    void case_UTAPI_006411() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006411",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006411", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006411", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006411", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006411", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006411", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006411", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006411", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006411", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006411", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006411", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006411")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006412")
    void case_UTAPI_006412() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006412",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006412", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006412", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006412", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006412", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006412", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006412", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006412", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006412", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006412", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006412", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006412")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.VALUE_REACHED, "the record key must be used by the statement", "jdbcTemplate", "", "data:setting.n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006413")
    void case_UTAPI_006413() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006413",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006413", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006413", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006413", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006413", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006413", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006413", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006413", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006413", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006413", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006413", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006413")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006414")
    void case_UTAPI_006414() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006414",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006414", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006414", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006414", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006414", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006414", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006414", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006414", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006414", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006414", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006414", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006414")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006415")
    void case_UTAPI_006415() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006415",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006415", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006415", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006415", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006415", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006415", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006415", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006415", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006415", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006415", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006415", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006415")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006416")
    void case_UTAPI_006416() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006416",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006416", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006416", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006416", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006416", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006416", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006416", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006416", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006416", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006416", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006416", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006416")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006417")
    void case_UTAPI_006417() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006417",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006417", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006417", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006417", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006417", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006417", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006417", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006417", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006417", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006417", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006417", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006417")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006418")
    void case_UTAPI_006418() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006418",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006418", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006418", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006418", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006418", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006418", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006418", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006418", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006418", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006418", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006418", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006418")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006419")
    void case_UTAPI_006419() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006419",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006419", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006419", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006419", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006419", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006419", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006419", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006419", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006419", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006419", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006419", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006419")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

    @Test
    @DisplayName("UTAPI-006420")
    void case_UTAPI_006420() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-006420",
                "com.matsushita.dbeditor.domain.repository.ConnectionSettingRepository",
                "update",
                "ConnectionSetting",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting")
                },
                new DataRef[] {
                    new DataRef("UTAPI-006420", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-006420", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-006420", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006420", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006420", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006420", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006420", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006420", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-006420", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-006420", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime")
                },
                OraclePlan.builder("UTAPI-006420")
                    .targetId("./java/com/matsushita/dbeditor/domain/repository/ConnectionSettingRepository.java::ConnectionSettingRepository::update::4::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for setting.updatedTimestamp is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the record content must be persisted by the statement", "jdbcTemplate", "", "data:setting.databaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record returned must carry its content", "getDatabaseName")
                    .check(CheckType.RETURN_FIELD_NOT_NULL, "the persisted record must carry its audit timestamp", "getUpdatedTimestamp")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ConnectionSettingRepositoryWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableNameValidatorWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableNameValidator#historyTableName.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableNameValidatorHistoryTableNameScenario {

    @Test
    @DisplayName("UTAPI-010788")
    void case_UTAPI_010788() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010788",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010788", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010788", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010788")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010789")
    void case_UTAPI_010789() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010789",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010789", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010789", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010789")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010790")
    void case_UTAPI_010790() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010790",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010790", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010790", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010790")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010791")
    void case_UTAPI_010791() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010791",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010791", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010791", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010791")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010792")
    void case_UTAPI_010792() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010792",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010792", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010792", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010792")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010793")
    void case_UTAPI_010793() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010793",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010793", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010793", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010793")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010794")
    void case_UTAPI_010794() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010794",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010794", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010794", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010794")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010795")
    void case_UTAPI_010795() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010795",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010795", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010795", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010795")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010796")
    void case_UTAPI_010796() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010796",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010796", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010796", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010796")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010797")
    void case_UTAPI_010797() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010797",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010797", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010797", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010797")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010798")
    void case_UTAPI_010798() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010798",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010798", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010798", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010798")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010799")
    void case_UTAPI_010799() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010799",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010799", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010799", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010799")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010800")
    void case_UTAPI_010800() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010800",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010800", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010800", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010800")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010801")
    void case_UTAPI_010801() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010801",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010801", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010801", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010801")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010802")
    void case_UTAPI_010802() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010802",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010802", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010802", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010802")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010803")
    void case_UTAPI_010803() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010803",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010803", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010803", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010803")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010804")
    void case_UTAPI_010804() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010804",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010804", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010804", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010804")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010805")
    void case_UTAPI_010805() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010805",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010805", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010805", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010805")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010806")
    void case_UTAPI_010806() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010806",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010806", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010806", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010806")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010807")
    void case_UTAPI_010807() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010807",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010807", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010807", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010807")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010808")
    void case_UTAPI_010808() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010808",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010808", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010808", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010808")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::1::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName, or the rejection it raises")
                    .expected("the supplied identifier parts appear in the composed identifier, or the invalid identifier is rejected as an invalid argument")
                    .failure("a supplied part is dropped from the composed identifier, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that does not match the declared pattern must be rejected as an invalid argument", "java.lang.IllegalArgumentException", "")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010809")
    void case_UTAPI_010809() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010809",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010809", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010809", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010809")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "1:length_null", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010810")
    void case_UTAPI_010810() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010810",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010810", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010810", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010810")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "2:length_empty", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010811")
    void case_UTAPI_010811() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010811",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010811", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010811", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010811")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "3:length_min", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010812")
    void case_UTAPI_010812() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010812",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010812", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010812", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010812")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010813")
    void case_UTAPI_010813() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010813",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010813", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010813", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010813")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "5:length_max", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010814")
    void case_UTAPI_010814() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010814",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010814", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010814", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010814")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010815")
    void case_UTAPI_010815() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010815",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010815", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010815", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010815")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010816")
    void case_UTAPI_010816() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010816",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010816", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010816", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010816")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("46:hw_integer", "-", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010817")
    void case_UTAPI_010817() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010817",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010817", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010817", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010817")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "-", "12:integer_positive")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010818")
    void case_UTAPI_010818() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010818",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010818", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010818", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010818")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "-", "13:integer_negative")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

    @Test
    @DisplayName("UTAPI-010819")
    void case_UTAPI_010819() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010819",
                "com.matsushita.dbeditor.infrastructure.database.TableNameValidator",
                "historyTableName",
                "String",
                new ParamSpec[] {
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010819", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010819", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-010819")
                    .targetId("./java/com/matsushita/dbeditor/infrastructure/database/TableNameValidator.java::TableNameValidator::historyTableName::7::ARG::2::-::seq")
                    .mirror("-", "-", "14:integer_zero")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.IDENTIFIER_COMPOSITION)
                    .observation("the identifier string returned by historyTableName")
                    .expected("a valid identifier condition must be accepted and every supplied part must appear in the composed identifier")
                    .failure("a valid identifier is rejected, a supplied part is dropped, or a derived name equals the source table name")
                    .assertion("assertTrue(result.contains(part)) per part, assertNotEquals for derived names")
                    .check(CheckType.NO_EXCEPTION, "an identifier that matches the declared pattern must be accepted, not rejected")
                    .check(CheckType.RETURN_NOT_NULL, "an accepted composition must produce an identifier")
                    .check(CheckType.RETURN_CONTAINS_VALUE, "the composed identifier must contain tableName", "data:tableName")
                    .check(CheckType.RETURN_DIFFERS_FROM_VALUE, "a derived table name must not collide with the supplied table name", "data:tableName")
                    .check(CheckType.SENSITIVE_TO_ARG, "the composed identifier must depend on the sequence number", "1", "data:seq")
                    .build()),
            new TableNameValidatorWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableHistoryUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableHistoryUseCase#getHistoryRecords.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableHistoryUseCaseGetHistoryRecordsScenario {

    @Test
    @DisplayName("UTAPI-013081")
    void case_UTAPI_013081() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013081",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013081", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013081", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013081", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013081", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013081")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013082")
    void case_UTAPI_013082() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013082",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013082", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013082", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013082", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013082", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013082")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013083")
    void case_UTAPI_013083() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013083",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013083", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013083", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013083", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013083", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013083")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013084")
    void case_UTAPI_013084() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013084",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013084", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013084", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013084", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013084", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013084")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013085")
    void case_UTAPI_013085() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013085",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013085", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013085", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013085", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013085", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013085")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013086")
    void case_UTAPI_013086() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013086",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013086", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013086", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013086", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013086", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013086")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013087")
    void case_UTAPI_013087() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013087",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013087", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013087", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013087", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013087", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013087")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013088")
    void case_UTAPI_013088() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013088",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013088", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013088", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013088", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013088", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013088")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013089")
    void case_UTAPI_013089() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013089",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013089", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013089", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013089", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013089", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013089")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013090")
    void case_UTAPI_013090() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013090",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013090", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013090", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013090", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013090", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013090")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013091")
    void case_UTAPI_013091() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013091",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013091", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013091", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013091", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013091", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013091")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::1::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013092")
    void case_UTAPI_013092() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013092",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013092", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013092", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013092", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013092", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013092")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013093")
    void case_UTAPI_013093() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013093",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013093", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013093", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013093", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013093", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013093")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013094")
    void case_UTAPI_013094() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013094",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013094", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013094", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013094", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013094", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013094")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013095")
    void case_UTAPI_013095() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013095",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013095", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013095", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013095", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013095", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013095")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013096")
    void case_UTAPI_013096() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013096",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013096", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013096", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013096", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013096", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013096")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013097")
    void case_UTAPI_013097() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013097",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013097", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013097", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013097", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013097", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013097")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013098")
    void case_UTAPI_013098() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013098",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013098", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013098", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013098", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013098", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013098")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013099")
    void case_UTAPI_013099() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013099",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013099", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013099", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013099", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013099", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013099")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013100")
    void case_UTAPI_013100() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013100",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013100", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013100", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013100", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013100", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013100")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013101")
    void case_UTAPI_013101() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013101",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013101", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013101", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013101", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013101", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013101")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013102")
    void case_UTAPI_013102() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013102",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013102", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013102", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013102", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013102", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013102")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013103")
    void case_UTAPI_013103() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013103",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013103", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013103", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013103", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013103", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013103")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013104")
    void case_UTAPI_013104() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013104",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013104", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013104", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013104", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013104", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013104")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013105")
    void case_UTAPI_013105() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013105",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013105", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013105", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013105", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013105", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013105")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013106")
    void case_UTAPI_013106() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013106",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013106", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013106", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013106", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013106", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013106")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013107")
    void case_UTAPI_013107() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013107",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013107", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013107", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013107", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013107", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013107")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013108")
    void case_UTAPI_013108() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013108",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013108", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013108", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013108", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013108", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013108")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013109")
    void case_UTAPI_013109() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013109",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013109", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013109", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013109", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013109", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013109")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013110")
    void case_UTAPI_013110() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013110",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013110", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013110", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013110", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013110", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013110")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013111")
    void case_UTAPI_013111() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013111",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013111", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013111", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013111", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013111", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013111")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013112")
    void case_UTAPI_013112() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013112",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013112", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013112", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013112", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013112", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013112")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013113")
    void case_UTAPI_013113() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013113",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013113", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013113", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013113", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013113", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013113")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013114")
    void case_UTAPI_013114() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013114",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013114", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013114", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013114", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013114", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013114")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013115")
    void case_UTAPI_013115() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013115",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013115", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013115", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013115", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013115", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013115")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013116")
    void case_UTAPI_013116() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013116",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013116", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013116", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013116", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013116", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013116")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013117")
    void case_UTAPI_013117() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013117",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013117", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013117", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013117", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013117", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013117")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013118")
    void case_UTAPI_013118() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013118",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013118", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013118", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013118", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013118", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013118")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013119")
    void case_UTAPI_013119() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013119",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013119", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013119", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013119", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013119", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013119")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013120")
    void case_UTAPI_013120() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013120",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013120", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013120", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013120", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013120", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013120")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013121")
    void case_UTAPI_013121() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013121",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013121", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013121", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013121", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013121", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013121")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013122")
    void case_UTAPI_013122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013122",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013122", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013122", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013122", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013122", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013122")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013123")
    void case_UTAPI_013123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013123",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013123", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013123", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013123", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013123", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013123")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013124")
    void case_UTAPI_013124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013124",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013124", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013124", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013124", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013124", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013124")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013125")
    void case_UTAPI_013125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013125",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013125", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013125", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013125", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013125", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013125")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013126")
    void case_UTAPI_013126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013126",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013126", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013126", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013126", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013126", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013126")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013127")
    void case_UTAPI_013127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013127",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013127", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013127", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013127", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013127", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013127")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013128")
    void case_UTAPI_013128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013128",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013128", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013128", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013128", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013128", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013128")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013129")
    void case_UTAPI_013129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013129",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013129", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013129", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013129", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013129", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013129")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013130")
    void case_UTAPI_013130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013130",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013130", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013130", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013130", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013130", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013130")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013131")
    void case_UTAPI_013131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013131",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013131", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013131", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013131", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013131", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013131")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013132")
    void case_UTAPI_013132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013132",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013132", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013132", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013132", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013132", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013132")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013133")
    void case_UTAPI_013133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013133",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013133", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013133", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013133", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-013133", "seq", "NORMAL", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013133")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013134")
    void case_UTAPI_013134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013134",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013134", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013134", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013134", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013134", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013134")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "1:length_null", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013135")
    void case_UTAPI_013135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013135",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013135", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013135", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013135", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013135", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013135")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "2:length_empty", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013136")
    void case_UTAPI_013136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013136",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013136", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013136", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013136", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013136", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013136")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "3:length_min", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013137")
    void case_UTAPI_013137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013137",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013137", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013137", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013137", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013137", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013137")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013138")
    void case_UTAPI_013138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013138",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013138", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013138", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013138", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013138", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013138")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "5:length_max", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013139")
    void case_UTAPI_013139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013139",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013139", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013139", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013139", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013139", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013139")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013140")
    void case_UTAPI_013140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013140",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013140", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013140", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013140", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013140", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013140")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013141")
    void case_UTAPI_013141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013141",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013141", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013141", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013141", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013141", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013141")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("46:hw_integer", "-", "-")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013142")
    void case_UTAPI_013142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013142",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013142", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013142", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013142", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013142", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013142")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "-", "12:integer_positive")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013143")
    void case_UTAPI_013143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013143",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013143", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013143", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013143", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013143", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013143")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "-", "13:integer_negative")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-013144")
    void case_UTAPI_013144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-013144",
                "com.matsushita.dbeditor.usecase.table.TableHistoryUseCase",
                "getHistoryRecords",
                "List<Map<String,Object>>",
                new ParamSpec[] {
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("seq", "int", "seq")
                },
                new DataRef[] {
                    new DataRef("UTAPI-013144", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-013144", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013144", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-013144", "seq", "TARGET", "NUMBER", "int")
                },
                OraclePlan.builder("UTAPI-013144")
                    .targetId("./java/com/matsushita/dbeditor/usecase/table/TableHistoryUseCase.java::TableHistoryUseCase::getHistoryRecords::3::ARG::4::-::seq")
                    .mirror("-", "-", "14:integer_zero")
                    .target("seq", "seq")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of connectionSettingRepository.findById; invocation of tableHistoryRepository.findHistoryRecords")
                    .expected("the value generated for seq is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through connectionSettingRepository.findById", "connectionSettingRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of connectionSettingRepository.findById must carry the value generated for connectionId", "connectionSettingRepository", "findById", "0", "data:connectionId")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.ARG_EQUALS, "argument 1 of tableHistoryRepository.findHistoryRecords must carry the value generated for schemaName", "tableHistoryRepository", "findHistoryRecords", "1", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of tableHistoryRepository.findHistoryRecords must carry the value generated for tableName", "tableHistoryRepository", "findHistoryRecords", "2", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of tableHistoryRepository.findHistoryRecords must carry the value generated for seq", "tableHistoryRepository", "findHistoryRecords", "3", "data:seq")
                    .check(CheckType.RETURN_SAME_AS_STUB, "the result must be the value obtained from tableHistoryRepository.findHistoryRecords", "tableHistoryRepository", "findHistoryRecords")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableHistoryUseCaseWrapper());
    }

}

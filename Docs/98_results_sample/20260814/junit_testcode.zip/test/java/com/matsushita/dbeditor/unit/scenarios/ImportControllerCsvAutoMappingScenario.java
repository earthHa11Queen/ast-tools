package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.ImportControllerWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for ImportController#csvAutoMapping.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class ImportControllerCsvAutoMappingScenario {

    @Test
    @DisplayName("UTAPI-000681")
    void case_UTAPI_000681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000681",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000681", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000681", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000681", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000681", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000681")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::1::-::file")
                    .mirror("-", "1:length_null", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.EXCEPTION_REQUIRED, "an absent upload cannot be processed", "java.lang.RuntimeException", "data:file")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000682")
    void case_UTAPI_000682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000682",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000682", "file", "TARGET", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000682", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000682", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000682", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000682")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::1::-::file")
                    .mirror("-", "2:length_empty", "-")
                    .target("file", "file")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for file is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .check(CheckType.ARG_SAME, "the uploaded document must be handed on as it was received", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000683")
    void case_UTAPI_000683() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000683",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000683", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000683", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000683", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000683", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000683")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "1:length_null", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000684")
    void case_UTAPI_000684() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000684",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000684", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000684", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000684", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000684", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000684")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "2:length_empty", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000685")
    void case_UTAPI_000685() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000685",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000685", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000685", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000685", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000685", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000685")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "3:length_min", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000686")
    void case_UTAPI_000686() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000686",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000686", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000686", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000686", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000686", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000686")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000687")
    void case_UTAPI_000687() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000687",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000687", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000687", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000687", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000687", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000687")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "5:length_max", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000688")
    void case_UTAPI_000688() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000688",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000688", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000688", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000688", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000688", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000688")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000689")
    void case_UTAPI_000689() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000689",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000689", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000689", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000689", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000689", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000689")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000690")
    void case_UTAPI_000690() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000690",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000690", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000690", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000690", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000690", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000690")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("46:hw_integer", "-", "-")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000691")
    void case_UTAPI_000691() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000691",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000691", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000691", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000691", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000691", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000691")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "-", "12:integer_positive")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000692")
    void case_UTAPI_000692() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000692",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000692", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000692", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000692", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000692", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000692")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "-", "13:integer_negative")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000693")
    void case_UTAPI_000693() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000693",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000693", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000693", "connectionId", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000693", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000693", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000693")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::2::-::connectionId")
                    .mirror("-", "-", "14:integer_zero")
                    .target("connectionId", "connectionId")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for connectionId is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000694")
    void case_UTAPI_000694() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000694",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000694", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000694", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000694", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000694", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000694")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000695")
    void case_UTAPI_000695() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000695",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000695", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000695", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000695", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000695", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000695")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000696")
    void case_UTAPI_000696() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000696",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000696", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000696", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000696", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000696", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000696")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000697")
    void case_UTAPI_000697() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000697",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000697", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000697", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000697", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000697", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000697")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000698")
    void case_UTAPI_000698() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000698",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000698", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000698", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000698", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000698", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000698")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000699")
    void case_UTAPI_000699() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000699",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000699", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000699", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000699", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000699", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000699")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000700")
    void case_UTAPI_000700() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000700",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000700", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000700", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000700", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000700", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000700")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000701")
    void case_UTAPI_000701() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000701",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000701", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000701", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000701", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000701", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000701")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000702")
    void case_UTAPI_000702() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000702",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000702", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000702", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000702", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000702", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000702")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000703")
    void case_UTAPI_000703() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000703",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000703", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000703", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000703", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000703", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000703")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000704")
    void case_UTAPI_000704() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000704",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000704", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000704", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000704", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000704", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000704")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000705")
    void case_UTAPI_000705() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000705",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000705", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000705", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000705", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000705", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000705")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000706")
    void case_UTAPI_000706() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000706",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000706", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000706", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000706", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000706", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000706")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000707")
    void case_UTAPI_000707() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000707",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000707", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000707", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000707", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000707", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000707")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000708")
    void case_UTAPI_000708() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000708",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000708", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000708", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000708", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000708", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000708")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000709")
    void case_UTAPI_000709() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000709",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000709", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000709", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000709", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000709", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000709")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000710")
    void case_UTAPI_000710() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000710",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000710", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000710", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000710", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000710", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000710")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000711")
    void case_UTAPI_000711() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000711",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000711", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000711", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000711", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000711", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000711")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000712")
    void case_UTAPI_000712() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000712",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000712", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000712", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000712", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000712", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000712")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000713")
    void case_UTAPI_000713() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000713",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000713", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000713", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000713", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000713", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000713")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000714")
    void case_UTAPI_000714() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000714",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000714", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000714", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000714", "tableName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-000714", "schemaName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000714")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for tableName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000715")
    void case_UTAPI_000715() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000715",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000715", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000715", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000715", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000715", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000715")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000716")
    void case_UTAPI_000716() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000716",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000716", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000716", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000716", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000716", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000716")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000717")
    void case_UTAPI_000717() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000717",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000717", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000717", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000717", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000717", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000717")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000718")
    void case_UTAPI_000718() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000718",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000718", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000718", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000718", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000718", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000718")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000719")
    void case_UTAPI_000719() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000719",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000719", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000719", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000719", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000719", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000719")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000720")
    void case_UTAPI_000720() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000720",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000720", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000720", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000720", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000720", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000720")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000721")
    void case_UTAPI_000721() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000721",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000721", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000721", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000721", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000721", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000721")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000722")
    void case_UTAPI_000722() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000722",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000722", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000722", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000722", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000722", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000722")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000723")
    void case_UTAPI_000723() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000723",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000723", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000723", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000723", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000723", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000723")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000724")
    void case_UTAPI_000724() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000724",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000724", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000724", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000724", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000724", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000724")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000725")
    void case_UTAPI_000725() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000725",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000725", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000725", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000725", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000725", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000725")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000726")
    void case_UTAPI_000726() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000726",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000726", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000726", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000726", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000726", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000726")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000727")
    void case_UTAPI_000727() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000727",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000727", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000727", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000727", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000727", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000727")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000728")
    void case_UTAPI_000728() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000728",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000728", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000728", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000728", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000728", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000728")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000729")
    void case_UTAPI_000729() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000729",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000729", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000729", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000729", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000729", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000729")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000730")
    void case_UTAPI_000730() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000730",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000730", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000730", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000730", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000730", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000730")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000731")
    void case_UTAPI_000731() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000731",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000731", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000731", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000731", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000731", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000731")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000732")
    void case_UTAPI_000732() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000732",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000732", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000732", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000732", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000732", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000732")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000733")
    void case_UTAPI_000733() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000733",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000733", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000733", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000733", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000733", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000733")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000734")
    void case_UTAPI_000734() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000734",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000734", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000734", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000734", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000734", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000734")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

    @Test
    @DisplayName("UTAPI-000735")
    void case_UTAPI_000735() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-000735",
                "com.matsushita.dbeditor.adapter.controller.ImportController",
                "csvAutoMapping",
                "ResponseEntity<AutoMappingResponse>",
                new ParamSpec[] {
                    new ParamSpec("file", "MultipartFile", "file"),
                    new ParamSpec("connectionId", "Integer", "connectionId"),
                    new ParamSpec("tableName", "String", "tableName"),
                    new ParamSpec("schemaName", "String", "schemaName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-000735", "file", "NORMAL", "OBJECT", "MultipartFile"),
                    new DataRef("UTAPI-000735", "connectionId", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-000735", "tableName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-000735", "schemaName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-000735")
                    .targetId("./java/com/matsushita/dbeditor/adapter/controller/ImportController.java::ImportController::csvAutoMapping::1::ARG::4::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of importUseCase.csvAutoMapping")
                    .expected("the value generated for schemaName is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through importUseCase.csvAutoMapping", "importUseCase", "csvAutoMapping")
                    .check(CheckType.ARG_EQUALS, "argument 0 of importUseCase.csvAutoMapping must carry the value generated for connectionId", "importUseCase", "csvAutoMapping", "0", "data:connectionId")
                    .check(CheckType.ARG_EQUALS, "argument 1 of importUseCase.csvAutoMapping must carry the value generated for tableName", "importUseCase", "csvAutoMapping", "1", "data:tableName")
                    .check(CheckType.ARG_EQUALS, "argument 2 of importUseCase.csvAutoMapping must carry the value generated for schemaName", "importUseCase", "csvAutoMapping", "2", "data:schemaName")
                    .check(CheckType.ARG_EQUALS, "argument 3 of importUseCase.csvAutoMapping must carry the value generated for file", "importUseCase", "csvAutoMapping", "3", "data:file")
                    .check(CheckType.RETURN_STATUS_2XX, "the request must be answered successfully")
                    .check(CheckType.RETURN_BODY_NOT_NULL, "the response must carry the produced content")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new ImportControllerWrapper());
    }

}

package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.SqlUseCaseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for SqlUseCase#getSql.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class SqlUseCaseGetSqlScenario {

    @Test
    @DisplayName("UTAPI-012882")
    void case_UTAPI_012882() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012882",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012882", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012882")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012883")
    void case_UTAPI_012883() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012883",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012883", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012883")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012884")
    void case_UTAPI_012884() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012884",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012884", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012884")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012885")
    void case_UTAPI_012885() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012885",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012885", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012885")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012886")
    void case_UTAPI_012886() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012886",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012886", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012886")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012887")
    void case_UTAPI_012887() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012887",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012887", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012887")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012888")
    void case_UTAPI_012888() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012888",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012888", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012888")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012889")
    void case_UTAPI_012889() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012889",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012889", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012889")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012890")
    void case_UTAPI_012890() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012890",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012890", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012890")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012891")
    void case_UTAPI_012891() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012891",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012891", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012891")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

    @Test
    @DisplayName("UTAPI-012892")
    void case_UTAPI_012892() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-012892",
                "com.matsushita.dbeditor.usecase.sql.SqlUseCase",
                "getSql",
                "SqlResponse",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-012892", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-012892")
                    .targetId("./java/com/matsushita/dbeditor/usecase/sql/SqlUseCase.java::SqlUseCase::getSql::2::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DELEGATION_CONTRACT)
                    .observation("invocation of savedSqlRepository.findById")
                    .expected("the value generated for n is carried to its declared observation point unchanged and the operation is performed through the declared collaborator")
                    .failure("the collaborator is not used, the value is dropped, altered or handed to the wrong parameter, or the result is not the one the collaborator produced")
                    .assertion("verify the collaborator invocation with captured arguments and assert the returned value")
                    .check(CheckType.INVOKED_ONCE, "the operation must be carried out through savedSqlRepository.findById", "savedSqlRepository", "findById")
                    .check(CheckType.ARG_EQUALS, "argument 0 of savedSqlRepository.findById must carry the value generated for n", "savedSqlRepository", "findById", "0", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce a result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new SqlUseCaseWrapper());
    }

}

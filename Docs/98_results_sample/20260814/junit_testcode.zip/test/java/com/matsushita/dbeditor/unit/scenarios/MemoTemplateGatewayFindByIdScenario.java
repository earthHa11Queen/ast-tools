package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.MemoTemplateGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for MemoTemplateGateway#findById.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class MemoTemplateGatewayFindByIdScenario {

    @Test
    @DisplayName("UTAPI-002861")
    void case_UTAPI_002861() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002861",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002861", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002861")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "1:length_null", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002862")
    void case_UTAPI_002862() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002862",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002862", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002862")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002863")
    void case_UTAPI_002863() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002863",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002863", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002863")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "3:length_min", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002864")
    void case_UTAPI_002864() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002864",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002864", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002864")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002865")
    void case_UTAPI_002865() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002865",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002865", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002865")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "5:length_max", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002866")
    void case_UTAPI_002866() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002866",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002866", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002866")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002867")
    void case_UTAPI_002867() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002867",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002867", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002867")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002868")
    void case_UTAPI_002868() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002868",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002868", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002868")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002869")
    void case_UTAPI_002869() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002869",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002869", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002869")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002870")
    void case_UTAPI_002870() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002870",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002870", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002870")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-002871")
    void case_UTAPI_002871() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-002871",
                "com.matsushita.dbeditor.adapter.gateway.MemoTemplateGateway",
                "findById",
                "Optional<MemoTemplate>",
                new ParamSpec[] {
                    new ParamSpec("n", "Integer", "n")
                },
                new DataRef[] {
                    new DataRef("UTAPI-002871", "n", "TARGET", "NUMBER", "Integer")
                },
                OraclePlan.builder("UTAPI-002871")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/MemoTemplateGateway.java::MemoTemplateGateway::findById::2::ARG::1::-::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("n", "n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the statements and bind values handed to the declared JdbcTemplate")
                    .expected("the persistence operation is executed through the declared JdbcTemplate and the value generated for n is used by it unchanged")
                    .failure("the gateway fabricates a result without executing a statement, or truncates, normalises or drops the supplied value")
                    .assertion("verify the JdbcTemplate interaction and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the declared JdbcTemplate", "jdbcTemplate", "")
                    .check(CheckType.RETURN_PATH_EQUALS, "a row found in the database must be exposed as present", "isPresent", "bool:true")
                    .check(CheckType.VALUE_REACHED, "the value generated for n must reach the executed statement unchanged", "jdbcTemplate", "", "data:n")
                    .check(CheckType.RETURN_NOT_NULL, "the operation must produce its declared result")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new MemoTemplateGatewayWrapper());
    }

}

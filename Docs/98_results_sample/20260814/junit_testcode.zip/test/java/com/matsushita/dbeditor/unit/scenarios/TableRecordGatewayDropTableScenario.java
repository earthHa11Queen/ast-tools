package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TableRecordGatewayWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TableRecordGateway#dropTable.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TableRecordGatewayDropTableScenario {

    @Test
    @DisplayName("UTAPI-005122")
    void case_UTAPI_005122() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005122",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005122", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005122", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005122", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005122", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005122", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005122", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005122", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005122", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005122", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005122", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005122", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005122", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005122")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005123")
    void case_UTAPI_005123() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005123",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005123", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005123", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005123", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005123", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005123", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005123", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005123", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005123", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005123", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005123", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005123", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005123", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005123")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005124")
    void case_UTAPI_005124() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005124",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005124", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005124", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005124", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005124", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005124", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005124", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005124", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005124", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005124", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005124", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005124", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005124", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005124")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005125")
    void case_UTAPI_005125() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005125",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005125", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005125", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005125", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005125", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005125", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005125", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005125", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005125", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005125", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005125", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005125", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005125", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005125")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005126")
    void case_UTAPI_005126() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005126",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005126", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005126", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005126", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005126", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005126", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005126", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005126", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005126", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005126", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005126", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005126", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005126", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005126")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005127")
    void case_UTAPI_005127() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005127",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005127", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005127", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005127", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005127", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005127", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005127", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005127", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005127", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005127", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005127", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005127", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005127", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005127")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005128")
    void case_UTAPI_005128() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005128",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005128", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005128", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005128", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005128", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005128", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005128", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005128", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005128", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005128", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005128", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005128", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005128", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005128")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005129")
    void case_UTAPI_005129() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005129",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005129", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005129", "setting.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005129", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005129", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005129", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005129", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005129", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005129", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005129", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005129", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005129", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005129", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005129")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.createdTimestamp", "ConnectionSetting.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.createdTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005130")
    void case_UTAPI_005130() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005130",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005130", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005130", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005130", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005130", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005130", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005130", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005130", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005130", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005130", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005130", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005130", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005130", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005130")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005131")
    void case_UTAPI_005131() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005131",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005131", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005131", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005131", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005131", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005131", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005131", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005131", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005131", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005131", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005131", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005131", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005131", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005131")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005132")
    void case_UTAPI_005132() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005132",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005132", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005132", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005132", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005132", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005132", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005132", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005132", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005132", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005132", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005132", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005132", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005132", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005132")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005133")
    void case_UTAPI_005133() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005133",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005133", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005133", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005133", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005133", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005133", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005133", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005133", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005133", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005133", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005133", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005133", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005133", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005133")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005134")
    void case_UTAPI_005134() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005134",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005134", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005134", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005134", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005134", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005134", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005134", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005134", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005134", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005134", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005134", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005134", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005134", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005134")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005135")
    void case_UTAPI_005135() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005135",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005135", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005135", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005135", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005135", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005135", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005135", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005135", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005135", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005135", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005135", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005135", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005135", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005135")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005136")
    void case_UTAPI_005136() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005136",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005136", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005136", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005136", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005136", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005136", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005136", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005136", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005136", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005136", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005136", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005136", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005136", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005136")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005137")
    void case_UTAPI_005137() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005137",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005137", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005137", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005137", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005137", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005137", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005137", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005137", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005137", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005137", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005137", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005137", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005137", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005137")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005138")
    void case_UTAPI_005138() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005138",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005138", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005138", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005138", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005138", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005138", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005138", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005138", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005138", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005138", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005138", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005138", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005138", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005138")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005139")
    void case_UTAPI_005139() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005139",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005139", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005139", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005139", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005139", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005139", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005139", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005139", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005139", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005139", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005139", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005139", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005139", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005139")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005140")
    void case_UTAPI_005140() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005140",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005140", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005140", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005140", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005140", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005140", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005140", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005140", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005140", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005140", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005140", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005140", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005140", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005140")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005141")
    void case_UTAPI_005141() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005141",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005141", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005141", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005141", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005141", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005141", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005141", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005141", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005141", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005141", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005141", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005141", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005141", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005141")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005142")
    void case_UTAPI_005142() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005142",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005142", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005142", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005142", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005142", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005142", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005142", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005142", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005142", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005142", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005142", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005142", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005142", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005142")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005143")
    void case_UTAPI_005143() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005143",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005143", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005143", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005143", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005143", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005143", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005143", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005143", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005143", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005143", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005143", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005143", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005143", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005143")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "56:space")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005144")
    void case_UTAPI_005144() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005144",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005144", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005144", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005144", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005144", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005144", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005144", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005144", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005144", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005144", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005144", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005144", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005144", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005144")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005145")
    void case_UTAPI_005145() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005145",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005145", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005145", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005145", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005145", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005145", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005145", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005145", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005145", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005145", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005145", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005145", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005145", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005145")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005146")
    void case_UTAPI_005146() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005146",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005146", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005146", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005146", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005146", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005146", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005146", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005146", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005146", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005146", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005146", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005146", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005146", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005146")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005147")
    void case_UTAPI_005147() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005147",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005147", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005147", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005147", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005147", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005147", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005147", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005147", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005147", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005147", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005147", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005147", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005147", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005147")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005148")
    void case_UTAPI_005148() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005148",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005148", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005148", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005148", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005148", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005148", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005148", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005148", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005148", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005148", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005148", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005148", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005148", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005148")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005149")
    void case_UTAPI_005149() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005149",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005149", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005149", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005149", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005149", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005149", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005149", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005149", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005149", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005149", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005149", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005149", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005149", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005149")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005150")
    void case_UTAPI_005150() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005150",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005150", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005150", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005150", "setting.databaseName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005150", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005150", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005150", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005150", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005150", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005150", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005150", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005150", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005150", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005150")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::databaseName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.databaseName", "ConnectionSetting.databaseName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.databaseName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005151")
    void case_UTAPI_005151() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005151",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005151", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005151", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005151", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005151", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005151", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005151", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005151", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005151", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005151", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005151", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005151", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005151", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005151")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005152")
    void case_UTAPI_005152() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005152",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005152", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005152", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005152", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005152", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005152", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005152", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005152", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005152", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005152", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005152", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005152", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005152", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005152")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005153")
    void case_UTAPI_005153() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005153",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005153", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005153", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005153", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005153", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005153", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005153", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005153", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005153", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005153", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005153", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005153", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005153", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005153")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005154")
    void case_UTAPI_005154() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005154",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005154", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005154", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005154", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005154", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005154", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005154", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005154", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005154", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005154", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005154", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005154", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005154", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005154")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005155")
    void case_UTAPI_005155() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005155",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005155", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005155", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005155", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005155", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005155", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005155", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005155", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005155", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005155", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005155", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005155", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005155", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005155")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005156")
    void case_UTAPI_005156() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005156",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005156", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005156", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005156", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005156", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005156", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005156", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005156", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005156", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005156", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005156", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005156", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005156", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005156")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005157")
    void case_UTAPI_005157() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005157",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005157", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005157", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005157", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005157", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005157", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005157", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005157", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005157", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005157", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005157", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005157", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005157", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005157")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005158")
    void case_UTAPI_005158() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005158",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005158", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005158", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005158", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005158", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005158", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005158", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005158", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005158", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005158", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005158", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005158", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005158", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005158")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005159")
    void case_UTAPI_005159() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005159",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005159", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005159", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005159", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005159", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005159", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005159", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005159", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005159", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005159", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005159", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005159", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005159", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005159")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005160")
    void case_UTAPI_005160() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005160",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005160", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005160", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005160", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005160", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005160", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005160", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005160", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005160", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005160", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005160", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005160", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005160", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005160")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005161")
    void case_UTAPI_005161() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005161",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005161", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005161", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005161", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005161", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005161", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005161", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005161", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005161", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005161", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005161", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005161", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005161", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005161")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005162")
    void case_UTAPI_005162() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005162",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005162", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005162", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005162", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005162", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005162", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005162", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005162", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005162", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005162", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005162", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005162", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005162", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005162")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005163")
    void case_UTAPI_005163() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005163",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005163", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005163", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005163", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005163", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005163", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005163", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005163", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005163", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005163", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005163", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005163", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005163", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005163")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005164")
    void case_UTAPI_005164() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005164",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005164", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005164", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005164", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005164", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005164", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005164", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005164", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005164", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005164", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005164", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005164", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005164", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005164")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005165")
    void case_UTAPI_005165() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005165",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005165", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005165", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005165", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005165", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005165", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005165", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005165", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005165", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005165", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005165", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005165", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005165", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005165")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005166")
    void case_UTAPI_005166() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005166",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005166", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005166", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005166", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005166", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005166", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005166", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005166", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005166", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005166", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005166", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005166", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005166", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005166")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005167")
    void case_UTAPI_005167() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005167",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005167", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005167", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005167", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005167", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005167", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005167", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005167", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005167", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005167", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005167", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005167", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005167", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005167")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005168")
    void case_UTAPI_005168() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005168",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005168", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005168", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005168", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005168", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005168", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005168", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005168", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005168", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005168", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005168", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005168", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005168", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005168")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005169")
    void case_UTAPI_005169() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005169",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005169", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005169", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005169", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005169", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005169", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005169", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005169", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005169", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005169", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005169", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005169", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005169", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005169")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005170")
    void case_UTAPI_005170() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005170",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005170", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005170", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005170", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005170", "setting.dbHost", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005170", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005170", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005170", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005170", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005170", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005170", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005170", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005170", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005170")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbHost")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbHost", "ConnectionSetting.dbHost")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbHost reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005171")
    void case_UTAPI_005171() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005171",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005171", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005171", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005171", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005171", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005171", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005171", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005171", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005171", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005171", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005171", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005171", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005171", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005171")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005172")
    void case_UTAPI_005172() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005172",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005172", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005172", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005172", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005172", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005172", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005172", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005172", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005172", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005172", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005172", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005172", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005172", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005172")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005173")
    void case_UTAPI_005173() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005173",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005173", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005173", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005173", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005173", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005173", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005173", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005173", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005173", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005173", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005173", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005173", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005173", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005173")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005174")
    void case_UTAPI_005174() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005174",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005174", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005174", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005174", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005174", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005174", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005174", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005174", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005174", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005174", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005174", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005174", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005174", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005174")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005175")
    void case_UTAPI_005175() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005175",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005175", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005175", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005175", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005175", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005175", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005175", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005175", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005175", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005175", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005175", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005175", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005175", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005175")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005176")
    void case_UTAPI_005176() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005176",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005176", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005176", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005176", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005176", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005176", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005176", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005176", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005176", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005176", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005176", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005176", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005176", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005176")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005177")
    void case_UTAPI_005177() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005177",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005177", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005177", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005177", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005177", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005177", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005177", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005177", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005177", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005177", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005177", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005177", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005177", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005177")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005178")
    void case_UTAPI_005178() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005178",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005178", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005178", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005178", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005178", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005178", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005178", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005178", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005178", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005178", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005178", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005178", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005178", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005178")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005179")
    void case_UTAPI_005179() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005179",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005179", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005179", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005179", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005179", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005179", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005179", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005179", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005179", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005179", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005179", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005179", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005179", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005179")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005180")
    void case_UTAPI_005180() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005180",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005180", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005180", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005180", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005180", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005180", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005180", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005180", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005180", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005180", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005180", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005180", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005180", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005180")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005181")
    void case_UTAPI_005181() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005181",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005181", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005181", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005181", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005181", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005181", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005181", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005181", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005181", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005181", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005181", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005181", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005181", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005181")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005182")
    void case_UTAPI_005182() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005182",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005182", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005182", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005182", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005182", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005182", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005182", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005182", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005182", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005182", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005182", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005182", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005182", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005182")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005183")
    void case_UTAPI_005183() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005183",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005183", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005183", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005183", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005183", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005183", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005183", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005183", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005183", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005183", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005183", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005183", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005183", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005183")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005184")
    void case_UTAPI_005184() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005184",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005184", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005184", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005184", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005184", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005184", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005184", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005184", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005184", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005184", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005184", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005184", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005184", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005184")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005185")
    void case_UTAPI_005185() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005185",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005185", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005185", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005185", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005185", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005185", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005185", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005185", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005185", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005185", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005185", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005185", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005185", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005185")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005186")
    void case_UTAPI_005186() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005186",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005186", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005186", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005186", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005186", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005186", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005186", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005186", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005186", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005186", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005186", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005186", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005186", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005186")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005187")
    void case_UTAPI_005187() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005187",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005187", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005187", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005187", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005187", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005187", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005187", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005187", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005187", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005187", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005187", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005187", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005187", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005187")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005188")
    void case_UTAPI_005188() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005188",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005188", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005188", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005188", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005188", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005188", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005188", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005188", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005188", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005188", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005188", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005188", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005188", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005188")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005189")
    void case_UTAPI_005189() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005189",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005189", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005189", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005189", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005189", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005189", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005189", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005189", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005189", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005189", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005189", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005189", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005189", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005189")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005190")
    void case_UTAPI_005190() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005190",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005190", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005190", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005190", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005190", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005190", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005190", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005190", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005190", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005190", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005190", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005190", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005190", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005190")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005191")
    void case_UTAPI_005191() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005191",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005191", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005191", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005191", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005191", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005191", "setting.dbName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005191", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005191", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005191", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005191", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005191", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005191", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005191", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005191")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbName", "ConnectionSetting.dbName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005192")
    void case_UTAPI_005192() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005192",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005192", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005192", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005192", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005192", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005192", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005192", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005192", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005192", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005192", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005192", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005192", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005192", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005192")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005193")
    void case_UTAPI_005193() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005193",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005193", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005193", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005193", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005193", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005193", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005193", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005193", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005193", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005193", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005193", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005193", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005193", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005193")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005194")
    void case_UTAPI_005194() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005194",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005194", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005194", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005194", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005194", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005194", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005194", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005194", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005194", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005194", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005194", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005194", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005194", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005194")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005195")
    void case_UTAPI_005195() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005195",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005195", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005195", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005195", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005195", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005195", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005195", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005195", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005195", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005195", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005195", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005195", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005195", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005195")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005196")
    void case_UTAPI_005196() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005196",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005196", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005196", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005196", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005196", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005196", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005196", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005196", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005196", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005196", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005196", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005196", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005196", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005196")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005197")
    void case_UTAPI_005197() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005197",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005197", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005197", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005197", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005197", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005197", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005197", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005197", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005197", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005197", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005197", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005197", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005197", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005197")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005198")
    void case_UTAPI_005198() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005198",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005198", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005198", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005198", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005198", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005198", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005198", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005198", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005198", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005198", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005198", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005198", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005198", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005198")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005199")
    void case_UTAPI_005199() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005199",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005199", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005199", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005199", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005199", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005199", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005199", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005199", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005199", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005199", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005199", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005199", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005199", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005199")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005200")
    void case_UTAPI_005200() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005200",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005200", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005200", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005200", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005200", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005200", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005200", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005200", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005200", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005200", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005200", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005200", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005200", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005200")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005201")
    void case_UTAPI_005201() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005201",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005201", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005201", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005201", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005201", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005201", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005201", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005201", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005201", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005201", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005201", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005201", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005201", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005201")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005202")
    void case_UTAPI_005202() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005202",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005202", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005202", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005202", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005202", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005202", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005202", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005202", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005202", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005202", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005202", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005202", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005202", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005202")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005203")
    void case_UTAPI_005203() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005203",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005203", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005203", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005203", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005203", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005203", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005203", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005203", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005203", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005203", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005203", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005203", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005203", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005203")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005204")
    void case_UTAPI_005204() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005204",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005204", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005204", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005204", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005204", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005204", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005204", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005204", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005204", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005204", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005204", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005204", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005204", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005204")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005205")
    void case_UTAPI_005205() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005205",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005205", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005205", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005205", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005205", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005205", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005205", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005205", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005205", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005205", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005205", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005205", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005205", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005205")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005206")
    void case_UTAPI_005206() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005206",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005206", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005206", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005206", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005206", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005206", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005206", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005206", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005206", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005206", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005206", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005206", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005206", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005206")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005207")
    void case_UTAPI_005207() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005207",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005207", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005207", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005207", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005207", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005207", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005207", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005207", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005207", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005207", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005207", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005207", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005207", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005207")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005208")
    void case_UTAPI_005208() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005208",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005208", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005208", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005208", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005208", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005208", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005208", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005208", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005208", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005208", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005208", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005208", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005208", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005208")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005209")
    void case_UTAPI_005209() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005209",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005209", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005209", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005209", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005209", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005209", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005209", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005209", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005209", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005209", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005209", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005209", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005209", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005209")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005210")
    void case_UTAPI_005210() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005210",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005210", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005210", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005210", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005210", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005210", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005210", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005210", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005210", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005210", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005210", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005210", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005210", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005210")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005211")
    void case_UTAPI_005211() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005211",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005211", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005211", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005211", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005211", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005211", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005211", "setting.dbPassword", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005211", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005211", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005211", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005211", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005211", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005211", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005211")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPassword")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbPassword", "ConnectionSetting.dbPassword")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPassword reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005212")
    void case_UTAPI_005212() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005212",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005212", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005212", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005212", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005212", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005212", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005212", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005212", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005212", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005212", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005212", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005212", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005212", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005212")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005213")
    void case_UTAPI_005213() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005213",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005213", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005213", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005213", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005213", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005213", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005213", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005213", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005213", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005213", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005213", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005213", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005213", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005213")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005214")
    void case_UTAPI_005214() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005214",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005214", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005214", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005214", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005214", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005214", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005214", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005214", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005214", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005214", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005214", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005214", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005214", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005214")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005215")
    void case_UTAPI_005215() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005215",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005215", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005215", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005215", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005215", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005215", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005215", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005215", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005215", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005215", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005215", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005215", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005215", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005215")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005216")
    void case_UTAPI_005216() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005216",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005216", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005216", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005216", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005216", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005216", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005216", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005216", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005216", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005216", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005216", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005216", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005216", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005216")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005217")
    void case_UTAPI_005217() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005217",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005217", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005217", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005217", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005217", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005217", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005217", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005217", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005217", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005217", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005217", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005217", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005217", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005217")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005218")
    void case_UTAPI_005218() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005218",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005218", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005218", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005218", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005218", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005218", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005218", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005218", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005218", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005218", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005218", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005218", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005218", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005218")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005219")
    void case_UTAPI_005219() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005219",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005219", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005219", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005219", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005219", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005219", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005219", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005219", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005219", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005219", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005219", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005219", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005219", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005219")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005220")
    void case_UTAPI_005220() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005220",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005220", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005220", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005220", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005220", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005220", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005220", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005220", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005220", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005220", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005220", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005220", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005220", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005220")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005221")
    void case_UTAPI_005221() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005221",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005221", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005221", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005221", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005221", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005221", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005221", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005221", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005221", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005221", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005221", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005221", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005221", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005221")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005222")
    void case_UTAPI_005222() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005222",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005222", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005222", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005222", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005222", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005222", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005222", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005222", "setting.dbPort", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005222", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005222", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005222", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005222", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005222", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005222")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbPort")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.dbPort", "ConnectionSetting.dbPort")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbPort reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005223")
    void case_UTAPI_005223() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005223",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005223", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005223", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005223", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005223", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005223", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005223", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005223", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005223", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005223", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005223", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005223", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005223", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005223")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005224")
    void case_UTAPI_005224() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005224",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005224", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005224", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005224", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005224", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005224", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005224", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005224", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005224", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005224", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005224", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005224", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005224", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005224")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005225")
    void case_UTAPI_005225() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005225",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005225", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005225", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005225", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005225", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005225", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005225", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005225", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005225", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005225", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005225", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005225", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005225", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005225")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005226")
    void case_UTAPI_005226() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005226",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005226", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005226", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005226", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005226", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005226", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005226", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005226", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005226", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005226", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005226", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005226", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005226", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005226")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005227")
    void case_UTAPI_005227() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005227",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005227", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005227", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005227", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005227", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005227", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005227", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005227", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005227", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005227", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005227", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005227", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005227", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005227")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005228")
    void case_UTAPI_005228() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005228",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005228", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005228", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005228", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005228", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005228", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005228", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005228", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005228", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005228", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005228", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005228", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005228", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005228")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005229")
    void case_UTAPI_005229() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005229",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005229", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005229", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005229", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005229", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005229", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005229", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005229", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005229", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005229", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005229", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005229", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005229", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005229")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005230")
    void case_UTAPI_005230() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005230",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005230", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005230", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005230", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005230", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005230", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005230", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005230", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005230", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005230", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005230", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005230", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005230", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005230")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005231")
    void case_UTAPI_005231() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005231",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005231", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005231", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005231", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005231", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005231", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005231", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005231", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005231", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005231", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005231", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005231", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005231", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005231")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005232")
    void case_UTAPI_005232() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005232",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005232", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005232", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005232", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005232", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005232", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005232", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005232", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005232", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005232", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005232", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005232", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005232", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005232")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005233")
    void case_UTAPI_005233() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005233",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005233", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005233", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005233", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005233", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005233", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005233", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005233", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005233", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005233", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005233", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005233", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005233", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005233")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005234")
    void case_UTAPI_005234() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005234",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005234", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005234", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005234", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005234", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005234", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005234", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005234", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005234", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005234", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005234", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005234", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005234", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005234")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005235")
    void case_UTAPI_005235() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005235",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005235", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005235", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005235", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005235", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005235", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005235", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005235", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005235", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005235", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005235", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005235", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005235", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005235")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005236")
    void case_UTAPI_005236() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005236",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005236", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005236", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005236", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005236", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005236", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005236", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005236", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005236", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005236", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005236", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005236", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005236", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005236")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "56:space")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005237")
    void case_UTAPI_005237() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005237",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005237", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005237", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005237", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005237", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005237", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005237", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005237", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005237", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005237", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005237", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005237", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005237", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005237")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005238")
    void case_UTAPI_005238() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005238",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005238", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005238", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005238", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005238", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005238", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005238", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005238", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005238", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005238", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005238", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005238", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005238", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005238")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005239")
    void case_UTAPI_005239() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005239",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005239", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005239", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005239", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005239", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005239", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005239", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005239", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005239", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005239", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005239", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005239", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005239", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005239")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "59:tab")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005240")
    void case_UTAPI_005240() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005240",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005240", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005240", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005240", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005240", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005240", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005240", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005240", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005240", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005240", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005240", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005240", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005240", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005240")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "60:control_character_null")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005241")
    void case_UTAPI_005241() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005241",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005241", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005241", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005241", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005241", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005241", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005241", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005241", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005241", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005241", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005241", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005241", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005241", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005241")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005242")
    void case_UTAPI_005242() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005242",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005242", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005242", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005242", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005242", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005242", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005242", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005242", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005242", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005242", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005242", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005242", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005242", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005242")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005243")
    void case_UTAPI_005243() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005243",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005243", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005243", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005243", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005243", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005243", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005243", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005243", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005243", "setting.dbUsername", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005243", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005243", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005243", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005243", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005243")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::dbUsername")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("setting.dbUsername", "ConnectionSetting.dbUsername")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.dbUsername reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005244")
    void case_UTAPI_005244() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005244",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005244", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005244", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005244", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005244", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005244", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005244", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005244", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005244", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005244", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005244", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005244", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005244", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005244")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005245")
    void case_UTAPI_005245() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005245",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005245", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005245", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005245", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005245", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005245", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005245", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005245", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005245", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005245", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005245", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005245", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005245", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005245")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005246")
    void case_UTAPI_005246() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005246",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005246", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005246", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005246", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005246", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005246", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005246", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005246", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005246", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005246", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005246", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005246", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005246", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005246")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "3:length_min", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005247")
    void case_UTAPI_005247() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005247",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005247", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005247", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005247", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005247", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005247", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005247", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005247", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005247", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005247", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005247", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005247", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005247", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005247")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005248")
    void case_UTAPI_005248() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005248",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005248", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005248", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005248", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005248", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005248", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005248", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005248", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005248", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005248", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005248", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005248", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005248", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005248")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "5:length_max", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005249")
    void case_UTAPI_005249() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005249",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005249", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005249", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005249", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005249", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005249", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005249", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005249", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005249", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005249", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005249", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005249", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005249", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005249")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005250")
    void case_UTAPI_005250() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005250",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005250", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005250", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005250", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005250", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005250", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005250", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005250", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005250", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005250", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005250", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005250", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005250", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005250")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005251")
    void case_UTAPI_005251() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005251",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005251", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005251", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005251", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005251", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005251", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005251", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005251", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005251", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005251", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005251", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005251", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005251", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005251")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005252")
    void case_UTAPI_005252() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005252",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005252", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005252", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005252", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005252", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005252", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005252", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005252", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005252", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005252", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005252", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005252", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005252", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005252")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005253")
    void case_UTAPI_005253() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005253",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005253", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005253", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005253", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005253", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005253", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005253", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005253", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005253", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005253", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005253", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005253", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005253", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005253")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005254")
    void case_UTAPI_005254() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005254",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005254", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005254", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005254", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005254", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005254", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005254", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005254", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005254", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005254", "setting.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005254", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005254", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005254", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005254")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("setting.n", "ConnectionSetting.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.n reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005255")
    void case_UTAPI_005255() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005255",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005255", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005255", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005255", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005255", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005255", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005255", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005255", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005255", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005255", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005255", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005255", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005255", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005255")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005256")
    void case_UTAPI_005256() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005256",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005256", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005256", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005256", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005256", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005256", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005256", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005256", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005256", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005256", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005256", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005256", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005256", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005256")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005257")
    void case_UTAPI_005257() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005257",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005257", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005257", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005257", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005257", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005257", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005257", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005257", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005257", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005257", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005257", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005257", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005257", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005257")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005258")
    void case_UTAPI_005258() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005258",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005258", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005258", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005258", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005258", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005258", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005258", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005258", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005258", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005258", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005258", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005258", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005258", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005258")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005259")
    void case_UTAPI_005259() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005259",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005259", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005259", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005259", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005259", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005259", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005259", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005259", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005259", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005259", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005259", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005259", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005259", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005259")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005260")
    void case_UTAPI_005260() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005260",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005260", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005260", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005260", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005260", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005260", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005260", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005260", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005260", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005260", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005260", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005260", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005260", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005260")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005261")
    void case_UTAPI_005261() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005261",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005261", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005261", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005261", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005261", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005261", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005261", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005261", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005261", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005261", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005261", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005261", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005261", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005261")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005262")
    void case_UTAPI_005262() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005262",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005262", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005262", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005262", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005262", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005262", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005262", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005262", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005262", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005262", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005262", "setting.updatedTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005262", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005262", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005262")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::FIELD::1::ConnectionSetting::updatedTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("setting.updatedTimestamp", "ConnectionSetting.updatedTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for setting.updatedTimestamp reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005263")
    void case_UTAPI_005263() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005263",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005263", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005263", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005263", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005263", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005263", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005263", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005263", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005263", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005263", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005263", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005263", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005263", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005263")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "1:length_null", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005264")
    void case_UTAPI_005264() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005264",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005264", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005264", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005264", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005264", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005264", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005264", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005264", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005264", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005264", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005264", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005264", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005264", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005264")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "2:length_empty", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005265")
    void case_UTAPI_005265() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005265",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005265", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005265", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005265", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005265", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005265", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005265", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005265", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005265", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005265", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005265", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005265", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005265", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005265")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "3:length_min", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005266")
    void case_UTAPI_005266() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005266",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005266", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005266", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005266", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005266", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005266", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005266", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005266", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005266", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005266", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005266", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005266", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005266", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005266")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005267")
    void case_UTAPI_005267() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005267",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005267", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005267", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005267", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005267", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005267", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005267", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005267", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005267", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005267", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005267", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005267", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005267", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005267")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "5:length_max", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005268")
    void case_UTAPI_005268() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005268",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005268", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005268", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005268", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005268", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005268", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005268", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005268", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005268", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005268", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005268", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005268", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005268", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005268")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005269")
    void case_UTAPI_005269() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005269",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005269", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005269", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005269", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005269", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005269", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005269", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005269", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005269", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005269", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005269", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005269", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005269", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005269")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005270")
    void case_UTAPI_005270() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005270",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005270", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005270", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005270", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005270", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005270", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005270", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005270", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005270", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005270", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005270", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005270", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005270", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005270")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005271")
    void case_UTAPI_005271() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005271",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005271", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005271", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005271", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005271", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005271", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005271", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005271", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005271", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005271", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005271", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005271", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005271", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005271")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005272")
    void case_UTAPI_005272() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005272",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005272", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005272", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005272", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005272", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005272", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005272", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005272", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005272", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005272", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005272", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005272", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005272", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005272")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005273")
    void case_UTAPI_005273() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005273",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005273", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005273", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005273", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005273", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005273", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005273", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005273", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005273", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005273", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005273", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005273", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005273", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005273")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005274")
    void case_UTAPI_005274() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005274",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005274", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005274", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005274", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005274", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005274", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005274", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005274", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005274", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005274", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005274", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005274", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005274", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005274")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005275")
    void case_UTAPI_005275() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005275",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005275", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005275", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005275", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005275", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005275", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005275", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005275", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005275", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005275", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005275", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005275", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005275", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005275")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005276")
    void case_UTAPI_005276() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005276",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005276", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005276", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005276", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005276", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005276", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005276", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005276", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005276", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005276", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005276", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005276", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005276", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005276")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "56:space")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005277")
    void case_UTAPI_005277() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005277",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005277", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005277", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005277", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005277", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005277", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005277", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005277", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005277", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005277", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005277", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005277", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005277", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005277")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005278")
    void case_UTAPI_005278() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005278",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005278", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005278", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005278", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005278", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005278", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005278", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005278", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005278", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005278", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005278", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005278", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005278", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005278")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005279")
    void case_UTAPI_005279() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005279",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005279", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005279", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005279", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005279", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005279", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005279", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005279", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005279", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005279", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005279", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005279", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005279", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005279")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "59:tab")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005280")
    void case_UTAPI_005280() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005280",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005280", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005280", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005280", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005280", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005280", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005280", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005280", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005280", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005280", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005280", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005280", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005280", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005280")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005281")
    void case_UTAPI_005281() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005281",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005281", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005281", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005281", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005281", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005281", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005281", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005281", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005281", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005281", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005281", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005281", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005281", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005281")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005282")
    void case_UTAPI_005282() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005282",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005282", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005282", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005282", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005282", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005282", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005282", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005282", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005282", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005282", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005282", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005282", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005282", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005282")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005283")
    void case_UTAPI_005283() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005283",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005283", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005283", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005283", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005283", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005283", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005283", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005283", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005283", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005283", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005283", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005283", "schemaName", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-005283", "tableName", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005283")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::2::-::schemaName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("schemaName", "schemaName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for schemaName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested tableName", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.VALUE_REACHED, "the value generated for schemaName must reach the executed statement unchanged", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005284")
    void case_UTAPI_005284() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005284",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005284", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005284", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005284", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005284", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005284", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005284", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005284", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005284", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005284", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005284", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005284", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005284", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005284")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "1:length_null", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005285")
    void case_UTAPI_005285() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005285",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005285", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005285", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005285", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005285", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005285", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005285", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005285", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005285", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005285", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005285", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005285", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005285", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005285")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "2:length_empty", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005286")
    void case_UTAPI_005286() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005286",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005286", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005286", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005286", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005286", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005286", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005286", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005286", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005286", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005286", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005286", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005286", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005286", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005286")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "3:length_min", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005287")
    void case_UTAPI_005287() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005287",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005287", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005287", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005287", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005287", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005287", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005287", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005287", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005287", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005287", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005287", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005287", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005287", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005287")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005288")
    void case_UTAPI_005288() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005288",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005288", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005288", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005288", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005288", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005288", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005288", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005288", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005288", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005288", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005288", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005288", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005288", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005288")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "5:length_max", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005289")
    void case_UTAPI_005289() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005289",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005289", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005289", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005289", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005289", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005289", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005289", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005289", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005289", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005289", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005289", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005289", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005289", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005289")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005290")
    void case_UTAPI_005290() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005290",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005290", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005290", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005290", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005290", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005290", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005290", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005290", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005290", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005290", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005290", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005290", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005290", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005290")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005291")
    void case_UTAPI_005291() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005291",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005291", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005291", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005291", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005291", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005291", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005291", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005291", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005291", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005291", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005291", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005291", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005291", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005291")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005292")
    void case_UTAPI_005292() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005292",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005292", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005292", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005292", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005292", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005292", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005292", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005292", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005292", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005292", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005292", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005292", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005292", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005292")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005293")
    void case_UTAPI_005293() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005293",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005293", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005293", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005293", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005293", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005293", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005293", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005293", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005293", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005293", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005293", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005293", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005293", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005293")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005294")
    void case_UTAPI_005294() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005294",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005294", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005294", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005294", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005294", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005294", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005294", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005294", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005294", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005294", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005294", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005294", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005294", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005294")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005295")
    void case_UTAPI_005295() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005295",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005295", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005295", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005295", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005295", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005295", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005295", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005295", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005295", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005295", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005295", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005295", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005295", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005295")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005296")
    void case_UTAPI_005296() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005296",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005296", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005296", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005296", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005296", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005296", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005296", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005296", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005296", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005296", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005296", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005296", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005296", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005296")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005297")
    void case_UTAPI_005297() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005297",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005297", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005297", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005297", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005297", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005297", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005297", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005297", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005297", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005297", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005297", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005297", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005297", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005297")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "56:space")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005298")
    void case_UTAPI_005298() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005298",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005298", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005298", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005298", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005298", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005298", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005298", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005298", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005298", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005298", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005298", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005298", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005298", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005298")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005299")
    void case_UTAPI_005299() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005299",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005299", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005299", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005299", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005299", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005299", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005299", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005299", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005299", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005299", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005299", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005299", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005299", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005299")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005300")
    void case_UTAPI_005300() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005300",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005300", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005300", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005300", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005300", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005300", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005300", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005300", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005300", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005300", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005300", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005300", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005300", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005300")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "59:tab")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005301")
    void case_UTAPI_005301() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005301",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005301", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005301", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005301", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005301", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005301", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005301", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005301", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005301", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005301", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005301", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005301", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005301", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005301")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "60:control_character_null")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005302")
    void case_UTAPI_005302() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005302",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005302", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005302", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005302", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005302", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005302", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005302", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005302", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005302", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005302", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005302", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005302", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005302", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005302")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005303")
    void case_UTAPI_005303() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005303",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005303", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005303", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005303", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005303", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005303", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005303", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005303", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005303", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005303", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005303", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005303", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005303", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005303")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

    @Test
    @DisplayName("UTAPI-005304")
    void case_UTAPI_005304() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-005304",
                "com.matsushita.dbeditor.adapter.gateway.TableRecordGateway",
                "dropTable",
                "void",
                new ParamSpec[] {
                    new ParamSpec("setting", "ConnectionSetting", "setting"),
                    new ParamSpec("schemaName", "String", "schemaName"),
                    new ParamSpec("tableName", "String", "tableName")
                },
                new DataRef[] {
                    new DataRef("UTAPI-005304", "setting", "NORMAL", "OBJECT", "ConnectionSetting"),
                    new DataRef("UTAPI-005304", "setting.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005304", "setting.databaseName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005304", "setting.dbHost", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005304", "setting.dbName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005304", "setting.dbPassword", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005304", "setting.dbPort", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005304", "setting.dbUsername", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005304", "setting.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-005304", "setting.updatedTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-005304", "schemaName", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-005304", "tableName", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-005304")
                    .targetId("./java/com/matsushita/dbeditor/adapter/gateway/TableRecordGateway.java::TableRecordGateway::dropTable::6::ARG::3::-::tableName")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("tableName", "tableName")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.INFRA_DELEGATION_CONTRACT)
                    .observation("the interactions with the declared TargetDatabaseConnector and the JdbcTemplate it produced")
                    .expected("the operation is executed against the database described by the supplied settings, and the value generated for tableName reaches the executed statement unchanged")
                    .failure("the gateway bypasses the declared connector, mutates the supplied settings, rewrites the identifier, or fabricates a result without executing a statement")
                    .assertion("verify the connector and JdbcTemplate interactions and assert the captured statement arguments")
                    .check(CheckType.EXCEPTION_ALLOWED_FAIL_CLOSED, "an identifier that the declared validator rejects must abort the operation before any statement is executed", "java.lang.IllegalArgumentException", "JdbcTemplate")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the connection must be obtained through the declared connector", "targetDatabaseConnector", "")
                    .check(CheckType.ARG_SAME, "the supplied connection settings must reach the connector as they were given", "targetDatabaseConnector", "", "0", "data:setting")
                    .check(CheckType.INVOKED_AT_LEAST_ONCE, "the operation must be executed through the obtained JdbcTemplate", "JdbcTemplate", "")
                    .check(CheckType.VALUE_REACHED, "the executed statement must carry the requested schemaName", "JdbcTemplate", "", "data:schemaName")
                    .check(CheckType.VALUE_REACHED, "the value generated for tableName must reach the executed statement unchanged", "JdbcTemplate", "", "data:tableName")
                    .check(CheckType.NO_EXCEPTION, "this input condition must be processed, not aborted")
                    .build()),
            new TableRecordGatewayWrapper());
    }

}

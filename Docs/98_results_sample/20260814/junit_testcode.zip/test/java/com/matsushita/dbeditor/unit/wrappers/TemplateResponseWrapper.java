package com.matsushita.dbeditor.unit.wrappers;

import com.matsushita.dbeditor.utils.ExecutionResult;
import com.matsushita.dbeditor.utils.HarnessException;

/**
 * Operation wrapper for TemplateResponse.
 */
public final class TemplateResponseWrapper extends SutWrapper {

    private static final String SUT_CLASS = "com.matsushita.dbeditor.dto.outdto.TemplateResponse";
    private static final String IMPL_CLASS = "com.matsushita.dbeditor.dto.outdto.TemplateResponse";
    private static final String[] DEP_NAMES = new String[] {"n", "title", "content"};
    private static final String[] DEP_TYPES = new String[] {"Integer", "String", "String"};
    private static final String[] TYPES_fromMemo = new String[] {"MemoTemplate"};
    private static final String[] TYPES_fromSql = new String[] {"SqlTemplate"};

    public TemplateResponseWrapper() {
        super(SUT_CLASS, IMPL_CLASS, DEP_NAMES, DEP_TYPES, true);
    }

    /** TemplateResponse fromMemo(t) */
    public ExecutionResult fromMemo(Object[] args) {
        return invoke("fromMemo", TYPES_fromMemo, args);
    }

    /** TemplateResponse fromSql(t) */
    public ExecutionResult fromSql(Object[] args) {
        return invoke("fromSql", TYPES_fromSql, args);
    }

    @Override
    public ExecutionResult execute(String operation, Object[] args) {
        if ("fromMemo".equals(operation)) {
            return fromMemo(args);
        } else if ("fromSql".equals(operation)) {
            return fromSql(args);
        } else {
            throw new HarnessException("Unknown operation " + operation + " on " + sutClassName());
        }
    }
}

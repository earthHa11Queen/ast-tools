package com.matsushita.dbeditor.unit.scenarios;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.matsushita.dbeditor.unit.wrappers.TemplateResponseWrapper;
import com.matsushita.dbeditor.utils.CaseDefinition;
import com.matsushita.dbeditor.utils.CaseExecutor;
import com.matsushita.dbeditor.utils.CheckType;
import com.matsushita.dbeditor.utils.DataRef;
import com.matsushita.dbeditor.utils.OracleKind;
import com.matsushita.dbeditor.utils.OraclePlan;
import com.matsushita.dbeditor.utils.ParamSpec;

/**
 * Validated test cases for TemplateResponse#fromMemo.
 *
 * <p>One CaseNo of the validated test specification is one JUnit test case, and the
 * CaseNo itself is the test title.</p>
 */
class TemplateResponseFromMemoScenario {

    @Test
    @DisplayName("UTAPI-010623")
    void case_UTAPI_010623() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010623",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010623", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010623", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010623", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010623", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010623", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010623")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "1:length_null", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010624")
    void case_UTAPI_010624() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010624",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010624", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010624", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010624", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010624", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010624", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010624")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "2:length_empty", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010625")
    void case_UTAPI_010625() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010625",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010625", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010625", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010625", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010625", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010625", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010625")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "3:length_min", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010626")
    void case_UTAPI_010626() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010626",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010626", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010626", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010626", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010626", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010626", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010626")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010627")
    void case_UTAPI_010627() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010627",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010627", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010627", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010627", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010627", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010627", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010627")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "5:length_max", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010628")
    void case_UTAPI_010628() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010628",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010628", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010628", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010628", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010628", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010628", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010628")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010629")
    void case_UTAPI_010629() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010629",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010629", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010629", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010629", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010629", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010629", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010629")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010630")
    void case_UTAPI_010630() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010630",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010630", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010630", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010630", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010630", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010630", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010630")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010631")
    void case_UTAPI_010631() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010631",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010631", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010631", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010631", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010631", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010631", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010631")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010632")
    void case_UTAPI_010632() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010632",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010632", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010632", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010632", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010632", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010632", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010632")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010633")
    void case_UTAPI_010633() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010633",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010633", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010633", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010633", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010633", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010633", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010633")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010634")
    void case_UTAPI_010634() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010634",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010634", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010634", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010634", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010634", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010634", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010634")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010635")
    void case_UTAPI_010635() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010635",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010635", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010635", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010635", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010635", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010635", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010635")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "56:space")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010636")
    void case_UTAPI_010636() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010636",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010636", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010636", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010636", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010636", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010636", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010636")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010637")
    void case_UTAPI_010637() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010637",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010637", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010637", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010637", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010637", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010637", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010637")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010638")
    void case_UTAPI_010638() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010638",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010638", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010638", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010638", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010638", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010638", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010638")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "59:tab")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010639")
    void case_UTAPI_010639() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010639",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010639", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010639", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010639", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010639", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010639", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010639")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "60:control_character_null")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010640")
    void case_UTAPI_010640() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010640",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010640", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010640", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010640", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010640", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010640", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010640")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010641")
    void case_UTAPI_010641() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010641",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010641", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010641", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010641", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010641", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010641", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010641")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010642")
    void case_UTAPI_010642() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010642",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010642", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010642", "t.contentMemo", "TARGET", "STRING", "String"),
                    new DataRef("UTAPI-010642", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010642", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010642", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010642")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::contentMemo")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("t.contentMemo", "MemoTemplate.contentMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.contentMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010643")
    void case_UTAPI_010643() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010643",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010643", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010643", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010643", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010643", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010643", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010643")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "1:length_null", "-")
                    .target("t.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010644")
    void case_UTAPI_010644() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010644",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010644", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010644", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010644", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010644", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010644", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010644")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "2:length_empty", "-")
                    .target("t.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010645")
    void case_UTAPI_010645() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010645",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010645", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010645", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010645", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010645", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010645", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010645")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("34:hw_datetime", "-", "-")
                    .target("t.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010646")
    void case_UTAPI_010646() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010646",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010646", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010646", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010646", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010646", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010646", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010646")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "26:valid_value")
                    .target("t.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010647")
    void case_UTAPI_010647() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010647",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010647", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010647", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010647", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010647", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010647", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010647")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "27:invalid_value")
                    .target("t.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010648")
    void case_UTAPI_010648() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010648",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010648", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010648", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010648", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010648", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010648", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010648")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "28:leap_year")
                    .target("t.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010649")
    void case_UTAPI_010649() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010649",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010649", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010649", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010649", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010649", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010649", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010649")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "29:within_valid_range")
                    .target("t.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010650")
    void case_UTAPI_010650() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010650",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010650", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010650", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010650", "t.createdTimestamp", "TARGET", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010650", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010650", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010650")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::createdTimestamp")
                    .mirror("-", "-", "30:out_of_range")
                    .target("t.createdTimestamp", "MemoTemplate.createdTimestamp")
                    .validation("-1", "-1", "-1", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.createdTimestamp survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.RESULT_TYPE_HAS_NO_PROPERTY, "the response type must not expose createdTimestamp", "getCreatedTimestamp")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010651")
    void case_UTAPI_010651() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010651",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010651", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010651", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010651", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010651", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010651", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010651")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "1:length_null", "-")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010652")
    void case_UTAPI_010652() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010652",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010652", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010652", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010652", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010652", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010652", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010652")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "2:length_empty", "-")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010653")
    void case_UTAPI_010653() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010653",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010653", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010653", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010653", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010653", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010653", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010653")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "3:length_min", "-")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010654")
    void case_UTAPI_010654() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010654",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010654", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010654", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010654", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010654", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010654", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010654")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010655")
    void case_UTAPI_010655() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010655",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010655", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010655", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010655", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010655", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010655", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010655")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "5:length_max", "-")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010656")
    void case_UTAPI_010656() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010656",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010656", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010656", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010656", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010656", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010656", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010656")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010657")
    void case_UTAPI_010657() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010657",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010657", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010657", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010657", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010657", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010657", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010657")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010658")
    void case_UTAPI_010658() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010658",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010658", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010658", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010658", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010658", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010658", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010658")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("46:hw_integer", "-", "-")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010659")
    void case_UTAPI_010659() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010659",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010659", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010659", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010659", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010659", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010659", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010659")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "-", "12:integer_positive")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010660")
    void case_UTAPI_010660() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010660",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010660", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010660", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010660", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010660", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010660", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010660")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "-", "13:integer_negative")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010661")
    void case_UTAPI_010661() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010661",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010661", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010661", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010661", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010661", "t.n", "TARGET", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010661", "t.titleMemo", "NORMAL", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010661")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::n")
                    .mirror("-", "-", "14:integer_zero")
                    .target("t.n", "MemoTemplate.n")
                    .validation("-1", "1", "18", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.n survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010662")
    void case_UTAPI_010662() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010662",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010662", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010662", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010662", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010662", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010662", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010662")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "1:length_null", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010663")
    void case_UTAPI_010663() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010663",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010663", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010663", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010663", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010663", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010663", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010663")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "2:length_empty", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010664")
    void case_UTAPI_010664() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010664",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010664", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010664", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010664", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010664", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010664", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010664")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "3:length_min", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010665")
    void case_UTAPI_010665() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010665",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010665", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010665", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010665", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010665", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010665", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010665")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "4:length_min_minus_1", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010666")
    void case_UTAPI_010666() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010666",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010666", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010666", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010666", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010666", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010666", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010666")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "5:length_max", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010667")
    void case_UTAPI_010667() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010667",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010667", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010667", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010667", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010667", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010667", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010667")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "6:length_max_plus_1", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010668")
    void case_UTAPI_010668() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010668",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010668", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010668", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010668", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010668", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010668", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010668")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "7:length_normal_mid", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010669")
    void case_UTAPI_010669() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010669",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010669", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010669", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010669", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010669", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010669", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010669")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("8:fw_alphanum", "-", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010670")
    void case_UTAPI_010670() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010670",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010670", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010670", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010670", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010670", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010670", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010670")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("37:hw_alphanum", "-", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010671")
    void case_UTAPI_010671() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010671",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010671", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010671", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010671", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010671", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010671", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010671")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("43:hw_symbol", "-", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010672")
    void case_UTAPI_010672() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010672",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010672", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010672", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010672", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010672", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010672", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010672")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("16:fw_kanji_common", "-", "-")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010673")
    void case_UTAPI_010673() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010673",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010673", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010673", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010673", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010673", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010673", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010673")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "8:mixed_half-width_and_full-width")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010674")
    void case_UTAPI_010674() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010674",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010674", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010674", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010674", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010674", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010674", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010674")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "10:chaotic_mix")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010675")
    void case_UTAPI_010675() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010675",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010675", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010675", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010675", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010675", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010675", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010675")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "56:space")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010676")
    void case_UTAPI_010676() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010676",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010676", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010676", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010676", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010676", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010676", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010676")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "57:line_break_code_crlf")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010677")
    void case_UTAPI_010677() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010677",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010677", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010677", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010677", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010677", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010677", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010677")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "58:line_break_code_lf")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010678")
    void case_UTAPI_010678() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010678",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010678", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010678", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010678", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010678", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010678", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010678")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "59:tab")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010679")
    void case_UTAPI_010679() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010679",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010679", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010679", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010679", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010679", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010679", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010679")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "60:control_character_null")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010680")
    void case_UTAPI_010680() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010680",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010680", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010680", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010680", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010680", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010680", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010680")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "61:surrogate_pair")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010681")
    void case_UTAPI_010681() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010681",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010681", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010681", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010681", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010681", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010681", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010681")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "62:environment-dependent_character")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

    @Test
    @DisplayName("UTAPI-010682")
    void case_UTAPI_010682() {
        CaseExecutor.execute(
            new CaseDefinition(
                "UTAPI-010682",
                "com.matsushita.dbeditor.dto.outdto.TemplateResponse",
                "fromMemo",
                "TemplateResponse",
                new ParamSpec[] {
                    new ParamSpec("t", "MemoTemplate", "t")
                },
                new DataRef[] {
                    new DataRef("UTAPI-010682", "t", "NORMAL", "OBJECT", "MemoTemplate"),
                    new DataRef("UTAPI-010682", "t.contentMemo", "NORMAL", "STRING", "String"),
                    new DataRef("UTAPI-010682", "t.createdTimestamp", "NORMAL", "DATETIME", "LocalDateTime"),
                    new DataRef("UTAPI-010682", "t.n", "NORMAL", "NUMBER", "Integer"),
                    new DataRef("UTAPI-010682", "t.titleMemo", "TARGET", "STRING", "String")
                },
                OraclePlan.builder("UTAPI-010682")
                    .targetId("./java/com/matsushita/dbeditor/dto/outdto/TemplateResponse.java::TemplateResponse::fromMemo::1::FIELD::1::MemoTemplate::titleMemo")
                    .mirror("-", "-", "63:character_with_mapping_differences")
                    .target("t.titleMemo", "MemoTemplate.titleMemo")
                    .validation("-1", "1", "255", "-")
                    .kind(OracleKind.DTO_FIELD_PROJECTION)
                    .observation("the fields of the response object produced by TemplateResponse.fromMemo")
                    .expected("every field of the response carries the value of the matching source field, so the value generated for t.titleMemo survives the mapping")
                    .failure("the mapped value is dropped, altered, truncated or written to a different field")
                    .assertion("assertNotNull on the response and assertEquals per mapped field")
                    .check(CheckType.RETURN_NOT_NULL, "the mapping must produce a response object")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getN must carry t.n", "getN", "data:t.n")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getTitle must carry t.titleMemo", "getTitle", "data:t.titleMemo")
                    .check(CheckType.RETURN_FIELD_EQUALS, "getContent must carry t.contentMemo", "getContent", "data:t.contentMemo")
                    .check(CheckType.NO_EXCEPTION, "the mapping must complete for this input condition")
                    .build()),
            new TemplateResponseWrapper());
    }

}
